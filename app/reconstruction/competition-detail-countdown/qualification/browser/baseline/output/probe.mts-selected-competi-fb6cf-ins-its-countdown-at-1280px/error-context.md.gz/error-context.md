# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: probe.mts >> selected competition retains its countdown at 1280px
- Location: reconstruction/competition-detail-countdown/probe.mts:48:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.competition-detail-heading').getByTestId('cup-countdown')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.competition-detail-heading').getByTestId('cup-countdown') with timeout 5000ms
  - waiting for locator('.competition-detail-heading').getByTestId('cup-countdown')

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- complementary "Application navigation":
  - link "Pump reconstruction home":
    - /url: /
    - img "pump.fun logomark"
  - button "Toggle Sidebar"
  - navigation "Primary":
    - list:
      - listitem:
        - link "Home":
          - /url: /
      - listitem:
        - link "Explore":
          - /url: /explore
      - listitem:
        - button "Perps" [disabled]
      - listitem:
        - link "Leaderboard":
          - /url: /leaderboard
      - listitem:
        - link "Live":
          - /url: /live
    - list:
      - listitem:
        - link "GO":
          - /url: /go
      - listitem:
        - link "Mayhem":
          - /url: /mayhem
      - listitem:
        - link "Holder rewards":
          - /url: /holder-rewards
      - listitem:
        - button "$PUMP" [disabled]
      - listitem:
        - link "Portfolio":
          - /url: /portfolio
  - button "Create a coin":
    - img
  - list:
    - listitem:
      - button "Open settings"
    - listitem:
      - button "Support (Intercom) is outside this reconstruction" [disabled]
    - listitem:
      - button "Terminal" [disabled]
  - button "Toggle Sidebar"
- banner:
  - button "Go back"
  - search:
    - button "Search for coins and users": Search for coins and users... ⌘K
  - button "Create"
  - button "Sign in"
  - button "Info bar settings" [disabled]
  - radiogroup "Info bar content":
    - radio "Watchlist" [checked]
    - radio "Positions"
    - radio "Following"
    - radio "Recently viewed"
- main:
  - paragraph: Verified read-only contract
  - heading "Leaderboard" [level=1]
  - paragraph: Trader PnL, creator payouts and competitions from documented developer reads. Rankings only appear after a response passes runtime validation.
  - text: Read only
  - navigation "Leaderboard categories":
    - link "Trader PnL":
      - /url: /leaderboard?category=traders
    - link "Creator payouts":
      - /url: /leaderboard?category=creators
    - link "Competitions":
      - /url: /leaderboard?category=competitions
  - region "Leaderboard controls":
    - search:
      - text: Filter loaded results
      - searchbox "Filter loaded results"
      - button "Filter"
      - text: Local filter only; it does not query an undocumented search API.
  - strong: Pump developer API
  - text: Validated Oct 29, 2026, 9:01 PM
  - button "← Back to competitions"
  - text: upcoming
  - heading "Solana Autumn Arena" [level=2]
  - paragraph: Upcoming solo trader showdown.
  - button "Schedule, scoring, eligibility and rules"
  - term: Ranked entries
  - definition: "0"
  - term: Prize
  - definition: $25,000 Grand Prize
  - term: Result
  - definition: In progress
  - heading "No qualifying results" [level=2]
  - paragraph: No ranked competition entry matches this local filter.
  - paragraph: "Data source: documented developer operations. The website origin was observed in captured bundles but returned HTTP 403 during bounded local qualification; no website/API equivalence is claimed."
- contentinfo:
  - paragraph: © Pump.fun 2026
  - navigation "Footer":
    - link "Blog":
      - /url: https://medium.com/@pumpdotfun_
    - button "Resources"
    - button "Legal"
  - link "X":
    - /url: https://twitter.com/pumpfun
    - img
  - link "TikTok":
    - /url: https://www.tiktok.com/@pump.fun
    - img
  - link "YouTube":
    - /url: https://www.youtube.com/@pumpfunofficial
    - img
- alert: Leaderboard
```

# Test source

```ts
  19  |   test.setTimeout(90000);
  20  |   await mkdir(output, { recursive: true });
  21  |   http = await startRulesDismissHttp();
  22  |   try {
  23  |     next = await startRulesDismissNext({
  24  |       backendUrl: http.backendUrl,
  25  |       port: Number(process.env.PUMP_RULES_PORT ?? 3027),
  26  |       outputDir: output,
  27  |     });
  28  |   } catch (error) {
  29  |     await http.close();
  30  |     throw error;
  31  |   }
  32  | });
  33  | test.afterAll(async () => {
  34  |   if (http)
  35  |     await writeFile(
  36  |       path.join(output, "handler-ledger.json"),
  37  |       JSON.stringify(await http.snapshot(), null, 2) + "\n",
  38  |     );
  39  |   if (next)
  40  |     await writeFile(
  41  |       path.join(output, "next-exit.json"),
  42  |       JSON.stringify(await next.close()) + "\n",
  43  |     );
  44  |   if (http) await http.close();
  45  | });
  46  | 
  47  | for (const width of [390, 1280]) {
  48  |   test(`selected competition retains its countdown at ${width}px`, async ({
  49  |     page,
  50  |     context,
  51  |   }) => {
  52  |     test.setTimeout(60000);
  53  |     await page.setViewportSize({ width, height: 844 });
  54  |     const errors: string[] = [];
  55  |     page.on("pageerror", (error) => errors.push(error.message));
  56  |     await context.route("**/*", async (route) => {
  57  |       const request = route.request(),
  58  |         url = new URL(request.url());
  59  |       if (url.origin !== next.baseURL || request.method() !== "GET") {
  60  |         errors.push(request.method() + " " + url.origin + url.pathname);
  61  |         await route.abort();
  62  |       } else await route.continue();
  63  |     });
  64  |     const listResponse = page.waitForResponse(
  65  |       (r) => r.url().includes("/api/leaderboard?") && r.status() === 200,
  66  |     );
  67  |     await page.goto(
  68  |       next.baseURL + "/leaderboard?category=competitions&status=upcoming",
  69  |     );
  70  |     const list = await (await listResponse).json();
  71  |     expect(list.ok).toBe(true);
  72  |     expect(list.data.kind).toBe("competitions");
  73  |     const supplied = list.data.upcoming.find(
  74  |       (c: any) => c.slug === "solana-autumn-arena",
  75  |     );
  76  |     expect(supplied.phase).toBe("upcoming");
  77  |     expect(Date.parse(supplied.startsAt)).toBeGreaterThan(Date.now() + 60000);
  78  |     const card = page.locator(".competition-card").filter({
  79  |       has: page.getByRole("heading", { name: supplied.title, exact: true }),
  80  |     });
  81  |     await expect(card.getByTestId("cup-countdown")).toBeVisible();
  82  |     const detailResponse = page.waitForResponse(
  83  |       (r) =>
  84  |         r.url().includes("/api/leaderboard?") &&
  85  |         r.url().includes("id=solana-autumn-arena") &&
  86  |         r.status() === 200,
  87  |     );
  88  |     await card.getByRole("link", { name: "View ranked entries" }).click();
  89  |     const detail = await (await detailResponse).json();
  90  |     expect(detail.ok).toBe(true);
  91  |     expect(detail.data.kind).toBe("competition-detail");
  92  |     expect(detail.data.competition).toEqual(supplied);
  93  |     const heading = page.locator(".competition-detail-heading");
  94  |     await expect(
  95  |       heading.getByRole("heading", { name: supplied.title, exact: true }),
  96  |     ).toBeVisible();
  97  |     expect(
  98  |       (await http.snapshot()).ledger.some(
  99  |         (entry: any) =>
  100 |           entry.keyMatched &&
  101 |           entry.status === 200 &&
  102 |           entry.path.startsWith("/v1/competitions/solana-autumn-arena?"),
  103 |       ),
  104 |     ).toBe(true);
  105 |     const directory = path.join(output, String(width));
  106 |     await mkdir(directory, { recursive: true });
  107 |     const admission = { width, list: list.data, detail: detail.data };
  108 |     await writeFile(
  109 |       path.join(directory, "admission.json"),
  110 |       JSON.stringify(admission, null, 2) + "\n",
  111 |     );
  112 |     await page.screenshot({
  113 |       path: path.join(directory, "selected.png"),
  114 |       fullPage: true,
  115 |     });
  116 | 
  117 |     // The unchanged baseline reaches this assertion after actual native admission.
  118 |     const countdown = heading.getByTestId("cup-countdown");
> 119 |     await expect(countdown).toBeVisible();
      |                             ^ Error: expect(locator).toBeVisible() failed
  120 |     await expect(countdown).toContainText("Starts in");
  121 |     await expect(page.getByTestId("cup-countdown")).toHaveCount(1);
  122 |     const observe = () =>
  123 |       countdown.evaluate((element) => {
  124 |         const boxes = [...element.querySelectorAll(":scope > div > div")];
  125 |         const values = boxes.map((box) =>
  126 |           Number(box.querySelector("span")?.textContent),
  127 |         );
  128 |         const labels = boxes.map(
  129 |           (box) => box.querySelectorAll("span")[1]?.textContent,
  130 |         );
  131 |         const rect = element.getBoundingClientRect();
  132 |         return {
  133 |           now: Date.now(),
  134 |           values,
  135 |           labels,
  136 |           totalSeconds:
  137 |             values[0] * 86400 + values[1] * 3600 + values[2] * 60 + values[3],
  138 |           width: rect.width,
  139 |           clientWidth: element.clientWidth,
  140 |           scrollWidth: element.scrollWidth,
  141 |         };
  142 |       });
  143 |     const beforeTick = await observe();
  144 |     expect(beforeTick.labels).toEqual(["Days", "Hours", "Minutes", "Seconds"]);
  145 |     expect(beforeTick.totalSeconds).toBeGreaterThan(0);
  146 |     expect(
  147 |       Math.abs(
  148 |         beforeTick.totalSeconds -
  149 |           Math.floor((Date.parse(supplied.startsAt) - beforeTick.now) / 1000),
  150 |       ),
  151 |     ).toBeLessThanOrEqual(2);
  152 |     await expect
  153 |       .poll(async () => (await observe()).totalSeconds, { timeout: 5000 })
  154 |       .toBeLessThan(beforeTick.totalSeconds);
  155 |     const afterTick = await observe();
  156 |     expect(afterTick.clientWidth).toBeGreaterThan(0);
  157 |     expect(afterTick.scrollWidth).toBeLessThanOrEqual(
  158 |       afterTick.clientWidth + 1,
  159 |     );
  160 |     await page.screenshot({
  161 |       path: path.join(directory, "countdown.png"),
  162 |       fullPage: true,
  163 |     });
  164 |     await heading.getByRole("button", { name: "Back to competitions" }).click();
  165 |     await expect(card.getByTestId("cup-countdown")).toBeVisible();
  166 |     await expect(page.locator(".competition-detail-heading")).toHaveCount(0);
  167 |     await expect(page.getByTestId("cup-countdown")).toHaveCount(1);
  168 |     await page.goto(next.baseURL + "/docs/fees");
  169 |     await expect(page.getByTestId("cup-countdown")).toHaveCount(0);
  170 |     expect(errors).toEqual([]);
  171 |     await writeFile(
  172 |       path.join(directory, "observed.json"),
  173 |       JSON.stringify(
  174 |         {
  175 |           ...admission,
  176 |           beforeTick,
  177 |           afterTick,
  178 |           errors,
  179 |           navigation:
  180 |             "Detail → existing list → fees: one visible countdown, then none. No timer-count or universal cleanup claim.",
  181 |         },
  182 |         null,
  183 |         2,
  184 |       ) + "\n",
  185 |     );
  186 |   });
  187 | }
  188 | 
```