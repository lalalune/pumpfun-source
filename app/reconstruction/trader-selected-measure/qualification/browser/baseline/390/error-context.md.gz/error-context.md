# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: trader-selected-measure.spec.mts >> sort controls render their selected backend measure at 390px
- Location: tests/browser/trader-selected-measure.spec.mts:71:3

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByRole('list', { name: 'Trader rankings' }).getByRole('listitem').filter({ has: locator('small[title="11111111111111111111111111111112"]') }).locator('.ranking-metric > strong')
Expected: "-$20.00"
Received: "$100.00"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" getByRole('list', { name: 'Trader rankings' }).getByRole('listitem').filter({ has: locator('small[title="11111111111111111111111111111112"]') }).locator('.ranking-metric > strong') with timeout 5000ms
  - waiting for getByRole('list', { name: 'Trader rankings' }).getByRole('listitem').filter({ has: locator('small[title="11111111111111111111111111111112"]') }).locator('.ranking-metric > strong')
    14 × locator resolved to <strong class="positive">$100.00</strong>
       - unexpected value "$100.00"

```

```yaml
- strong: $100.00
```

# Test source

```ts
  28  | test.afterAll(async () => {
  29  |   await mkdir(output, { recursive: true });
  30  |   if (fixture) {
  31  |     await writeFile(
  32  |       path.join(output, "requests.json"),
  33  |       JSON.stringify(await fixture.command("snapshot"), null, 2) + "\n",
  34  |     );
  35  |   }
  36  |   if (server) {
  37  |     const result = await server.close();
  38  |     await writeFile(
  39  |       path.join(output, "server-exit.json"),
  40  |       JSON.stringify(result) + "\n",
  41  |     );
  42  |   }
  43  |   if (fixture) await fixture.close();
  44  | });
  45  | async function isolate(page: any) {
  46  |   const origin = server.baseURL,
  47  |     unexpected: string[] = [],
  48  |     apiCalls: string[] = [];
  49  |   await page.route("**/*", async (route: any) => {
  50  |     const request = route.request(),
  51  |       url = new URL(request.url());
  52  |     if (url.origin !== origin || !["GET", "HEAD"].includes(request.method())) {
  53  |       unexpected.push(request.method() + " " + request.url());
  54  |       await route.abort();
  55  |       return;
  56  |     }
  57  |     if (url.pathname === "/api/leaderboard") {
  58  |       apiCalls.push(url.search);
  59  |       expect(request.headers().authorization).toBeUndefined();
  60  |     }
  61  |     await route.continue();
  62  |   });
  63  |   return { unexpected, apiCalls };
  64  | }
  65  | const rowFor = (page: any, wallet: string) =>
  66  |   page
  67  |     .getByRole("list", { name: "Trader rankings" })
  68  |     .getByRole("listitem")
  69  |     .filter({ has: page.locator('small[title="' + wallet + '"]') });
  70  | for (const width of [390, 1280])
  71  |   test(`sort controls render their selected backend measure at ${width}px`, async ({
  72  |     page,
  73  |   }, info) => {
  74  |     await page.setViewportSize({ width, height: 844 });
  75  |     const state = await isolate(page);
  76  |     await page.goto("/leaderboard?category=traders&period=daily&sort=combined");
  77  |     await expect(
  78  |       rowFor(page, fixture.wallets[0]).locator(".ranking-metric > strong"),
  79  |     ).toHaveText("$100.00");
  80  |     const response = page.waitForResponse((r) => {
  81  |       const u = new URL(r.url());
  82  |       return (
  83  |         u.pathname === "/api/leaderboard" &&
  84  |         u.searchParams.get("sort") === "realized" &&
  85  |         r.status() === 200
  86  |       );
  87  |     });
  88  |     await page
  89  |       .getByLabel("Trader sort", { exact: true })
  90  |       .selectOption("realized");
  91  |     const actual = await (await response).json();
  92  |     await writeFile(
  93  |       info.outputPath("realized-response.json"),
  94  |       JSON.stringify(actual, null, 2) + "\n",
  95  |     );
  96  |     expect(actual.data.kind).toBe("traders");
  97  |     expect(
  98  |       actual.data.entries.find(
  99  |         (row: any) => row.walletAddress === fixture.wallets[0],
  100 |       ).realizedPnlUsd,
  101 |     ).toBe(-20);
  102 |     expect(
  103 |       actual.data.entries.find(
  104 |         (row: any) => row.walletAddress === fixture.wallets[0],
  105 |       ).pnlUsd,
  106 |     ).toBe(100);
  107 |     const observed = (await fixture.command("snapshot")).ledger;
  108 |     expect(
  109 |       observed.some(
  110 |         (row: any) =>
  111 |           row.status === 200 &&
  112 |           row.keyMatched &&
  113 |           new URL(row.path, fixture.backendUrl).searchParams.get("sort") ===
  114 |             "realized",
  115 |       ),
  116 |     ).toBe(true);
  117 |     await expect(
  118 |       page
  119 |         .getByRole("list", { name: "Trader rankings" })
  120 |         .getByRole("listitem")
  121 |         .first(),
  122 |     ).toContainText("111111…11113");
  123 |     const alpha = rowFor(page, fixture.wallets[0]),
  124 |       beta = rowFor(page, fixture.wallets[1]);
  125 |     await page
  126 |       .getByRole("list", { name: "Trader rankings" })
  127 |       .screenshot({ path: info.outputPath("realized-before-assert.png") });
> 128 |     await expect(alpha.locator(".ranking-metric > strong")).toHaveText(
      |                                                             ^ Error: expect(locator).toHaveText(expected) failed
  129 |       "-$20.00",
  130 |     );
  131 |     await expect(alpha.locator(".ranking-metric > strong")).toHaveClass(
  132 |       "negative",
  133 |     );
  134 |     await expect(beta.locator(".ranking-metric > strong")).toHaveText("$40.00");
  135 |     await expect(alpha.locator(".ranking-metric > small")).toHaveText(
  136 |       "Realized PnL",
  137 |     );
  138 |     await page
  139 |       .getByRole("list", { name: "Trader rankings" })
  140 |       .screenshot({ path: info.outputPath("realized-after.png") });
  141 |     await page
  142 |       .getByLabel("Trader sort", { exact: true })
  143 |       .selectOption("unrealized");
  144 |     await expect(alpha.locator(".ranking-metric > strong")).toHaveText(
  145 |       "$120.00",
  146 |     );
  147 |     await expect(beta.locator(".ranking-metric > strong")).toHaveText("$10.00");
  148 |     await expect(alpha.locator(".ranking-metric > small")).toHaveText(
  149 |       "Unrealized PnL",
  150 |     );
  151 |     await expect(alpha.locator(".ranking-metric > strong")).toHaveClass(
  152 |       "positive",
  153 |     );
  154 |     await page
  155 |       .getByLabel("Trader sort", { exact: true })
  156 |       .selectOption("combined");
  157 |     await expect(alpha.locator(".ranking-metric > strong")).toHaveText(
  158 |       "$100.00",
  159 |     );
  160 |     await expect(alpha.locator(".ranking-metric > small")).toHaveText(
  161 |       "10% combined PnL",
  162 |     );
  163 |     expect(
  164 |       await page.evaluate(
  165 |         () => document.documentElement.scrollWidth <= innerWidth,
  166 |       ),
  167 |     ).toBe(true);
  168 |     expect(state.unexpected).toEqual([]);
  169 |     expect(
  170 |       state.apiCalls.some(
  171 |         (s) => new URLSearchParams(s).get("sort") === "realized",
  172 |       ),
  173 |     ).toBe(true);
  174 |     expect(await page.content()).not.toContain(`pf_live_${"A".repeat(49)}`);
  175 |   });
  176 | test("real upstream stop produces error without stale rows and Retry restores selected measure", async ({
  177 |   page,
  178 | }, info) => {
  179 |   const state = await isolate(page);
  180 |   await page.goto("/leaderboard?category=traders&period=daily&sort=realized");
  181 |   await expect(
  182 |     rowFor(page, fixture.wallets[0]).locator(".ranking-metric > strong"),
  183 |   ).toHaveText("-$20.00");
  184 |   await fixture.command("stop-backend");
  185 |   await page
  186 |     .getByLabel("Trader period", { exact: true })
  187 |     .selectOption("weekly");
  188 |   await expect(page.getByTestId("leaderboard-error")).toBeVisible();
  189 |   await expect(page.getByRole("list", { name: "Trader rankings" })).toHaveCount(
  190 |     0,
  191 |   );
  192 |   await page.screenshot({
  193 |     path: info.outputPath("upstream-error.png"),
  194 |     fullPage: true,
  195 |   });
  196 |   await fixture.command("start-backend");
  197 |   await page.getByRole("button", { name: "Retry", exact: true }).click();
  198 |   await expect(
  199 |     rowFor(page, fixture.wallets[0]).locator(".ranking-metric > strong"),
  200 |   ).toHaveText("-$20.00");
  201 |   await expect(page.getByLabel("Trader sort", { exact: true })).toHaveValue(
  202 |     "realized",
  203 |   );
  204 |   await expect(page.getByLabel("Trader period", { exact: true })).toHaveValue(
  205 |     "weekly",
  206 |   );
  207 |   await page
  208 |     .getByRole("list", { name: "Trader rankings" })
  209 |     .screenshot({ path: info.outputPath("retry-after.png") });
  210 |   expect(state.unexpected).toEqual([]);
  211 | });
  212 | 
```