import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, stat } from 'node:fs/promises';
import { once } from 'node:events';
import http from 'node:http';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const appRoot = fileURLToPath(new URL('../../../', import.meta.url));
const repoRoot = path.dirname(appRoot);
const args = process.argv.slice(2);
assert.equal(args.length, 4, 'Usage: browser.mjs --source FULL_PUBLIC_OR_LOCAL_SHA --output NEW_DIRECTORY');
assert.equal(args[0], '--source'); assert.match(args[1], /^[a-f0-9]{40}$/); assert.equal(args[2], '--output');
const source = args[1], output = path.resolve(args[3]);
await assert.rejects(stat(output), { code: 'ENOENT' });
await mkdir(output, { recursive: true });
const sha = (b) => createHash('sha256').update(b).digest('hex');
const git = (...a) => execFileSync('git', a, { cwd: repoRoot, env: { ...process.env, GIT_NO_LAZY_FETCH: '1' } });
git('cat-file', '-e', `${source}^{commit}`);
const sourceFiles = ['reconstruction/create-quote-selection/client.mjs', 'reconstruction/create-quote-selection/client.d.mts',
  'reconstruction/create-quote-selection/qualification/browser.mjs', 'reconstruction/create-quote-selection/qualification/fixture.mjs'];
const sourceBinding = [];
for (const relative of sourceFiles) {
  const bytes = await readFile(path.join(appRoot, relative));
  assert.ok(bytes.equals(git('show', `${source}:app/${relative}`)), `actual source differs: ${relative}`);
  sourceBinding.push({ path: relative, bytes: bytes.length, sha256: sha(bytes), gitBlob: git('rev-parse', `${source}:app/${relative}`).toString().trim() });
}
const frontend = createRequire(path.join(appRoot, 'packages/frontend/package.json'));
const backend = createRequire(path.join(appRoot, 'packages/backend/package.json'));
const esbuild = createRequire(backend.resolve('tsx'))('esbuild');
const { chromium } = frontend('@playwright/test');
const built = await esbuild.build({ entryPoints: [fileURLToPath(new URL('fixture.mjs', import.meta.url))], absWorkingDir: appRoot,
  bundle: true, write: false, platform: 'browser', format: 'iife', metafile: true,
  define: { 'process.env.NODE_ENV': '"development"' },
  alias: { react: frontend.resolve('react'), 'react/jsx-runtime': frontend.resolve('react/jsx-runtime'),
    'react/compiler-runtime': frontend.resolve('react/compiler-runtime'), 'react-dom/client': frontend.resolve('react-dom/client'), 'react-dom': frontend.resolve('react-dom') } });
const bundle = built.outputFiles[0].contents;
const inputs = [];
for (const relative of Object.keys(built.metafile.inputs)) {
  const bytes = await readFile(path.resolve(appRoot, relative)); inputs.push({ path: relative, bytes: bytes.length, sha256: sha(bytes) });
}
for (const row of sourceBinding) if (!inputs.some((r) => r.path === row.path)) inputs.push({ path: row.path, bytes: row.bytes, sha256: row.sha256 });
const record = { scope: 'Standalone real React/compiler; complete quote coordinator with synthetic query/picker/state/translation/art/dialog ports. No original acquisition, provider, asset search, wallet or submission.',
  selectedSource: source, repositoryHead: git('rev-parse', 'HEAD').toString().trim(), sourceBinding, inputs, bundleSha256: sha(bundle),
  cases: [], requests: [], blockedRequests: [], pageErrors: [], startedAt: new Date().toISOString() };
await writeFile(path.join(output, 'INPUTS.json'), JSON.stringify(record, null, 2) + '\n');
await writeFile(path.join(output, 'bundle.js'), bundle);
const server = http.createServer((req, res) => {
  record.requests.push({ method: req.method, path: req.url });
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'self'; connect-src 'none'; style-src 'none'; img-src 'none'");
  if (req.method !== 'GET') { res.writeHead(405); return res.end(); }
  if (req.url === '/') { res.setHeader('Content-Type', 'text/html'); return res.end('<!doctype html><meta charset="utf-8"><title>Synthetic Create control</title><div id="root"></div><script src="/bundle.js"></script>'); }
  if (req.url === '/bundle.js') { res.setHeader('Content-Type', 'text/javascript'); return res.end(bundle); }
  res.writeHead(404); res.end();
});
let browser, context, page;
async function observed() { return page.evaluate(() => window.harness.observe()); }
async function scenario(name, run) {
  const row = { name, startedAt: new Date().toISOString() }; record.cases.push(row);
  try { await run(row); row.status = 'PASS'; }
  catch (e) { row.status = 'FAIL'; row.error = String(e.stack ?? e); await page.screenshot({ path: path.join(output, `failure-${record.cases.length}.png`) }).catch(() => {}); throw e; }
  finally { row.endedAt = new Date().toISOString(); }
}
try {
  server.listen(0, '127.0.0.1'); await once(server, 'listening'); record.origin = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ headless: true }); context = await browser.newContext({ viewport: { width: 850, height: 700 } });
  await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
  page = await context.newPage(); page.on('pageerror', (e) => record.pageErrors.push(String(e.stack ?? e)));
  await page.route('**/*', (route) => {
    if (new URL(route.request().url()).origin === record.origin) return route.continue();
    record.blockedRequests.push(route.request().url()); return route.abort('blockedbyclient');
  });
  await page.goto(record.origin); await page.waitForFunction(() => !!window.harness);
  const radios = page.getByRole('radio');
  const sol = page.getByRole('radio', { name: 'SOL', exact: true });
  const usdc = page.getByRole('radio', { name: 'USDC', exact: true });
  const stockRadio = () => page.getByRole('radio', { name: /Stock \/ Pump/, exact: false });
  const trigger = () => page.locator('button[aria-haspopup="dialog"]');
  const dialog = page.getByRole('dialog', { name: 'Synthetic picker gateway' });
  await scenario('complete initial SOL radios and supplied stock availability gate', async (row) => {
    assert.equal(await radios.count(), 2); assert.equal(await sol.getAttribute('aria-checked'), 'true');
    assert.equal(await usdc.getAttribute('aria-checked'), 'false'); assert.equal(await trigger().count(), 0);
    row.initial = await observed(); await page.evaluate(() => window.harness.supplyStocks('loaded'));
    assert.equal(await radios.count(), 3); assert.equal(await stockRadio().getAttribute('aria-checked'), 'false'); row.loaded = await observed();
  });
  await scenario('native SOL/USDC radio selection updates exact pair flag and ignores same-kind selection', async (row) => {
    await page.evaluate(() => window.harness.clearCalls()); await usdc.click();
    row.usdc = await observed(); assert.deepEqual(row.usdc.pair, { kind: 'usdc' }); assert.equal(row.usdc.isQuoteMintEnabled, true);
    const count = row.usdc.calls.length; await usdc.click(); assert.equal((await observed()).calls.length, count);
    await sol.click(); row.sol = await observed(); assert.deepEqual(row.sol.pair, { kind: 'sol' }); assert.equal(row.sol.isQuoteMintEnabled, false);
    assert.ok(!row.sol.calls.some(([kind]) => kind === 'mayhem-read' || kind === 'sharing-read'));
  });
  await scenario('stock radio invokes supplied flag setters and notices in actual source order', async (row) => {
    await page.evaluate(() => { window.harness.flags(true, true); window.harness.clearCalls(); });
    await stockRadio().click(); row.selected = await observed();
    assert.deepEqual(row.selected.calls.map(([kind]) => kind), ['mayhem-read', 'mayhem', 'info', 'sharing-read', 'sharing', 'info', 'quote']);
    assert.equal(row.selected.mayhem, false); assert.equal(row.selected.sharing, false); assert.deepEqual(row.selected.pair, { kind: 'stock' });
    assert.equal(await stockRadio().getAttribute('aria-checked'), 'true'); const count = row.selected.calls.length;
    await stockRadio().click(); assert.equal((await observed()).calls.length, count);
  });
  await scenario('six-field gateway/five-field picker contract, close notifications and stock identity', async (row) => {
    await trigger().click(); await dialog.waitFor(); row.open = await observed();
    assert.equal(await trigger().getAttribute('aria-expanded'), 'true');
    assert.deepEqual(row.open.pickerFields, ['isLoading', 'stocks', 'onSelect', 'onSelectPumpCoin', 'onClose']);
    assert.equal(row.open.pickerSameReaderArray, true);
    await page.getByRole('button', { name: 'Emit open notification', exact: true }).click(); assert.equal(await dialog.count(), 1);
    await page.getByRole('button', { name: 'Emit close notification', exact: true }).click(); await dialog.waitFor({ state: 'hidden' });
    await trigger().click(); await dialog.waitFor();
    await page.evaluate(() => { window.harness.flags(true, true); window.harness.clearCalls(); });
    await page.getByRole('button', { name: 'Emit stock callback', exact: true }).click(); await dialog.waitFor({ state: 'hidden' });
    row.stock = await observed(); assert.equal(row.stock.sameStockReference, true); assert.equal(row.stock.mayhem, true); assert.equal(row.stock.sharing, true);
    assert.deepEqual(row.stock.calls.map(([kind]) => kind), ['quote']); assert.equal(await trigger().getAttribute('aria-expanded'), 'false');
  });
  await scenario('supplied Pump selection keeps shallow fields and defensive nullish/empty branches', async (row) => {
    await trigger().click(); await dialog.waitFor(); await page.getByRole('button', { name: 'Emit Pump callback', exact: true }).click();
    await dialog.waitFor({ state: 'hidden' }); row.normal = await observed();
    assert.equal(row.normal.pair.kind, 'pump'); assert.equal(row.normal.pair.coin.untouched, 12);
    assert.equal(row.normal.samePumpReference, false); assert.equal(row.normal.samePumpNestedReference, true);
    await trigger().click(); await dialog.waitFor(); await page.getByRole('button', { name: 'Emit missing-name callback', exact: true }).click();
    await dialog.waitFor({ state: 'hidden' }); row.missing = await observed();
    assert.equal(row.missing.pair.coin.name, 'synthetic-missing'); assert.equal(row.missing.pair.coin.symbol, 'synthetic-missing'); assert.equal(row.missing.pair.coin.untouched, 19);
    await trigger().click(); await dialog.waitFor(); await page.getByRole('button', { name: 'Emit empty-name callback', exact: true }).click();
    await dialog.waitFor({ state: 'hidden' }); row.empty = await observed();
    assert.equal(row.empty.pair.coin.name, ''); assert.equal(row.empty.pair.coin.symbol, '');
    row.limit = 'Defensive supplied callback branches only; no original asset-search eligibility proven.';
  });
  await scenario('current stock/Pump retains third radio when reader empty/pending without disabling ordinary choices', async (row) => {
    await page.evaluate(() => window.harness.supplyStocks('undefined', true)); assert.equal(await radios.count(), 3);
    assert.equal(await sol.isEnabled(), true); assert.equal(await usdc.isEnabled(), true); await trigger().click(); await dialog.waitFor();
    assert.equal(await page.getByTestId('picker-loading').innerText(), 'true'); assert.equal(await page.getByTestId('picker-count').innerText(), '0');
    row.pending = await observed(); await page.getByRole('button', { name: 'Close supplied picker', exact: true }).click(); await dialog.waitFor({ state: 'hidden' });
  });
  await scenario('actual compiler updates source translation consumers while brand labels and selection remain', async (row) => {
    await page.evaluate(() => window.harness.setLanguage('B'));
    assert.equal(await stockRadio().getAttribute('aria-checked'), 'true');
    assert.equal(await page.getByRole('radiogroup').getAttribute('aria-label'), 'B Pair asset');
    assert.ok((await trigger().innerText()).includes('B Pair')); assert.equal(await sol.innerText(), 'SOL'); assert.equal(await usdc.innerText(), 'USDC');
    row.changed = await observed(); assert.equal(row.changed.pair.coin.name, '');
  });
  await scenario('independent open state survives supplied quote change and real subscriptions clean up', async (row) => {
    await trigger().click(); await dialog.waitFor(); await page.evaluate(() => window.harness.setQuote({ kind: 'sol' }));
    assert.equal(await trigger().count(), 0); assert.equal(await dialog.count(), 1); row.openSol = await observed();
    await page.getByRole('button', { name: 'Close supplied picker', exact: true }).click(); await dialog.waitFor({ state: 'hidden' });
    assert.equal(await sol.getAttribute('aria-checked'), 'true'); row.unmounted = await page.evaluate(() => window.harness.unmount());
    assert.equal(row.unmounted.quoteSubscribers, 0); assert.equal(row.unmounted.readerSubscribers, 0); assert.equal(row.unmounted.translationSubscribers, 0);
  });
  assert.equal(record.cases.length, 8); assert.deepEqual(record.pageErrors, []); assert.deepEqual(record.blockedRequests, []); record.status = 'PASS';
} finally {
  if (context) await context.tracing.stop({ path: path.join(output, 'trace.zip') }).catch(() => {});
  if (browser) await browser.close(); record.browserClosed = browser ? !browser.isConnected() : true;
  if (server.listening) await new Promise((resolve) => server.close(resolve)); record.serverListening = server.listening;
  for (const input of record.inputs) {
    const bytes = await readFile(path.resolve(appRoot, input.path)); input.afterRunSha256 = sha(bytes); input.unchanged = input.sha256 === input.afterRunSha256;
  }
  record.endedAt = new Date().toISOString(); await writeFile(path.join(output, 'RESULT.json'), JSON.stringify(record, null, 2) + '\n');
}
assert.ok(record.inputs.every((i) => i.unchanged));
console.log(JSON.stringify({ status: record.status, cases: record.cases.length, pageErrors: record.pageErrors,
  browserClosed: record.browserClosed, serverListening: record.serverListening, allInputsUnchanged: record.inputs.every((i) => i.unchanged) }));
