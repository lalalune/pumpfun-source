import hashlib
import json
import os
import pathlib
import signal
import subprocess
import time

root = pathlib.Path('/workspace/pump-app-social')
work = root / 'work/callout-image-preview-20261029'
frozen = json.loads((work / 'FROZEN-SOURCE.json').read_text())
def inputs():
    result = []
    for entry in frozen['files']:
        data = (root / entry['path']).read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        if sha != entry['sha256']:
            raise RuntimeError('Frozen source input changed: ' + entry['path'])
        result.append({'path': entry['path'], 'sha256': sha, 'bytes': len(data)})
    return result
before = inputs()
os.putenv('PUMP_IMAGE_PREVIEW_OUTPUT', str(work / 'browser-initial'))
command = ['node', '--test', 'tests/callout_image_preview.browser.mjs']
started = time.time()
timed_out = False
with (work / 'browser-initial.log').open('w') as log:
    process = subprocess.Popen(command, cwd=root / 'app', stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        exit_code = process.wait(timeout=100)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        exit_code = process.wait(timeout=10)
after = inputs()
record = {'sourceCommit': frozen['head'], 'command': command, 'cwd': 'app',
          'outputEnvironment': {'PUMP_IMAGE_PREVIEW_OUTPUT': 'work/callout-image-preview-20261029/browser-initial'},
          'exitCode': exit_code, 'timedOut': timed_out, 'elapsedSeconds': time.time() - started,
          'before': before, 'after': after, 'controllerSha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
(work / 'BROWSER-CONTROLLER-INITIAL.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['sourceCommit', 'exitCode', 'timedOut', 'elapsedSeconds']}), flush=True)
print((work / 'browser-initial.log').read_text()[-6000:], flush=True)
raise SystemExit(exit_code if exit_code else 0)
