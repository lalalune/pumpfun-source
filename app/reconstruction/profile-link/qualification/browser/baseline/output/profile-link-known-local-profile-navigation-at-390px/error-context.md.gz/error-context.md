# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: profile-link.spec.mts >> known local profile navigation at 390px
- Location: tests/browser/profile-link.spec.mts:48:3

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('list', { name: 'Trader rankings' }).locator('li').first().getByRole('link', { name: 'View local example profile for @alice_pump' })
Expected: "/profile/7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" getByRole('list', { name: 'Trader rankings' }).locator('li').first().getByRole('link', { name: 'View local example profile for @alice_pump' }) with timeout 5000ms
  - waiting for getByRole('list', { name: 'Trader rankings' }).locator('li').first().getByRole('link', { name: 'View local example profile for @alice_pump' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- navigation "Mobile":
  - link "Home":
    - /url: /
    - img
  - link "Explore":
    - /url: /explore
  - button "Create":
    - img
  - link "GO":
    - /url: /go
  - button "Open navigation"
- banner:
  - link "pump.fun logomark":
    - /url: /
    - img "pump.fun logomark"
  - button "Search for coins and users"
  - button "Sign in"
- main:
  - paragraph: Verified read-only contract
  - heading "Leaderboard" [level=1]
  - paragraph: Trader PnL, creator payouts and competitions from documented developer reads. Rankings only appear after a response passes runtime validation.
  - text: Read only
  - navigation "Leaderboard categories":
    - link "Trader PnL":
      - /url: /leaderboard?category=traders
    - link "Creator payouts":
      - /url: /leaderboard?category=creators
    - link "Competitions":
      - /url: /leaderboard?category=competitions
  - region "Leaderboard controls":
    - text: Period
    - combobox "Trader period":
      - option "Daily" [selected]
      - option "Weekly"
      - option "Monthly"
    - text: Sort
    - combobox "Trader sort":
      - option "Combined PnL" [selected]
      - option "Realized PnL"
      - option "Unrealized PnL"
    - search:
      - text: Filter loaded results
      - searchbox "Filter loaded results"
      - button "Filter"
      - text: Local filter only; it does not query an undocumented search API.
  - strong: Pump developer API
  - text: Validated Oct 29, 2026, 7:42 PM Daily 3 validated traders
  - list "Trader rankings":
    - listitem:
      - text: "1"
      - strong: "@alice_pump ✓"
      - text: 7xKXtg…sgAsU · 0 positions
      - strong: $100.00
      - text: 10% combined PnL Realized -$20.00 Unrealized $120.00
    - listitem:
      - text: "2"
      - strong: "@alice_pump ✓"
      - text: DfMxre…XXhzj · 0 positions
      - strong: $50.00
      - text: 5% combined PnL Realized $40.00 Unrealized $10.00
    - listitem:
      - text: "3"
      - strong: 111111…11112
      - text: 111111…11112 · 0 positions
      - strong: $25.00
      - text: 5% combined PnL Realized $40.00 Unrealized $10.00
  - paragraph: "Data source: documented developer operations. The website origin was observed in captured bundles but returned HTTP 403 during bounded local qualification; no website/API equivalence is claimed."
- contentinfo:
  - navigation "Resources":
    - heading "Resources" [level=2]
    - list:
      - listitem:
        - link "PumpSwap":
          - /url: https://swap.pump.fun
      - listitem:
        - link "Fees":
          - /url: /docs/fees
      - listitem:
        - link "Revenue":
          - /url: https://fees.pump.fun/
      - listitem:
        - link "Tech updates":
          - /url: https://t.me/pump_tech_updates
      - listitem:
        - link "Wallet sign-in changes":
          - /url: /docs/wallet-login-changes
  - navigation "Legal":
    - heading "Legal" [level=2]
    - list:
      - listitem:
        - link "Privacy policy":
          - /url: /docs/privacy-policy
      - listitem:
        - link "Terms of service":
          - /url: /docs/terms-and-conditions
      - listitem:
        - link "Tokenized agent disclaimer":
          - /url: /docs/tokenized-agent-disclaimer
      - listitem:
        - link "Livestream policy":
          - /url: /docs/livestream-moderation-policy
      - listitem:
        - link "DMCA policy":
          - /url: /docs/dmca-policy
      - listitem:
        - link "Trademark guidelines":
          - /url: /docs/trademark-guidelines
      - listitem:
        - link "Charity coins":
          - /url: /docs/charitycoins
      - listitem:
        - link "Go.fun terms":
          - /url: /docs/go-fun-terms
  - link "Blog":
    - /url: https://medium.com/@pumpdotfun_
  - paragraph: © Pump.fun 2026
  - link "X":
    - /url: https://twitter.com/pumpfun
    - img
  - link "TikTok":
    - /url: https://www.tiktok.com/@pump.fun
    - img
  - link "YouTube":
    - /url: https://www.youtube.com/@pumpfunofficial
    - img
- alert
```

# Test source

```ts
  32  | test.afterAll(async () => {
  33  |   if (http) {
  34  |     const snapshot = await http.command("snapshot");
  35  |     await writeFile(
  36  |       path.join(output, "handler-ledger.json"),
  37  |       JSON.stringify(snapshot, null, 2) + "\n",
  38  |     );
  39  |   }
  40  |   if (next)
  41  |     await writeFile(
  42  |       path.join(output, "next-exit.json"),
  43  |       JSON.stringify(await next.close()) + "\n",
  44  |     );
  45  |   if (http) await http.close();
  46  | });
  47  | for (const width of [390, 1280])
  48  |   test(`known local profile navigation at ${width}px`, async ({
  49  |     page,
  50  |     context,
  51  |   }, testInfo) => {
  52  |     test.setTimeout(60000);
  53  |     await page.setViewportSize({ width, height: 900 });
  54  |     const errors: string[] = [],
  55  |       requests: Array<{ url: string; method: string; status?: number }> = [];
  56  |     page.on("pageerror", (error) => errors.push(error.message));
  57  |     await context.route("**/*", async (route) => {
  58  |       const request = route.request(),
  59  |         u = new URL(request.url());
  60  |       if (u.origin !== next.baseURL) {
  61  |         await route.abort();
  62  |         return;
  63  |       }
  64  |       if (request.method() !== "GET") {
  65  |         errors.push(
  66  |           "Unexpected browser write " + request.method() + " " + u.pathname,
  67  |         );
  68  |         await route.abort();
  69  |         return;
  70  |       }
  71  |       await route.continue();
  72  |     });
  73  |     page.on("response", (response) => {
  74  |       if (response.url().includes("/api/leaderboard"))
  75  |         requests.push({
  76  |           url: response.url(),
  77  |           method: response.request().method(),
  78  |           status: response.status(),
  79  |         });
  80  |     });
  81  |     const bodyPromise = page.waitForResponse(
  82  |       (r) => r.url().includes("/api/leaderboard?") && r.status() === 200,
  83  |     );
  84  |     await page.goto(
  85  |       next.baseURL + "/leaderboard?category=traders&period=daily&sort=combined",
  86  |     );
  87  |     const response = await bodyPromise,
  88  |       body = await response.json();
  89  |     expect(body.ok).toBe(true);
  90  |     expect(body.data.entries).toHaveLength(3);
  91  |     expect(body.data.entries[0]).toMatchObject({
  92  |       walletAddress: wallet,
  93  |       userId: "user-001",
  94  |       username: "alice_pump",
  95  |       pnlUsd: 100,
  96  |     });
  97  |     const snapshot = await http.command("snapshot");
  98  |     expect(
  99  |       snapshot.ledger.some(
  100 |         (r: any) =>
  101 |           r.keyMatched &&
  102 |           r.status === 200 &&
  103 |           r.method === "GET" &&
  104 |           r.path.startsWith("/v1/pnl-leaderboard?"),
  105 |       ),
  106 |     ).toBe(true);
  107 |     const rows = page
  108 |       .getByRole("list", { name: "Trader rankings" })
  109 |       .locator("li");
  110 |     await expect(rows).toHaveCount(3);
  111 |     await expect(rows.nth(0).locator(".ranking-metric strong")).toHaveText(
  112 |       "$100.00",
  113 |     );
  114 |     await expect(rows.nth(1)).toContainText("@alice_pump");
  115 |     await expect(rows.nth(1).getByRole("link")).toHaveCount(0); // Known wallet, mismatched user/name tuple.
  116 |     await expect(rows.nth(2).getByRole("link")).toHaveCount(0); // Unresolved public identity.
  117 |     await mkdir(path.join(output, String(width)), { recursive: true });
  118 |     await writeFile(
  119 |       path.join(output, String(width), "admitted-response.json"),
  120 |       JSON.stringify(body, null, 2) + "\n",
  121 |     );
  122 |     await page.screenshot({
  123 |       path: path.join(output, String(width), "rankings.png"),
  124 |       fullPage: true,
  125 |     });
  126 |     const link = rows
  127 |       .nth(0)
  128 |       .getByRole("link", {
  129 |         name: "View local example profile for @alice_pump",
  130 |       });
  131 |     // Same causal assertion on baseline and candidate, after real HTTP admission.
> 132 |     await expect(link).toHaveAttribute("href", "/profile/" + wallet);
      |                        ^ Error: expect(locator).toHaveAttribute(expected) failed
  133 |     expect(
  134 |       await page.evaluate(
  135 |         () => document.querySelectorAll('link[rel="prefetch"]').length,
  136 |       ),
  137 |     ).toBe(0);
  138 |     await link.focus();
  139 |     await expect(link).toBeFocused();
  140 |     await link.press("Enter");
  141 |     await expect(page).toHaveURL(next.baseURL + "/profile/" + wallet);
  142 |     await expect(page.getByLabel("Profile data source")).toContainText(
  143 |       "Local synthetic example — not a real Pump.fun user",
  144 |     );
  145 |     await expect(page.locator(".profile-page")).toContainText("alice_pump");
  146 |     await page.screenshot({
  147 |       path: path.join(output, String(width), "profile.png"),
  148 |       fullPage: true,
  149 |     });
  150 |     await page.goBack();
  151 |     await expect(page).toHaveURL(
  152 |       /\/leaderboard\?category=traders&period=daily&sort=combined$/,
  153 |     );
  154 |     const returned = page.getByRole("link", {
  155 |       name: "View local example profile for @alice_pump",
  156 |     });
  157 |     await expect(returned).toBeVisible();
  158 |     await returned.click();
  159 |     await expect(page).toHaveURL(next.baseURL + "/profile/" + wallet);
  160 |     expect(errors).toEqual([]);
  161 |     await writeFile(
  162 |       path.join(output, String(width), "browser-observed.json"),
  163 |       JSON.stringify(
  164 |         { errors, requests, actualProfileURL: page.url() },
  165 |         null,
  166 |         2,
  167 |       ) + "\n",
  168 |     );
  169 |   });
  170 | 
```