import assert from'node:assert/strict';import path from'node:path';import{fileURLToPath}from'node:url';import{writeFile}from'node:fs/promises';
import{openCorpus,findNodes,exactlyOne,member,propertyName,sha256}from'../../app/scripts/original-contracts/source.mjs';
import{normalizeSession}from'../../app/scripts/verify-search-session.mjs';
const root=fileURLToPath(new URL('../../app',import.meta.url)),c=await openCorpus(root);
const decls=f=>f.node.body.body.flatMap(n=>n.type==='VariableDeclaration'?n.declarations:[]);
const decl=(f,k)=>exactlyOne(decls(f).filter(n=>n.id.name===k),'binding '+k);
function exp(f,id,key){const n=exactlyOne(findNodes(f.node,n=>n.type==='CallExpression'&&member(n.callee,f.runtime,'s')&&(n.arguments.length===1||n.arguments[1]?.value===id)&&n.arguments[0]?.type==='ArrayExpression'&&n.arguments[0].elements.some(x=>x?.value===key)),'export '+id+'.'+key),a=n.arguments[0].elements,i=a.findIndex(x=>x?.value===key);let v=a[i+2];if(v.type==='Identifier')v=decl(f,v.name).init;return v;}
let canonical;const result=[];
for(const m of c.index.modules.filter(m=>m.ids.includes(223363)))for(const o of m.origins){const f=await c.factory(223363,{source:o.source}),frame=exp(f,223363,'f');
 const aliases=new Map(decls(f).filter(n=>n.init?.type==='CallExpression'&&member(n.init.callee,f.runtime,'i')).map(n=>[n.id.name,n.init.arguments[0]?.value]));
 const ring=exactlyOne(decls(f).filter(n=>n.init?.type==='ObjectExpression'&&n.init.properties.some(p=>propertyName(p.key)==='strip')),'ring map');
 const imports={};for(const n of findNodes(frame,n=>n.type==='MemberExpression'&&!n.computed&&aliases.has(n.object?.name)))imports[n.object.name+'.'+propertyName(n.property)]='operation:'+aliases.get(n.object.name)+'.'+propertyName(n.property);
 const normalized=normalizeSession(frame,{Symbol:'global:Symbol',Number:'global:Number',Date:'global:Date',p:'operation:formatAmount',[ring.id.name]:'data:ring'},imports);
 const same=canonical===undefined?true:JSON.stringify(canonical)===JSON.stringify(normalized);if(!canonical)canonical=normalized;
 result.push({factory:f.provenance,completeFrame:f.witness(frame,'full154-slot display'),normalizedSha256:sha256(JSON.stringify(normalized)),sameAsFirst:same,aliases:Object.fromEntries(aliases)});
}
await writeFile(new URL('DISPLAY-VARIANTS.json',import.meta.url),JSON.stringify({result},null,2)+'\n');console.log(JSON.stringify(result.map(x=>({sha:x.factory.sha256,same:x.sameAsFirst,normalized:x.normalizedSha256}))));
