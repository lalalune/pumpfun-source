# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rules-dismiss.spec.mts >> actual competition Rules light dismissal at 1280px
- Location: app/tests/browser/rules-dismiss.spec.mts:45:3

# Error details

```
Error: expect(locator).not.toBeVisible() failed

Locator:  getByRole('dialog', { name: 'Competition rules' })
Expected: not visible
Received: visible
Timeout:  5000ms

Call log:
  - Expect "not toBeVisible" getByRole('dialog', { name: 'Competition rules' }) with timeout 5000ms
  - waiting for getByRole('dialog', { name: 'Competition rules' })
    14 × locator resolved to <dialog open="" aria-labelledby="_r_0_" aria-describedby="_r_1_" data-testid="cup-rules-dialog" class="competition-rules_dialog__EgJ1Q">…</dialog>
       - unexpected value "visible"

```

```yaml
- dialog "Competition rules":
  - banner
  - paragraph: Read-only reconstruction of captured competition rules. Times shown in UTC. Registration, eligibility checks and prize claims are not available here.
  - paragraph: Solana Autumn Arena
  - heading "Schedule" [level=3]
  - term: Registration
  - definition: Nov 1, 12:00 AM – Dec 1, 12:00 AM
  - term: Competition
  - definition: Nov 15, 12:00 AM – Dec 1, 12:00 AM
  - heading "How it's scored" [level=3]
  - paragraph: Upcoming solo trader showdown.
  - heading "Who can enter" [level=3]
  - paragraph: Anyone with a pump.fun wallet, one entry each. Register from the pump.fun app before registration closes.
  - paragraph: Limited to 250 entries.
  - heading "Prize breakdown" [level=3]
  - paragraph: $25,000 Grand Prize
  - term: "#1"
  - definition: $25,000
  - paragraph: Top 1 gets paid
  - heading "Rules" [level=3]
  - list
  - link "Competition terms and conditions":
    - /url: https://pump.fun/docs/app-competition-terms
```

# Test source

```ts
  29  |   }
  30  | });
  31  | test.afterAll(async () => {
  32  |   if (http)
  33  |     await writeFile(
  34  |       path.join(output, "handler-ledger.json"),
  35  |       JSON.stringify(await http.snapshot(), null, 2) + "\n",
  36  |     );
  37  |   if (next)
  38  |     await writeFile(
  39  |       path.join(output, "next-exit.json"),
  40  |       JSON.stringify(await next.close()) + "\n",
  41  |     );
  42  |   if (http) await http.close();
  43  | });
  44  | for (const width of [390, 1280])
  45  |   test(`actual competition Rules light dismissal at ${width}px`, async ({
  46  |     page,
  47  |     context,
  48  |   }) => {
  49  |     test.setTimeout(60000);
  50  |     await page.setViewportSize({ width, height: 844 });
  51  |     const errors: string[] = [];
  52  |     page.on("pageerror", (error) => errors.push(error.message));
  53  |     await context.route("**/*", async (route) => {
  54  |       const request = route.request(),
  55  |         url = new URL(request.url());
  56  |       if (url.origin !== next.baseURL || request.method() !== "GET") {
  57  |         errors.push(request.method() + " " + url.origin + url.pathname);
  58  |         await route.abort();
  59  |         return;
  60  |       }
  61  |       await route.continue();
  62  |     });
  63  |     const responsePromise = page.waitForResponse(
  64  |       (r) => r.url().includes("/api/leaderboard?") && r.status() === 200,
  65  |     );
  66  |     await page.goto(
  67  |       next.baseURL +
  68  |         "/leaderboard?category=competitions&competition=solana-autumn-arena",
  69  |     );
  70  |     const response = await responsePromise,
  71  |       body = await response.json();
  72  |     expect(body.ok).toBe(true);
  73  |     expect(body.data.kind).toBe("competition-detail");
  74  |     expect(body.data.competition.slug).toBe("solana-autumn-arena");
  75  |     const ledger = await http.snapshot();
  76  |     expect(
  77  |       ledger.ledger.some(
  78  |         (r: any) =>
  79  |           r.keyMatched &&
  80  |           r.status === 200 &&
  81  |           r.method === "GET" &&
  82  |           r.path.startsWith("/v1/competitions/solana-autumn-arena?"),
  83  |       ),
  84  |     ).toBe(true);
  85  |     const launcher = page.getByRole("button", {
  86  |         name: "Schedule, scoring, eligibility and rules",
  87  |       }),
  88  |       dialog = page.getByRole("dialog", { name: "Competition rules" });
  89  |     await expect(launcher).toBeEnabled();
  90  |     await launcher.focus();
  91  |     await launcher.press("Enter");
  92  |     await expect(dialog).toBeVisible();
  93  |     const close = dialog.getByRole("button", { name: "Close", exact: true });
  94  |     await expect(close).toBeFocused();
  95  |     await expect(dialog).toContainText("Solana Autumn Arena");
  96  |     const before = await page.evaluate(() => ({
  97  |       scrollY: window.scrollY,
  98  |       overflow: document.body.style.overflow,
  99  |     }));
  100 |     const box = await dialog.boundingBox();
  101 |     if (!box) throw Error("No native Rules dialog box");
  102 |     expect(box.x).toBeGreaterThan(2);
  103 |     expect(box.y).toBeGreaterThan(2);
  104 |     // A press starting inside and released on the backdrop must remain inside-owned.
  105 |     await page.mouse.move(box.x + box.width / 2, box.y + 20);
  106 |     await page.mouse.down();
  107 |     await page.mouse.move(2, 2);
  108 |     await page.mouse.up();
  109 |     await expect(dialog).toBeVisible();
  110 |     await page.mouse.click(2, 2, { button: "right" });
  111 |     await expect(dialog).toBeVisible();
  112 |     await page.mouse.move(2, 2);
  113 |     await page.mouse.wheel(0, 400);
  114 |     expect(await page.evaluate(() => window.scrollY)).toBe(before.scrollY);
  115 |     const readsBefore = (await http.snapshot()).ledger.filter((r: any) =>
  116 |       r.path.startsWith("/v1/competitions/"),
  117 |     ).length;
  118 |     await mkdir(path.join(output, String(width)), { recursive: true });
  119 |     await writeFile(
  120 |       path.join(output, String(width), "admitted-response.json"),
  121 |       JSON.stringify(body, null, 2) + "\n",
  122 |     );
  123 |     await page.screenshot({
  124 |       path: path.join(output, String(width), "before-outside.png"),
  125 |       fullPage: true,
  126 |     });
  127 |     await page.mouse.click(2, 2);
  128 |     // Same actual missing behavior assertion before and after the caller-only fix.
> 129 |     await expect(dialog).not.toBeVisible();
      |                              ^ Error: expect(locator).not.toBeVisible() failed
  130 |     await expect(launcher).toBeFocused();
  131 |     expect(await page.evaluate(() => document.body.style.overflow)).toBe("");
  132 |     expect(await page.evaluate(() => window.scrollY)).toBe(before.scrollY);
  133 |     await page.screenshot({
  134 |       path: path.join(output, String(width), "after-outside.png"),
  135 |       fullPage: true,
  136 |     });
  137 |     await launcher.press("Enter");
  138 |     await expect(dialog).toBeVisible();
  139 |     await page.keyboard.press("Escape");
  140 |     await expect(dialog).not.toBeVisible();
  141 |     await expect(launcher).toBeFocused();
  142 |     await launcher.click();
  143 |     await expect(dialog).toBeVisible();
  144 |     await close.click();
  145 |     await expect(dialog).not.toBeVisible();
  146 |     await expect(launcher).toBeFocused();
  147 |     expect(
  148 |       (await http.snapshot()).ledger.filter((r: any) =>
  149 |         r.path.startsWith("/v1/competitions/"),
  150 |       ).length,
  151 |     ).toBe(readsBefore);
  152 |     expect(errors).toEqual([]);
  153 |     await writeFile(
  154 |       path.join(output, String(width), "observed.json"),
  155 |       JSON.stringify(
  156 |         {
  157 |           before,
  158 |           after: {
  159 |             scrollY: await page.evaluate(() => window.scrollY),
  160 |             overflow: await page.evaluate(() => document.body.style.overflow),
  161 |           },
  162 |           errors,
  163 |           readsBefore,
  164 |         },
  165 |         null,
  166 |         2,
  167 |       ) + "\n",
  168 |     );
  169 |   });
  170 | 
```