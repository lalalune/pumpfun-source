# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: competition-refresh.spec.mts >> real-clock list rereads supplied data after60seconds at390px
- Location: tests/browser/competition-refresh.spec.mts:172:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByRole('list', { name: 'Competitions', exact: true }).getByRole('heading', { level: 2 })
Expected: "Synthetic read snapshot 2"
Received: "Synthetic read snapshot 1"
Timeout:  68000ms

Call log:
  - Expect "toHaveText" getByRole('list', { name: 'Competitions', exact: true }).getByRole('heading', { level: 2 }) with timeout 68000ms
  - waiting for getByRole('list', { name: 'Competitions', exact: true }).getByRole('heading', { level: 2 })
    139 × locator resolved to <h2>Synthetic read snapshot 1</h2>
        - unexpected value "Synthetic read snapshot 1"

```

```yaml
- heading "Synthetic read snapshot 1" [level=2]
```

# Test source

```ts
  101 |           finishedAtMs: Date.now(),
  102 |           unexpected,
  103 |           responses,
  104 |           native: await fixture.command("snapshot"),
  105 |         },
  106 |         null,
  107 |         2,
  108 |       ) + "\n",
  109 |     );
  110 |     expect(unexpected).toEqual([]);
  111 |     expect(await page.content()).not.toContain(`pf_live_${"A".repeat(49)}`);
  112 |   };
  113 | }
  114 | async function foreground(page: any) {
  115 |   await page.bringToFront();
  116 |   await expect
  117 |     .poll(() =>
  118 |       page.evaluate(
  119 |         () => document.visibilityState === "visible" && document.hasFocus(),
  120 |       ),
  121 |     )
  122 |     .toBe(true);
  123 | }
  124 | 
  125 | test("real-clock detail rereads supplied data after15seconds at1280px", async ({
  126 |   page,
  127 | }, info) => {
  128 |   await page.setViewportSize({ width: 1280, height: 844 });
  129 |   const finish = await observe(page, info);
  130 |   try {
  131 |     await page.goto(
  132 |       "/leaderboard?category=competitions&competition=" + fixture.slug,
  133 |     );
  134 |     await foreground(page);
  135 |     const amount = page
  136 |       .getByRole("list", { name: "Competition rankings" })
  137 |       .locator(".ranking-metric > strong");
  138 |     await expect(amount).toHaveText("$100.00");
  139 |     await fixture.command("advance");
  140 |     const actual = await (
  141 |       await fetch(
  142 |         fixture.adapterUrl +
  143 |           "/api/leaderboard?category=competitions&id=" +
  144 |           fixture.slug,
  145 |       )
  146 |     ).json();
  147 |     expect(actual.ok).toBe(true);
  148 |     expect(actual.data.entries[0].pnlUsd).toBe(200);
  149 |     await writeFile(
  150 |       info.outputPath("changed-backend-response.json"),
  151 |       JSON.stringify(actual, null, 2) + "\n",
  152 |     );
  153 |     await page.screenshot({
  154 |       path: info.outputPath("before-refresh.png"),
  155 |       fullPage: true,
  156 |     });
  157 |     await expect(amount).toHaveText("$200.00", { timeout: 22_000 });
  158 |     await page.screenshot({
  159 |       path: info.outputPath("after-refresh.png"),
  160 |       fullPage: true,
  161 |     });
  162 |     expect(
  163 |       await page.evaluate(
  164 |         () => document.documentElement.scrollWidth <= innerWidth,
  165 |       ),
  166 |     ).toBe(true);
  167 |   } finally {
  168 |     await finish();
  169 |   }
  170 | });
  171 | 
  172 | test("real-clock list rereads supplied data after60seconds at390px", async ({
  173 |   page,
  174 | }, info) => {
  175 |   await page.setViewportSize({ width: 390, height: 844 });
  176 |   const finish = await observe(page, info);
  177 |   try {
  178 |     await page.goto("/leaderboard?category=competitions&status=live");
  179 |     await foreground(page);
  180 |     const title = page
  181 |       .getByRole("list", { name: "Competitions", exact: true })
  182 |       .getByRole("heading", { level: 2 });
  183 |     await expect(title).toHaveText("Synthetic read snapshot 1");
  184 |     await fixture.command("advance");
  185 |     const actual = await (
  186 |       await fetch(
  187 |         fixture.adapterUrl +
  188 |           "/api/leaderboard?category=competitions&status=live",
  189 |       )
  190 |     ).json();
  191 |     expect(actual.ok).toBe(true);
  192 |     expect(actual.data.live[0].title).toBe("Synthetic read snapshot 2");
  193 |     await writeFile(
  194 |       info.outputPath("changed-backend-response.json"),
  195 |       JSON.stringify(actual, null, 2) + "\n",
  196 |     );
  197 |     await page.screenshot({
  198 |       path: info.outputPath("before-refresh.png"),
  199 |       fullPage: true,
  200 |     });
> 201 |     await expect(title).toHaveText("Synthetic read snapshot 2", {
      |                         ^ Error: expect(locator).toHaveText(expected) failed
  202 |       timeout: 68_000,
  203 |     });
  204 |     await page.screenshot({
  205 |       path: info.outputPath("after-refresh.png"),
  206 |       fullPage: true,
  207 |     });
  208 |     expect(
  209 |       await page.evaluate(
  210 |         () => document.documentElement.scrollWidth <= innerWidth,
  211 |       ),
  212 |     ).toBe(true);
  213 |   } finally {
  214 |     await finish();
  215 |   }
  216 | });
  217 | 
  218 | test("actual foreground pause, error/Retry and unmount retain request ownership", async ({
  219 |   page,
  220 |   context,
  221 | }, info) => {
  222 |   const finish = await observe(page, info);
  223 |   try {
  224 |     await page.goto(
  225 |       "/leaderboard?category=competitions&competition=" + fixture.slug,
  226 |     );
  227 |     await foreground(page);
  228 |     const amount = page
  229 |       .getByRole("list", { name: "Competition rankings" })
  230 |       .locator(".ranking-metric > strong");
  231 |     await expect(amount).toHaveText("$100.00");
  232 |     const before = (await fixture.command("snapshot")).ledger.length;
  233 |     const other = await context.newPage();
  234 |     await other.bringToFront();
  235 |     await expect
  236 |       .poll(() => page.evaluate(() => document.hasFocus()))
  237 |       .toBe(false);
  238 |     await fixture.command("advance");
  239 |     await page.waitForTimeout(17_000); // Real elapsed time; no virtual clock or timer shim.
  240 |     expect((await fixture.command("snapshot")).ledger.length).toBe(before);
  241 |     await expect(amount).toHaveText("$100.00");
  242 |     await other.close();
  243 |     await foreground(page);
  244 |     await expect(amount).toHaveText("$200.00", { timeout: 22_000 });
  245 |     await fixture.command("stop-backend");
  246 |     await expect(page.getByTestId("leaderboard-error")).toBeVisible({
  247 |       timeout: 22_000,
  248 |     });
  249 |     await expect(
  250 |       page.getByRole("list", { name: "Competition rankings" }),
  251 |     ).toHaveCount(0);
  252 |     await page.screenshot({
  253 |       path: info.outputPath("upstream-error.png"),
  254 |       fullPage: true,
  255 |     });
  256 |     await fixture.command("start-backend");
  257 |     await page.getByRole("button", { name: "Retry", exact: true }).click();
  258 |     await expect(amount).toHaveText("$200.00");
  259 |     await page.goto("/fees");
  260 |     await expect(
  261 |       page.getByRole("heading", { name: /Fees/i, level: 1 }),
  262 |     ).toBeVisible();
  263 |     const afterUnmount = (await fixture.command("snapshot")).ledger.length;
  264 |     await page.waitForTimeout(17_000);
  265 |     expect((await fixture.command("snapshot")).ledger.length).toBe(
  266 |       afterUnmount,
  267 |     );
  268 |   } finally {
  269 |     await finish();
  270 |   }
  271 | });
  272 | 
```