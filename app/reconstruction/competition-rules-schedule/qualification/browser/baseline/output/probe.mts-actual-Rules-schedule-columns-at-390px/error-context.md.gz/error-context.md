# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: probe.mts >> actual Rules schedule columns at 390px
- Location: app/reconstruction/competition-rules-schedule/probe.mts:45:3

# Error details

```
Error: expect(received).toHaveLength(expected)

Expected length: 1
Received length: 2
Received array:  [{"bottom": 308, "height": 18, "left": 40, "right": 109.078125, "top": 290, "width": 69.078125}, {"bottom": 329, "height": 18, "left": 40, "right": 48.140625, "top": 311, "width": 8.140625}]
```

# Test source

```ts
  81  |       ),
  82  |     ).toBe(true);
  83  |     await page
  84  |       .getByRole("button", { name: "Schedule, scoring, eligibility and rules" })
  85  |       .click();
  86  |     const dialog = page.getByRole("dialog", { name: "Competition rules" });
  87  |     await expect(dialog).toBeVisible();
  88  |     await page.evaluate(() => document.fonts.ready);
  89  |     const schedule = dialog
  90  |       .locator("section")
  91  |       .filter({
  92  |         has: page.getByRole("heading", { name: "Schedule", exact: true }),
  93  |       })
  94  |       .locator("dl");
  95  |     const measured = await schedule.evaluate((dl) => {
  96  |       const box = (e: Element) => {
  97  |         const r = e.getBoundingClientRect();
  98  |         return {
  99  |           left: r.left,
  100 |           right: r.right,
  101 |           top: r.top,
  102 |           bottom: r.bottom,
  103 |           width: r.width,
  104 |           height: r.height,
  105 |         };
  106 |       };
  107 |       return {
  108 |         bounds: box(dl),
  109 |         clientWidth: dl.clientWidth,
  110 |         scrollWidth: dl.scrollWidth,
  111 |         rows: [...dl.children].map((row) => {
  112 |           const label = row.querySelector("dt")!,
  113 |             value = row.querySelector("dd")!,
  114 |             range = document.createRange();
  115 |           range.selectNodeContents(label);
  116 |           const labelRects = [...range.getClientRects()]
  117 |             .filter((r) => r.width > 0)
  118 |             .map((r) => ({
  119 |               left: r.left,
  120 |               right: r.right,
  121 |               top: r.top,
  122 |               bottom: r.bottom,
  123 |               width: r.width,
  124 |               height: r.height,
  125 |             }));
  126 |           range.selectNodeContents(value);
  127 |           const valueRects = [...range.getClientRects()]
  128 |             .filter((r) => r.width > 0)
  129 |             .map((r) => ({
  130 |               left: r.left,
  131 |               right: r.right,
  132 |               top: r.top,
  133 |               bottom: r.bottom,
  134 |               width: r.width,
  135 |               height: r.height,
  136 |             }));
  137 |           return {
  138 |             label: label.textContent,
  139 |             value: value.textContent,
  140 |             row: box(row),
  141 |             labelBounds: box(label),
  142 |             valueBounds: box(value),
  143 |             labelRects,
  144 |             valueRects,
  145 |             flex: getComputedStyle(value).flex,
  146 |           };
  147 |         }),
  148 |       };
  149 |     });
  150 |     const prize = dialog
  151 |       .locator("section")
  152 |       .filter({
  153 |         has: page.getByRole("heading", {
  154 |           name: "Prize breakdown",
  155 |           exact: true,
  156 |         }),
  157 |       });
  158 |     const prizeData = await prize.evaluate((section) => ({
  159 |       text: section.textContent,
  160 |       rows: [...section.querySelectorAll("dl>div")].map((row) => ({
  161 |         label: row.querySelector("dt")?.textContent,
  162 |         value: row.querySelector("dd")?.textContent,
  163 |         height: row.getBoundingClientRect().height,
  164 |       })),
  165 |     }));
  166 |     await mkdir(path.join(output, String(width)), { recursive: true });
  167 |     await writeFile(
  168 |       path.join(output, String(width), "observed.json"),
  169 |       JSON.stringify({ measured, prizeData, admitted: body, errors }, null, 2) +
  170 |         "\n",
  171 |     );
  172 |     await page.screenshot({
  173 |       path: path.join(output, String(width), "schedule.png"),
  174 |       fullPage: true,
  175 |     });
  176 |     expect(measured.rows.map((row) => row.label)).toEqual([
  177 |       "Registration",
  178 |       "Competition",
  179 |     ]);
  180 |     // Product assertion: the source's column allocation keeps each label word intact.
> 181 |     for (const row of measured.rows) expect(row.labelRects).toHaveLength(1);
      |                                                             ^ Error: expect(received).toHaveLength(expected)
  182 |     expect(measured.scrollWidth).toBeLessThanOrEqual(measured.clientWidth + 1);
  183 |     for (const row of measured.rows) {
  184 |       expect(row.value?.length).toBeGreaterThan(0);
  185 |       for (const rect of row.valueRects) {
  186 |         expect(rect.left).toBeGreaterThanOrEqual(row.valueBounds.left - 0.5);
  187 |         expect(rect.right).toBeLessThanOrEqual(row.valueBounds.right + 0.5);
  188 |       }
  189 |     }
  190 |     expect(errors).toEqual([]);
  191 |     await dialog.getByRole("button", { name: "Close", exact: true }).click();
  192 |     await expect(dialog).not.toBeVisible();
  193 |   });
  194 | 
```