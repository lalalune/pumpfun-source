from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
files=subprocess.check_output(['git','diff','--name-only','094a06f18df738d41e77070c1a009e135671ac1a','HEAD'],cwd=root,text=True).splitlines()
assert len(files)==8
hashes=lambda:{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files}
before=hashes();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
record={'sourceCommit':head,'inputsBefore':before,'startedUTC':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'commands':[]}
commands=[('browser.log',['node','--test','tests/reply_row.browser.mjs']),('evidence.log',['python3','scripts/verify-evidence.py']),('progress.log',['python3','scripts/progress.py','--check'])]
import os
env=dict(os.environ,PUMP_REPLY_ROW_OUTPUT=str(out/'run'))
try:
 for name,cmd in commands:
  with (out/name).open('wb') as log:r=subprocess.run(cmd,cwd=root/'app',env=env,stdout=log,stderr=subprocess.STDOUT)
  record['commands'].append({'argv':cmd,'cwd':'app','log':name,'exitCode':r.returncode})
  (out/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
  if r.returncode:break
finally:
 record['inputsAfter']=hashes();record['unchanged']=record['inputsAfter']==before
 record['finishedUTC']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 record['result']='PASS' if record['unchanged'] and len(record['commands'])==len(commands) and all(x['exitCode']==0 for x in record['commands']) else 'FAIL'
 (out/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['result'],json.dumps(record['commands']))
raise SystemExit(0 if record['result']=='PASS' else 1)
