import hashlib,json,pathlib,subprocess,time
ROOT=pathlib.Path('/workspace/pump-app-social')
WORK=ROOT/'work/callout-card-20261030'
FREEZE='e08451201fecdb052109c917f6dd39a62a550fac'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode().strip()
assert git('rev-parse','HEAD')==FREEZE and not git('status','--porcelain')
paths=git('diff','--name-only','094a06f18df738d41e77070c1a009e135671ac1a',FREEZE).splitlines()
assert len(paths)==8
def seals():
 return [{'path':p,'bytes':len((ROOT/p).read_bytes()),'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),'gitBlob':git('rev-parse',FREEZE+':'+p)} for p in paths]
record={'freeze':FREEZE,'before':seals(),'results':[]}
commands=[('browser',['node','--test','app/tests/callout_card.browser.mjs']),('app-evidence',['python3','app/scripts/verify-evidence.py']),('progress',['python3','app/scripts/progress.py','--check'])]
import os
env=dict(os.environ,PUMP_CALLOUT_CARD_OUTPUT=str(WORK/'run'))
try:
 for name,command in commands:
  start=time.monotonic()
  with (WORK/(name+'.log')).open('wb') as log:result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
  record['results'].append({'name':name,'command':command,'returncode':result.returncode,'seconds':time.monotonic()-start})
  if result.returncode:raise SystemExit(result.returncode)
finally:
 record['after']=seals();record['unchanged']=record['before']==record['after']
 (WORK/'controller.json').write_text(json.dumps(record,indent=2)+'\n')
 assert record['unchanged']
