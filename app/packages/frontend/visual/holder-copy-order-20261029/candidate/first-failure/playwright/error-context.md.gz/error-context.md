# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: holder-rewards.spec.ts >> inspection performs no external request, mutation, wallet prompt or transaction
- Location: tests/holder-rewards.spec.ts:116:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "Failed to load resource: the server responded with a status of 404 (Not Found)",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - link "Skip to main content" [ref=e3] [cursor=pointer]:
      - /url: "#main-content"
    - complementary "Application navigation" [ref=e4]:
      - generic [ref=e6]:
        - generic [ref=e7]:
          - link "Pump reconstruction home" [ref=e8] [cursor=pointer]:
            - /url: /
            - img "pump.fun logomark" [ref=e10]
          - button "Toggle Sidebar" [ref=e11] [cursor=pointer]
        - generic [ref=e14]:
          - navigation "Primary" [ref=e15]:
            - list [ref=e17]:
              - listitem [ref=e18]:
                - link "Home" [ref=e19] [cursor=pointer]:
                  - /url: /
              - listitem [ref=e23]:
                - link "Explore" [ref=e24] [cursor=pointer]:
                  - /url: /explore
              - listitem [ref=e27]:
                - button "Perps" [disabled]
              - listitem [ref=e28]:
                - link "Leaderboard" [ref=e29] [cursor=pointer]:
                  - /url: /leaderboard
              - listitem [ref=e32]:
                - link "Live" [ref=e33] [cursor=pointer]:
                  - /url: /live
            - list [ref=e38]:
              - listitem [ref=e39]:
                - link "GO" [ref=e40] [cursor=pointer]:
                  - /url: /go
              - listitem [ref=e43]:
                - link "Mayhem" [ref=e44] [cursor=pointer]:
                  - /url: /mayhem
              - listitem [ref=e47]:
                - link "Holder rewards" [ref=e48] [cursor=pointer]:
                  - /url: /holder-rewards
              - listitem [ref=e54]:
                - button "$PUMP" [disabled]
              - listitem [ref=e55]:
                - link "Portfolio" [ref=e56] [cursor=pointer]:
                  - /url: /portfolio
          - button "Create a coin" [ref=e60] [cursor=pointer]
        - list [ref=e64]:
          - listitem [ref=e65]:
            - button "Open settings" [ref=e66] [cursor=pointer]
          - listitem [ref=e70]:
            - button "Support (Intercom) is outside this reconstruction" [disabled]
          - listitem [ref=e71]:
            - button "Terminal" [disabled]
        - button "Toggle Sidebar" [ref=e73]
    - generic [ref=e75]:
      - banner [ref=e76]:
        - generic [ref=e78]:
          - generic [ref=e80]:
            - button "Go back" [ref=e81] [cursor=pointer]
            - search [ref=e85]:
              - button "Search for coins and users" [ref=e86] [cursor=pointer]:
                - generic [ref=e87]: Search for coins and users...
                - generic: ⌘K
            - button [disabled] [aria-hidden] [ref=e88]
          - generic [ref=e91]:
            - button "Create" [ref=e93] [cursor=pointer]
            - button "Sign in" [ref=e97] [cursor=pointer]
        - generic [ref=e99]:
          - button "Info bar settings" [disabled] [ref=e100]
          - radiogroup "Info bar content" [ref=e104]:
            - radio "Watchlist" [checked] [ref=e105] [cursor=pointer]
            - radio "Positions" [ref=e108] [cursor=pointer]
            - radio "Following" [ref=e111] [cursor=pointer]
            - radio "Recently viewed" [ref=e115] [cursor=pointer]
      - main [ref=e180]:
        - paragraph [ref=e181]: Pump reconstruction
        - heading "Holder rewards" [level=1] [ref=e182]
        - paragraph [ref=e183]: Derive a holder-rewards PDA locally and optionally inspect its public account holdings. Reward eligibility and claims remain unavailable.
        - generic [ref=e184]:
          - generic [ref=e185]:
            - generic [ref=e186]:
              - generic [ref=e187]:
                - heading "Inspect a holder-rewards address" [level=2] [ref=e188]
                - paragraph [ref=e189]: Enter a Solana mint to compute its deterministic Pump holder-rewards PDA. Computation stays in this browser and does not query the chain.
              - generic [ref=e190]: Offline SDK computation
            - generic [ref=e191]:
              - text: Solana mint address
              - paragraph [ref=e192]: Whitespace is trimmed. A syntactically valid address does not prove that a mint or rewards account exists.
              - generic [ref=e193]:
                - textbox "Solana mint address" [ref=e194]:
                  - /placeholder: Enter a Base58 public key
                  - text: So11111111111111111111111111111111111111112
                - button "Derive address" [ref=e195] [cursor=pointer]
                - button "Clear" [ref=e196] [cursor=pointer]
          - region [ref=e197]:
            - generic [ref=e198]:
              - heading "Local derivation result" [level=2] [ref=e199]
              - generic [ref=e200]: Computed locally
            - generic [ref=e201]:
              - generic [ref=e202]:
                - paragraph [ref=e203]: Normalized mint
                - generic [ref=e204]:
                  - status [ref=e205]: So11111111111111111111111111111111111111112
                  - button "Copy normalized mint" [active] [ref=e206] [cursor=pointer]: Copy
              - generic [ref=e207]:
                - paragraph [ref=e208]: Holder-rewards PDA
                - generic [ref=e209]:
                  - status [ref=e210]: 54SthQvXp5vQrse2JBjVUgsZVU3RrCtPAKQhqcn7XJnh
                  - button "Copy holder-rewards pda" [ref=e211] [cursor=pointer]: Copy
            - paragraph [ref=e212]:
              - text: "SDK derivation: seeds"
              - code [ref=e213]: "[\"holder-rewards\", mint]"
              - text: under the Pump program ID.
          - region [ref=e214]:
            - heading "Public holder-reward configuration" [level=2] [ref=e215]
            - paragraph [ref=e216]: Inspect the program's public Global and curve account records for this mint. Stored flags describe configuration; they do not establish reward eligibility, payout amounts or whether a transaction could succeed.
            - button "Read public configuration" [ref=e217] [cursor=pointer]
          - region [ref=e218]:
            - heading "Public balances at the derived address" [level=2] [ref=e219]
            - paragraph [ref=e220]: Optionally query public Solana mainnet data for this PDA. These are account holdings, not accrued, claimed or claimable rewards. Zero balances do not establish whether an account exists or whether a coin participates in Holder Rewards.
            - button "Read public PDA balances" [ref=e221] [cursor=pointer]
          - region [ref=e222]:
            - generic [ref=e223]:
              - heading "Reward status" [level=2] [ref=e224]
              - paragraph [ref=e225]: These values remain unknown without authenticated live data.
            - generic [ref=e226]:
              - generic [ref=e227]:
                - paragraph [ref=e228]: Accrued rewards
                - paragraph [ref=e229]: Unavailable
                - paragraph [ref=e230]: Requires authenticated on-chain or service data.
              - generic [ref=e231]:
                - paragraph [ref=e232]: Claimed rewards
                - paragraph [ref=e233]: Unavailable
                - paragraph [ref=e234]: No payout history is loaded in this inspector.
              - generic [ref=e235]:
                - paragraph [ref=e236]: Claimable rewards
                - paragraph [ref=e237]: Unavailable
                - paragraph [ref=e238]: A derived PDA does not establish eligibility or balance.
          - region [ref=e239]:
            - heading "Rewards trust boundary" [level=2] [ref=e240]
            - list [ref=e241]:
              - listitem [ref=e242]: Mint existence and Pump-coin status are not checked.
              - listitem [ref=e243]: Rewards configuration, ownership, accrual and eligibility are unknown.
              - listitem [ref=e244]: No wallet is connected and no transaction can be signed or submitted.
            - button "Claim unavailable" [disabled] [ref=e245]
          - status [ref=e246]: Normalized mint copied.
          - paragraph [aria-hidden] [ref=e247]: Normalized mint copied.
      - contentinfo [ref=e248]:
        - generic [ref=e249]:
          - paragraph [ref=e250]: © Pump.fun 2026
          - navigation "Footer" [ref=e251]:
            - link "Blog" [ref=e252] [cursor=pointer]:
              - /url: https://medium.com/@pumpdotfun_
            - button "Resources" [ref=e253] [cursor=pointer]
            - button "Legal" [ref=e256] [cursor=pointer]
          - generic [ref=e259]:
            - link "X" [ref=e260] [cursor=pointer]:
              - /url: https://twitter.com/pumpfun
            - link "TikTok" [ref=e263] [cursor=pointer]:
              - /url: https://www.tiktok.com/@pump.fun
            - link "YouTube" [ref=e266] [cursor=pointer]:
              - /url: https://www.youtube.com/@pumpfunofficial
  - button "Open Next.js Dev Tools" [ref=e274] [cursor=pointer]
  - alert [ref=e278]
```

# Test source

```ts
  40  |   await expect(page.locator("#holder-rewards-mint-error")).toHaveText("Enter a Solana mint address.");
  41  |   await expect(input).toHaveAttribute("aria-invalid", "true");
  42  |   await expect(input).toHaveAttribute("aria-describedby", /holder-rewards-mint-error/);
  43  | 
  44  |   for (const invalid of ["not base58 0OIl", "111", "1".repeat(45)]) {
  45  |     await input.fill(invalid);
  46  |     await page.getByRole("button", { name: "Derive address" }).click();
  47  |     await expect(page.locator("#holder-rewards-mint-error")).toContainText("valid Base58 Solana public key");
  48  |     await expect(page.getByTestId("holder-rewards-result")).toHaveCount(0);
  49  |   }
  50  | });
  51  | 
  52  | test("edits invalidate stale results and clear resets the inspector", async ({ page }) => {
  53  |   await page.goto("/holder-rewards");
  54  |   await derive(page);
  55  |   await expect(page.getByText(PDA, { exact: true })).toBeVisible();
  56  |   await mintInput(page).fill("11111111111111111111111111111111");
  57  |   await expect(page.getByTestId("holder-rewards-result")).toHaveCount(0);
  58  |   await page.getByRole("button", { name: "Derive address" }).click();
  59  |   await expect(page.getByText("Cxpv3PFKz8jFfeQHUFQRTXCyNUz6WScMG8XrM8wLwBun", { exact: true })).toBeVisible();
  60  |   await page.getByRole("button", { name: "Clear" }).click();
  61  |   await expect(mintInput(page)).toHaveValue("");
  62  |   await expect(page.getByTestId("holder-rewards-no-result")).toBeVisible();
  63  | });
  64  | 
  65  | test("copy controls are keyboard reachable and announce their result", async ({ page, context }) => {
  66  |   await context.grantPermissions(["clipboard-read", "clipboard-write"], {
  67  |     origin: "http://127.0.0.1:3010",
  68  |   });
  69  |   await page.goto("/holder-rewards");
  70  |   await derive(page);
  71  |   const copy = page.getByRole("button", { name: "Copy holder-rewards pda" });
  72  |   await copy.focus();
  73  |   await expect(copy).toBeFocused();
  74  |   await page.keyboard.press("Enter");
  75  |   await expect(page.locator('p[aria-hidden="true"]').filter({ hasText: "Holder-rewards PDA copied." })).toBeVisible();
  76  |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(PDA);
  77  | });
  78  | 
  79  | test("form can be completed with the keyboard and preserves shell navigation", async ({ page }) => {
  80  |   await page.goto("/");
  81  |   await page.getByRole("link", { name: "Holder rewards" }).click();
  82  |   await expect(page).toHaveURL(/\/holder-rewards$/);
  83  |   await mintInput(page).focus();
  84  |   await page.keyboard.type(MINT);
  85  |   await page.keyboard.press("Enter");
  86  |   await expect(page.getByText(PDA, { exact: true })).toBeVisible();
  87  | 
  88  |   await page.setViewportSize({ width: 390, height: 844 });
  89  |   await page.goto("/");
  90  |   await page.getByRole("button", { name: "Open navigation" }).click();
  91  |   await page.getByRole("link", { name: "Holder rewards" }).click();
  92  |   await expect(page).toHaveURL(/\/holder-rewards$/);
  93  |   await expect(mintInput(page)).toBeVisible();
  94  | });
  95  | 
  96  | test("target viewports have no horizontal overflow", async ({ page }) => {
  97  |   for (const [width, height] of [
  98  |     [1440, 900],
  99  |     [1280, 800],
  100 |     [768, 1024],
  101 |     [390, 844],
  102 |     [375, 667],
  103 |   ] as const) {
  104 |     await page.setViewportSize({ width, height });
  105 |     await page.goto("/holder-rewards");
  106 |     await derive(page);
  107 |     await expect(page.getByText(PDA, { exact: true })).toBeVisible();
  108 |     const dimensions = await page.evaluate(() => ({
  109 |       clientWidth: document.documentElement.clientWidth,
  110 |       scrollWidth: document.documentElement.scrollWidth,
  111 |     }));
  112 |     expect(dimensions.scrollWidth, `${width}px`).toBeLessThanOrEqual(dimensions.clientWidth);
  113 |   }
  114 | });
  115 | 
  116 | test("inspection performs no external request, mutation, wallet prompt or transaction", async ({ page, context }) => {
  117 |   const violations: string[] = [];
  118 |   const consoleErrors: string[] = [];
  119 |   page.on("console", (message) => {
  120 |     if (message.type() === "error") consoleErrors.push(message.text());
  121 |   });
  122 |   page.on("request", (request) => {
  123 |     const url = new URL(request.url());
  124 |     if (url.origin !== "http://127.0.0.1:3010" || !["GET", "HEAD"].includes(request.method())) {
  125 |       violations.push(`${request.method()} ${request.url()}`);
  126 |     }
  127 |   });
  128 | 
  129 |   await context.grantPermissions(["clipboard-read", "clipboard-write"], {
  130 |     origin: "http://127.0.0.1:3010",
  131 |   });
  132 |   await page.goto("/holder-rewards");
  133 |   await derive(page);
  134 |   await page.getByRole("button", { name: "Copy normalized mint" }).click();
  135 |   await expect(page.locator('p[aria-hidden="true"]').filter({ hasText: "Normalized mint copied." })).toBeVisible();
  136 |   await expect(page.getByText(/connect wallet/i)).toHaveCount(0);
  137 |   await expect(page.getByText(/transaction submitted/i)).toHaveCount(0);
  138 | 
  139 |   expect(violations).toEqual([]);
> 140 |   expect(consoleErrors).toEqual([]);
      |                         ^ Error: expect(received).toEqual(expected) // deep equality
  141 | });
  142 | 
```