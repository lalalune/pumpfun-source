# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: holder-copy-order.spec.ts >> editing the mint discards an earlier copy success announcement
- Location: tests/holder-copy-order.spec.ts:57:5

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByTestId('holder-rewards-inspector').locator(':scope > p[role="status"]')
Expected: ""
Received: "Normalized mint copied."
Timeout:  5000ms

Call log:
  - Expect "toHaveText" getByTestId('holder-rewards-inspector').locator(':scope > p[role="status"]') with timeout 5000ms
  - waiting for getByTestId('holder-rewards-inspector').locator(':scope > p[role="status"]')
    14 × locator resolved to <p role="status" class="sr-only" aria-live="polite">Normalized mint copied.</p>
       - unexpected value "Normalized mint copied."

```

```yaml
- status: Normalized mint copied.
```

# Test source

```ts
  1  | import { expect, test, type Page } from "@playwright/test";
  2  | 
  3  | const MINT = "So11111111111111111111111111111111111111112";
  4  | const OTHER = "11111111111111111111111111111111";
  5  | 
  6  | type ClipboardWrite = {
  7  |   value: string;
  8  |   resolve: () => void;
  9  |   reject: () => void;
  10 | };
  11 | declare global {
  12 |   interface Window {
  13 |     __delayedClipboardWrites: ClipboardWrite[];
  14 |   }
  15 | }
  16 | 
  17 | async function derive(page: Page) {
  18 |   await page.getByLabel("Solana mint address", { exact: true }).fill(MINT);
  19 |   await page.getByRole("button", { name: "Derive address", exact: true }).click();
  20 |   await expect(page.getByTestId("holder-rewards-result")).toBeVisible();
  21 | }
  22 | 
  23 | const feedback = (page: Page) =>
  24 |   page.getByTestId("holder-rewards-inspector").locator(':scope > p[role="status"]');
  25 | 
  26 | async function settle(page: Page, outcome: "resolve" | "reject") {
  27 |   await page.evaluate(async (outcome) => {
  28 |     window.__delayedClipboardWrites[0][outcome]();
  29 |     // Let the native Promise continuation and React's resulting render finish.
  30 |     await new Promise<void>((done) =>
  31 |       requestAnimationFrame(() => requestAnimationFrame(() => done())),
  32 |     );
  33 |   }, outcome);
  34 | }
  35 | 
  36 | test.beforeEach(async ({ page }) => {
  37 |   await page.addInitScript(() => {
  38 |     window.__delayedClipboardWrites = [];
  39 |     Object.defineProperty(navigator, "clipboard", {
  40 |       configurable: true,
  41 |       value: {
  42 |         writeText: (value: string) =>
  43 |           new Promise<void>((resolve, reject) => {
  44 |             window.__delayedClipboardWrites.push({
  45 |               value,
  46 |               resolve,
  47 |               reject: () => reject(new DOMException("Denied", "NotAllowedError")),
  48 |             });
  49 |           }),
  50 |       },
  51 |     });
  52 |   });
  53 |   await page.goto("/holder-rewards");
  54 |   await derive(page);
  55 | });
  56 | 
  57 | test("editing the mint discards an earlier copy success announcement", async ({ page }) => {
  58 |   await page.getByRole("button", { name: "Copy normalized mint", exact: true }).click();
  59 |   await expect.poll(() => page.evaluate(() => window.__delayedClipboardWrites.length)).toBe(1);
  60 |   expect(await page.evaluate(() => window.__delayedClipboardWrites[0].value)).toBe(MINT);
  61 |   await page.getByLabel("Solana mint address", { exact: true }).fill(OTHER);
  62 |   await expect(page.getByTestId("holder-rewards-no-result")).toBeVisible();
  63 |   await settle(page, "resolve");
> 64 |   await expect(feedback(page)).toHaveText("");
     |                                ^ Error: expect(locator).toHaveText(expected) failed
  65 |   await expect(page.getByTestId("holder-rewards-inspector")).not.toContainText("Normalized mint copied.");
  66 | });
  67 | 
  68 | test("Clear keeps its current announcement when an earlier clipboard request rejects", async ({ page }) => {
  69 |   await page.getByRole("button", { name: "Copy holder-rewards pda", exact: true }).click();
  70 |   await expect.poll(() => page.evaluate(() => window.__delayedClipboardWrites.length)).toBe(1);
  71 |   await page.getByRole("button", { name: "Clear", exact: true }).click();
  72 |   await expect(feedback(page)).toHaveText("Inspector cleared.");
  73 |   await settle(page, "reject");
  74 |   await expect(feedback(page)).toHaveText("Inspector cleared.");
  75 |   await expect(page.getByTestId("holder-rewards-inspector")).not.toContainText("Could not copy");
  76 | });
  77 | 
  78 | test("a new derivation discards feedback from a copy started in the previous result", async ({ page }) => {
  79 |   await page.getByRole("button", { name: "Copy normalized mint", exact: true }).click();
  80 |   await expect.poll(() => page.evaluate(() => window.__delayedClipboardWrites.length)).toBe(1);
  81 |   await page.getByRole("button", { name: "Derive address", exact: true }).click();
  82 |   await expect(feedback(page)).toHaveText("");
  83 |   await settle(page, "resolve");
  84 |   await expect(feedback(page)).toHaveText("");
  85 | });
  86 | 
```