"""Bounded control of the pinned compiler's existing reverse-local option."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;W=D.parent;S=W/'pump-v3-scheduler';L=W/'l18'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    inventory=read(L/'source-inventory.json')
    paths=['llvm/lib/CodeGen/RegAllocGreedy.cpp','llvm/include/llvm/CodeGen/TargetRegisterInfo.h','llvm/lib/Target/SBF/SBFRegisterInfo.h','llvm/lib/Target/SBF/SBFSubtarget.h','llvm/lib/CodeGen/TargetSubtargetInfo.cpp','llvm/lib/Target/SBF/SBFTargetMachine.cpp']
    pins={p:sha(L/'source'/p) for p in paths};assert all(pins[p]==inventory[p] for p in paths)
    save(D/'hypothesis.json',dict(llvm_revision='08aedd64bf3abe4f163407b7bcf680403b84b32d',sources=pins,prediction='ReverseLocalAssignment uses distance from zero to interval end. On the scheduler-reversed profile pair %101 ends at6400 and %100 at6384, so it should restore field0=r1 and field8=r2. Global output consequences unknown. Off controls must reproduce existing complete objects.',scope='Existing stock allocator option. The final control still uses the private scheduler derivative; none proves original flags, recovered source or behavior.'))
    cases=[(m,r,False) for m in ['baseline','frequency'] for r in [False,True]]+[('frequency',True,True)]
    for mode,reverse,scheduler in cases:
        prior=S/('counterfactual-frequency-on' if scheduler else 'stock-'+mode);parent=read(prior/'launch.json');old=read(prior/'result.json')
        inp=Path(parent['command'][8]);tool=Path(parent['command'][0]);assert sha(inp)==parent['input_sha256'] and sha(tool)==parent['tool_sha256'] and sha(prior/'target.o')==old['object_sha256']
        name=mode+'-reverse'+str(int(reverse))+'-scheduler'+str(int(scheduler));out=D/name;out.mkdir()
        cmd=parent['command'][:11];cmd[10]=str(out/'target.o')
        if scheduler:cmd+=['-v3-diagnostic-reverse-loads']
        cmd+=['-greedy-reverse-local-assignment='+str(reverse).lower(),'-debug-only=regalloc','-print-before=greedy','-print-after=greedy,virtregrewriter','-filter-print-funcs='+SYMBOL]
        launch=dict(command=cmd,cwd=str(D),environment=parent['environment'],tool_sha256=sha(tool),input_sha256=sha(inp),parent_launch_sha256=sha(prior/'launch.json'),parent_object_sha256=sha(prior/'target.o'),controller_sha256=sha(Path(__file__)),target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            process=subprocess.run(cmd,cwd=D,env=parent['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        obj=out/'target.o';row=dict(returncode=process.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==launch['input_sha256'],tool_unchanged=sha(tool)==launch['tool_sha256'],object_sha256=sha(obj) if obj.exists() else None,whole_parent_object_equal=obj.read_bytes()==(prior/'target.o').read_bytes() if obj.exists() else False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
        save(out/'result.json',row);print(json.dumps(dict(name=name,**row)),flush=True)
        assert row['returncode']==0 and row['tool_unchanged'] and row['input_unchanged']
        if not reverse:assert row['whole_parent_object_equal']
    assert all(sha(L/'source'/p)==pins[p] for p in paths)
if __name__=='__main__':main()
