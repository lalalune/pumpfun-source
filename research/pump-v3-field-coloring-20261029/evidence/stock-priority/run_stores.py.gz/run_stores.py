"""Revisit the retained store-order control with the existing allocator option."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,time
D=Path(__file__).resolve().parent;W=D.parent;N=W/'pump-v3-net-tail';F=W/'pump-v3-cost-model/ir01'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    spec=importlib.util.spec_from_file_location('retained_store_control',N/'run_store_order02.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    for mode in ['baseline','frequency']:
      prior=N/('store02-'+mode);p=read(prior/'launch.json');r=read(prior/'result.json');inp=Path(p['command'][8]);tool=Path(p['command'][0])
      parent=(F/mode/'input.ll').read_bytes();assert parent.count(old.PAIR)==1 and inp.read_bytes()==parent.replace(old.PAIR,old.REVERSED)
      assert sha(inp)==p['input_sha256'] and sha(tool)==p['tool_sha256']=='aff85aa14d18e21b98f6e17f9e4b80c26c5ed0948b9641af46d73881a3c2ab6d' and sha(prior/'target.o')==r['object_sha256']
      for reverse in [False,True]:
        name='stores-'+mode+'-reverse'+str(int(reverse));out=D/name;out.mkdir();cmd=p['command'][:11];cmd[10]=str(out/'target.o')
        cmd+=['-greedy-reverse-local-assignment='+str(reverse).lower(),'-debug-only=isel-dump,pre-RA-sched,regalloc','-print-before=greedy','-print-after=greedy,virtregrewriter','-filter-print-funcs='+SYMBOL]
        l=dict(command=cmd,cwd=str(D),environment=p['environment'],tool_sha256=sha(tool),input_sha256=sha(inp),parent_launch_sha256=sha(prior/'launch.json'),parent_object_sha256=sha(prior/'target.o'),controller_sha256=sha(Path(__file__)),scope='Unmodified stock compiler with explicit reverse-local option; retained synthetic IR store order, plus synthetic profile in frequency mode. No recovered source or original compiler provenance.',target_executions=0);save(out/'launch.json',l);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            process=subprocess.run(cmd,cwd=D,env=p['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        obj=out/'target.o';row=dict(returncode=process.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==l['input_sha256'],tool_unchanged=sha(tool)==l['tool_sha256'],object_sha256=sha(obj) if obj.exists() else None,whole_parent_object_equal=obj.read_bytes()==(prior/'target.o').read_bytes() if obj.exists() else False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
        save(out/'result.json',row);print(json.dumps(dict(name=name,**row)),flush=True)
        assert row['returncode']==0 and row['tool_unchanged'] and row['input_unchanged']
        if not reverse:assert row['whole_parent_object_equal']
if __name__=='__main__':main()
