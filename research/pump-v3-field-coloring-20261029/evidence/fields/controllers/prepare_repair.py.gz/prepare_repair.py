"""Retain the failed priority query; recompute only its already-qualified local term."""
from pathlib import Path
D=Path(__file__).resolve().parent
s=(D/'field_patch.py').read_text()
s=s.replace('<< LIS->intervalIsInOneMBB(*LI)','<< bool(LIS->intervalIsInOneMBB(*LI))')
a='      unsigned NewRet = PriorityAdvisor->getPriority(LIS->getInterval(Other));'
b='''      // The other register has not necessarily been enqueued yet: querying
      // its full advisor reads an uninitialized stage. Reuse the same proven
      // local-range distance formula, without mutating the other stage.
      const LiveInterval &OtherLI = LIS->getInterval(Other);
      assert(!ReverseLocalAssignment && !VRM->hasKnownPreference(Other) &&
             LIS->intervalIsInOneMBB(OtherLI) == LIS->intervalIsInOneMBB(*LI) &&
             "exact-input local priority prerequisites");
      unsigned Distance = OtherLI.beginIndex().getApproxInstrDistance(Indexes->getLastIndex());
      unsigned NewRet = (Ret & 0xff000000u) | std::min(Distance, (unsigned)maxUIntN(24));'''
assert s.count(a)==1;s=s.replace(a,b)
p=D/'field_patch02.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
s=(D/'build_probe.py').read_text();assert s.count("O=D/'derivative01'")==1
s=s.replace("O=D/'derivative01'","O=D/'derivative02'").replace("D/'field_patch.py'","D/'field_patch02.py'")
p=D/'build_probe02.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
s=(D/'run_probe.py').read_text().replace("D/'derivative01/","D/'derivative02/").replace("out=D/name;","out=D/('repaired-'+name);")
p=D/'run_probe02.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
