"""Package retained diagnostics and failures; never execute them during replay."""
from pathlib import Path
import gzip,hashlib,json,shutil
D=Path(__file__).resolve().parent;W=D.parent;S=W/'pump-v3-scheduler';L=W/'l18';R=W/'pumpfun-source';P=R/'research/pump-v3-field-coloring-20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    P.mkdir(exist_ok=True);mapping={}
    def add(key,path):
        b=path.read_bytes();p=P/'evidence'/(key+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,mtime=0));mapping[key]=dict(file=p.relative_to(P).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    runs=['stock-baseline','stock-frequency','probe-baseline','probe-frequency','counterfactual-baseline-off','counterfactual-baseline-on','counterfactual-frequency-off','counterfactual-frequency-on','stages-off','stages-on','postra-baseline','postra-frequency']
    for group,root,names in [('scheduler',S,runs),('fields',D,['trace-off','trace-on']+[f'{prefix}scheduler{s}-priority{p}' for prefix in ['','repaired-'] for s,p in [(0,0),(1,0),(0,1),(1,1)]])]:
        for name in names:
            for n in ['launch.json','result.json','stdout.log','stderr.log','target.o']:
                if (root/name/n).exists():add(group+'/'+name+'/'+n,root/name/n)
    for n in ['capture.py','run_probe.py','run_counterfactual.py','capture_stages.py','run_postra.py','build_probe.py','build_counterfactual.py','counterfactual_patch.py','prepare_probe.py','prepare_counterfactual.py','analyze.py']:
        add('scheduler/controllers/'+n,S/n)
    for n in ['capture.py','run_probe.py','run_probe02.py','build_probe.py','build_probe02.py','field_patch.py','field_patch02.py','prepare_builder.py','prepare_repair.py','package.py']:
        add('fields/controllers/'+n,D/n)
    for group,root in [('scheduler',S),('fields',D)]:
        for derivative in ['derivative01','derivative02']:
            folder=root/derivative
            for p in folder.iterdir():
                # Keep source, recipes, inventories, build logs and response
                # provenance. Host executables/libraries/objects are not replayed.
                if p.is_file() and p.suffix not in ['.exe','.lib','.obj','.pdb','.exp']:
                    add(group+'/'+derivative+'/'+p.name,p)
    add('fields/failure-driver.log',D/'probe.log');add('fields/failure-driver.err',D/'probe.err')
    add('scheduler/analysis.json',S/'analysis.json');add('scheduler/stage-evidence.json',S/'stage-evidence.json')
    for rel in ['llvm/lib/CodeGen/SelectionDAG/ScheduleDAGRRList.cpp','llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp','llvm/lib/CodeGen/RegAllocGreedy.cpp','llvm/lib/CodeGen/AllocationOrder.cpp','llvm/lib/CodeGen/RegAllocBase.cpp','llvm/include/llvm/CodeGen/SlotIndexes.h','llvm/lib/Target/SBF/SBFISelLowering.cpp']:
        add('compiler/'+rel,L/'source'/rel)
    parent=R/'research/pump-v3-regalloc-20261029'
    provenance=dict(parent_packet=parent.name,parent_manifest_sha256=sha(parent/'MANIFEST.json'),llvm_revision='08aedd64bf3abe4f163407b7bcf680403b84b32d',rust_revision='08b7341888ab480dfaaa0698300cbbbbb2d75b53',original_sha256=sha(R/'evidence/original/pump/deployed.so'),upstream_base='4068e77accddbfaf26d790573b12bd6a8b7fb535',source_root_commands=0,llc_commands=22,failed_llc_commands=1,private_host_build_commands=12,target_executions=0,scope='Historical compiler receipts and retained emitted objects. Replay runs no build controller, compiler, ELF or VM. Synthetic profile and opt-in scheduling/priority controls are not recovered source or original compiler provenance.')
    for name,value in [('EVIDENCE.json',mapping),('PROVENANCE.json',provenance)]:
        (P/name).write_bytes((json.dumps(value,indent=2)+'\n').encode())
    print(json.dumps(dict(evidence_files=len(mapping),compressed_bytes=sum((P/v['file']).stat().st_size for v in mapping.values())),indent=2))
if __name__=='__main__':main()
