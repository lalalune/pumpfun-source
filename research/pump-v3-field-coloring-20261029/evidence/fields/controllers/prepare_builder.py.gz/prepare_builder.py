from pathlib import Path
D=Path(__file__).resolve().parent;W=D.parent
s=(W/'pump-v3-cost-model/build_cost_probe.py').read_text()
s=s.replace("D/'cost_patch.py'","D/'field_patch.py'").replace('cost_patch_sha256','field_patch_sha256')
s=s.replace('"""Build an isolated, logging-only allocator cost probe from existing stock objects."""','"""Build a default-off field priority probe, retaining the qualified scheduler switch."""')
a='    for command in [compile,archive,link]:'
b='''    scheduler=D.parent/'pump-v3-scheduler/derivative02'
    scheduler_build=json.loads((scheduler/'build-result.json').read_bytes())
    assert scheduler_build['stock_build_unchanged'] and scheduler_build['stock_source_unchanged']
    assert sha(scheduler/'LLVMSelectionDAG.lib')==scheduler_build['outputs']['LLVMSelectionDAG.lib']
    assert link.count(r'lib\\LLVMSelectionDAG.lib')==1
    link=[str(scheduler/'LLVMSelectionDAG.lib') if a==r'lib\\LLVMSelectionDAG.lib' else a for a in link]
'''+a
assert s.count(a)==1;s=s.replace(a,b)
a="    save(O/'build-launch.json',plan);results=[]"
b="    plan['scheduler_parent']=dict(directory=str(scheduler),library_sha256=sha(scheduler/'LLVMSelectionDAG.lib'),build_result_sha256=sha(scheduler/'build-result.json'))\n"+a
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('Logging-only diagnostic of integer split costs for V3 return pointer23.','Default-off logging-only field priority probe, with opt-in exact-input priority swap and inherited scheduler switch.')
p=D/'build_probe.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
