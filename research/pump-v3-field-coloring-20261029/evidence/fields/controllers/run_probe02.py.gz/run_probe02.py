"""Qualify both diagnostic switches independently and jointly on the fixed input."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;S=D.parent/'pump-v3-scheduler'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    tool=D/'derivative02/llc.exe';build=read(D/'derivative02/build-result.json')
    assert sha(tool)==build['outputs']['llc.exe'] and build['stock_source_unchanged'] and build['stock_build_unchanged']
    for sched,priority in [(False,False),(True,False),(False,True),(True,True)]:
        name=f'scheduler{int(sched)}-priority{int(priority)}';prior=D/('trace-on' if sched else 'trace-off');p=read(prior/'launch.json');r=read(prior/'result.json');inp=Path(p['command'][8])
        assert sha(inp)==p['input_sha256'] and sha(prior/'target.o')==r['object_sha256']
        out=D/('repaired-'+name);out.mkdir();cmd=p['command'][:11];cmd[0]=str(tool);cmd[10]=str(out/'target.o')
        if sched:cmd+=['-v3-diagnostic-reverse-loads']
        if priority:cmd+=['-v3-diagnostic-field-priority']
        cmd+=['-debug-only=regalloc','-print-before=greedy','-print-after=greedy,virtregrewriter','-filter-print-funcs='+SYMBOL]
        launch=dict(command=cmd,cwd=str(D),environment=p['environment'],tool_sha256=sha(tool),input_sha256=sha(inp),parent_launch_sha256=sha(prior/'launch.json'),parent_object_sha256=sha(prior/'target.o'),controller_sha256=sha(Path(__file__)),scope='Exact-input isolated compiler diagnostics on inherited synthetic frequency input. Neither switch recovers Rust or original compiler provenance.',target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            process=subprocess.run(cmd,cwd=D,env=p['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        row=dict(returncode=process.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==launch['input_sha256'],tool_unchanged=sha(tool)==launch['tool_sha256'],object_sha256=sha(out/'target.o') if (out/'target.o').exists() else None,whole_parent_object_equal=(out/'target.o').read_bytes()==(prior/'target.o').read_bytes() if (out/'target.o').exists() else False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
        save(out/'result.json',row);print(json.dumps(dict(mode=name,**row),indent=2),flush=True)
        assert process.returncode==0 and row['input_unchanged'] and row['tool_unchanged']
        if not priority or not sched:assert row['whole_parent_object_equal']
if __name__=='__main__':main()
