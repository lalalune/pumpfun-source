"""Log exact priorities/interference and offer an explicit field-pair diagnostic."""
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
def once(s,a,b):assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def patch(text):
    text=once(text,'#define DEBUG_TYPE "regalloc"','#define DEBUG_TYPE "regalloc"\n'+'''
static cl::opt<bool> V3DiagnosticFieldPriority(
    "v3-diagnostic-field-priority", cl::Hidden, cl::init(false),
    cl::desc("Diagnostic only: swap qualified V3 frame17 field priorities"));
''')
    scope='MF->getName() == "'+SYMBOL+'" && (Reg == Register::index2VirtReg(100) || Reg == Register::index2VirtReg(101))'
    a='  unsigned Ret = PriorityAdvisor->getPriority(*LI);'
    b=a+'''
  if ('''+scope+''') {
    LLVM_DEBUG(dbgs() << "FIELD_PROBE enqueue reg=" << printReg(Reg, TRI)
                     << " priority=" << Ret << " size=" << LI->getSize()
                     << " begin=" << LI->beginIndex() << " end=" << LI->endIndex()
                     << " last=" << Indexes->getLastIndex()
                     << " local=" << bool(LIS->intervalIsInOneMBB(*LI))
                     << " preference=" << VRM->hasKnownPreference(Reg)
                     << " stage=" << unsigned(Stage)
                     << " reverse=" << ReverseLocalAssignment << "\\n");
    MachineInstr *A = MRI->getUniqueVRegDef(Register::index2VirtReg(100));
    MachineInstr *B = MRI->getUniqueVRegDef(Register::index2VirtReg(101));
    if (V3DiagnosticFieldPriority && Stage == RS_Assign && A && B &&
        A->getNumOperands() >= 3 && B->getNumOperands() >= 3 &&
        A->getOperand(1).isFI() && B->getOperand(1).isFI() &&
        A->getOperand(1).getIndex() == 17 && B->getOperand(1).getIndex() == 17 &&
        A->getOperand(2).isImm() && B->getOperand(2).isImm() &&
        A->getOperand(2).getImm() == 8 && B->getOperand(2).getImm() == 0) {
      Register Other = Register::index2VirtReg(Reg == Register::index2VirtReg(100) ? 101 : 100);
      // The other register has not necessarily been enqueued yet: querying
      // its full advisor reads an uninitialized stage. Reuse the same proven
      // local-range distance formula, without mutating the other stage.
      const LiveInterval &OtherLI = LIS->getInterval(Other);
      assert(!ReverseLocalAssignment && !VRM->hasKnownPreference(Other) &&
             LIS->intervalIsInOneMBB(OtherLI) == LIS->intervalIsInOneMBB(*LI) &&
             "exact-input local priority prerequisites");
      unsigned Distance = OtherLI.beginIndex().getApproxInstrDistance(Indexes->getLastIndex());
      unsigned NewRet = (Ret & 0xff000000u) | std::min(Distance, (unsigned)maxUIntN(24));
      dbgs() << "V3_FIELD_COUNTERFACTUAL reg=" << printReg(Reg, TRI)
             << " previous=" << Ret << " replacement=" << NewRet << "\\n";
      Ret = NewRet;
    }
  }
'''
    text=once(text,a,b)
    a='''    if (!Matrix->checkInterference(VirtReg, *I)) {'''
    b='''    auto Interference = Matrix->checkInterference(VirtReg, *I);
    LLVM_DEBUG(if (MF->getName() == "'''+SYMBOL+'''" &&
                   (VirtReg.reg() == Register::index2VirtReg(100) ||
                    VirtReg.reg() == Register::index2VirtReg(101)))
      dbgs() << "FIELD_PROBE candidate reg=" << printReg(VirtReg.reg(), TRI)
             << " physical=" << printReg(*I, TRI)
             << " interference=" << unsigned(Interference)
             << " hint=" << I.isHint() << "\\n");
    if (!Interference) {'''
    return once(text,a,b)
