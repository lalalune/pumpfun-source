"""Compare default-off and opt-in scheduler controls to qualified stock outputs."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    tool=D/'derivative02/llc.exe';build=read(D/'derivative02/build-result.json')
    assert sha(tool)==build['outputs']['llc.exe'] and build['stock_source_unchanged'] and build['stock_build_unchanged']
    for mode in ['baseline','frequency']:
      for enabled in [False,True]:
        prior=D/('stock-'+mode);p=read(prior/'launch.json');r=read(prior/'result.json');inp=Path(p['command'][8])
        assert r['complete_object_equal'] and sha(prior/'target.o')==r['object_sha256']
        assert sha(inp)==p['input_sha256'] and sha(Path(p['command'][0]))==p['tool_sha256']
        out=D/('counterfactual-'+mode+('-on' if enabled else '-off'));out.mkdir();cmd=p['command'].copy();cmd[0]=str(tool);cmd[10]=str(out/'target.o')
        if enabled:cmd+=['-v3-diagnostic-reverse-loads']
        launch=dict(command=cmd,cwd=str(D),environment=p['environment'],tool_sha256=sha(tool),input_sha256=sha(inp),parent_launch_sha256=sha(prior/'launch.json'),parent_object_sha256=sha(prior/'target.o'),controller_sha256=sha(Path(__file__)),scope='Opt-in scheduler decision control only; no recovered source, compiler recipe, raw identity or behavior claim.',target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            process=subprocess.run(cmd,cwd=D,env=p['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        row=dict(returncode=process.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==launch['input_sha256'],tool_unchanged=sha(tool)==launch['tool_sha256'],object_sha256=sha(out/'target.o') if (out/'target.o').exists() else None,whole_stock_object_equal=(out/'target.o').read_bytes()==(prior/'target.o').read_bytes() if (out/'target.o').exists() else False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
        save(out/'result.json',row);print(json.dumps(dict(mode=mode,enabled=enabled,**row),indent=2),flush=True)
        assert process.returncode==0 and row['input_unchanged'] and row['tool_unchanged']
        if not enabled:assert row['whole_stock_object_equal']
if __name__=='__main__':main()
