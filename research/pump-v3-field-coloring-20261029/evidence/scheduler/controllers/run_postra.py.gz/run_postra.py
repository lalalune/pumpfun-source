"""One stock compiler configuration control for each qualified frequency input."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    for mode in ['baseline','frequency']:
        prior=D/('stock-'+mode);p=read(prior/'launch.json');r=read(prior/'result.json');inp=Path(p['command'][8]);tool=Path(p['command'][0])
        assert sha(inp)==p['input_sha256'] and sha(tool)==p['tool_sha256'] and sha(prior/'target.o')==r['object_sha256']
        out=D/('postra-'+mode);out.mkdir();cmd=p['command'][:11];cmd[10]=str(out/'target.o');cmd+=['-post-RA-scheduler=true','-debug-only=post-RA-sched','-print-before=post-RA-sched','-print-after=post-RA-sched','-filter-print-funcs=_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E']
        launch=dict(command=cmd,cwd=str(D),environment=p['environment'],tool_sha256=sha(tool),input_sha256=sha(inp),parent_object_sha256=sha(prior/'target.o'),controller_sha256=sha(Path(__file__)),scope='Supported stock LLVM post-RA scheduler configuration diagnostic. Not evidence that the original used this option. Frequency mode retains synthetic profile metadata.',target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            process=subprocess.run(cmd,cwd=D,env=p['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        row=dict(returncode=process.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==launch['input_sha256'],tool_unchanged=sha(tool)==launch['tool_sha256'],object_sha256=sha(out/'target.o') if (out/'target.o').exists() else None,whole_stock_object_equal=(out/'target.o').read_bytes()==(prior/'target.o').read_bytes() if (out/'target.o').exists() else False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
        save(out/'result.json',row);print(json.dumps(dict(mode=mode,**row),indent=2),flush=True)
        assert process.returncode==0 and row['input_unchanged'] and row['tool_unchanged']
if __name__=='__main__':main()
