from pathlib import Path
import shutil
D=Path(__file__).resolve().parent
s=(D/'build_probe.py').read_text()
a="O=Path(__file__).resolve().parent/'derivative01'";assert s.count(a)==1;s=s.replace(a,"O=Path(__file__).resolve().parent/'derivative02'")
a=' assert len(replacements)==20,len(replacements)';assert s.count(a)==1
s=s.replace(a,a+'''
 import importlib.util
 patch_path=Path(__file__).resolve().parent/'counterfactual_patch.py'
 spec=importlib.util.spec_from_file_location('v3_sched_counterfactual',patch_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 modified=module.patch(modified)''')
s=s.replace('Logging-only derivative of one compiler translation unit;','Opt-in exact-input scheduler counterfactual, logging-only when disabled;')
p=D/'build_counterfactual.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
o=D/'derivative02';o.mkdir();shutil.copyfile(D/'derivative01/stock-commands.json',o/'stock-commands.json')
