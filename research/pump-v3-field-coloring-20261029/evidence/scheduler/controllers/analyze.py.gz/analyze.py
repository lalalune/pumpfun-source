"""Independently qualify scheduler traces, counterfactuals and downstream stages."""
if not __debug__:raise SystemExit('Run without -O.')
from pathlib import Path
import hashlib,importlib.util,json,re
D=Path(__file__).resolve().parent;W=D.parent;L=W/'l18';F=W/'pump-v3-cost-model/ir01'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
LABEL='_ZN14pump_recovered5trade12v3_buy_costs28_$u7b$$u7b$closure$u7d$$u7d$17hc52a5d3605a74ae3E.exit'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def load(n,p):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def pointers(text):
    # Strip only printed BasicBlock object addresses. Branch probability hex
    # values and every actual instruction, operand and register are retained.
    return re.sub(r'(BasicBlock:ch<[^\n>]* )0x[0-9a-fA-F]+',r'\1<ADDRESS>',text)
def schedule(text):
    key="********** List Scheduling %bb.27 '"+LABEL+"' **********"
    assert text.count(key)==1
    block=text.split(key,1)[1].split('Initial selection DAG:',1)[0]
    assert 'TargetConstant:i64<375>' in block
    stages=re.findall(r'^\*\*\* Scheduling \[(\d+)\]: SU\((\d+)\): (.*)$',block,re.M)
    assert len(stages)==40
    return block,[dict(cycle=int(c),unit=int(u),instruction=s) for c,u,s in stages]
def machine_stage(text,pid):
    headers=list(re.finditer(r'^# \*\*\* IR Dump After .+ \('+re.escape(pid)+r'\) \*\*\*:',text,re.M));assert len(headers)==1
    rest=text[headers[0].end():];body=rest[:rest.index('# End machine code for function')]
    headers=list(re.finditer(r'^(?:\d+[A-Za-z]\t)?bb\.\d+[^:\n]*:\s*$',body,re.M))
    selected=[]
    for i,h in enumerate(headers):
        if LABEL in h[0]:selected.append(body[h.start():headers[i+1].start() if i+1<len(headers) else len(body)])
    assert len(selected)==1
    block=selected[0];assert re.search(r'STW_imm_V1 [^\n]*375',block)
    calls=list(re.finditer(r'JAL @"_ZN104_[^\n]+From\$LT\$anchor_lang\.\.error\.\.AnchorError[^\n]+',block));assert len(calls)==1
    tail=block[calls[0].end():]
    return dict(header=block.splitlines()[0],block=block,tail=tail,blocks=len(headers))
def run(p,controller):
    l=read(p/'launch.json');r=read(p/'result.json')
    assert r['returncode']==0 and r['target_executions']==0 and r['input_unchanged'] and r['tool_unchanged']
    assert sha(p/'target.o')==r['object_sha256'] and sha(Path(l['command'][8]))==l['input_sha256'] and sha(Path(l['command'][0]))==l['tool_sha256']
    assert l['controller_sha256']==sha(D/controller)
    for n,x in r['logs'].items():assert sha(p/n)==x['sha256'] and (p/n).stat().st_size==x['bytes']
    return l,r
def main():
    m=load('v3_sched_elf',L/'inspect_codegen.py');m.SYMBOL=SYMBOL;c=load('v3_sched_cf',W/'pump-v3-regalloc/run_counterfactual.py')
    original=m.audit.Elf(W/'pumpfun-source/evidence/original/pump/deployed.so');ob=original.body(0x80df8,2120);on=original.normalize(ob,0x80df8)[0]
    source_inventory=read(L/'source-inventory.json')
    files=['llvm/lib/CodeGen/SelectionDAG/ScheduleDAGRRList.cpp','llvm/lib/CodeGen/SelectionDAG/SelectionDAGBuilder.cpp','llvm/lib/Target/SBF/SBFISelLowering.cpp','llvm/lib/Target/SBF/SBFSubtarget.h','llvm/lib/CodeGen/PostRASchedulerList.cpp','llvm/include/llvm/CodeGen/TargetSubtargetInfo.h','llvm/lib/CodeGen/TargetSubtargetInfo.cpp']
    provenance={p:sha(L/'source'/p) for p in files};assert all(h==source_inventory[p] for p,h in provenance.items())
    for name in ['derivative01','derivative02']:
        p=D/name;plan=read(p/'build-launch.json');built=read(p/'build-result.json')
        assert built['stock_build_unchanged'] and built['stock_source_unchanged'] and len(built['stages'])==3
        assert sha(p/'ScheduleDAGRRList.cpp')==plan['derivative_source_sha256'] and sha(p/'diagnostic.patch')==plan['patch_sha256']
        assert plan['stock_source_sha256']==provenance[plan['source_path']]
        assert all(sha(p/n)==h for n,h in built['outputs'].items())
        for stage in built['stages']:
            assert stage['returncode']==0
            assert all(sha(p/(stage['stage']+'.'+kind+'.log'))==h for kind,h in stage['logs'].items())
    patch=load('sched_counterfactual_patch',D/'counterfactual_patch.py')
    assert patch.patch((D/'derivative01/ScheduleDAGRRList.cpp').read_text())==(D/'derivative02/ScheduleDAGRRList.cpp').read_text()
    rows={};trace_rows={}
    for mode in ['baseline','frequency']:
        parent=F/mode;parent_launch=read(parent/'launch.json')
        pi,pb=m.target(parent/'target.o');norm=c.normalized(pb,pi['relocations'])
        for prefix,controller in [('stock-','capture.py'),('probe-','run_probe.py'),('counterfactual-','run_counterfactual.py'),('postra-','run_postra.py')]:
            names=[prefix+mode] if prefix!='counterfactual-' else [prefix+mode+'-off',prefix+mode+'-on']
            for name in names:
                p=D/name;l,r=run(p,controller);assert l['input_sha256']==parent_launch['input_sha256'] and l['environment']==parent_launch['environment']
                expected=parent_launch['command'][:11];expected[0]=l['command'][0];expected[10]=str(p/'target.o')
                if prefix=='postra-':expected+=['-post-RA-scheduler=true','-debug-only=post-RA-sched','-print-before=post-RA-sched','-print-after=post-RA-sched','-filter-print-funcs='+SYMBOL]
                else:expected+=['-debug-only=isel-dump,pre-RA-sched','-filter-print-funcs='+SYMBOL]
                if name.endswith('-on'):expected+=['-v3-diagnostic-reverse-loads']
                assert l['command']==expected
                info,raw=m.target(p/'target.o');normal=c.normalized(raw,info['relocations'])
                targets=lambda rel:[(x['type'],x['symbol'],x['addend']) for x in rel]
                allocated=lambda e:{n:e.section_bytes(n) for n,s in e.sections.items() if e.headers[s['index']][2]&2 and not e.headers[s['index']][2]&4}
                assert allocated(m.audit.Elf(p/'target.o'))==allocated(m.audit.Elf(parent/'target.o'))
                rows[name]=dict(object_sha256=sha(p/'target.o'),target_bytes=len(raw),aligned_slots=c.distance(on,normal),raw_original_equal=raw==ob,normalized_original_equal=normal==on,whole_parent_object_equal=(p/'target.o').read_bytes()==(parent/'target.o').read_bytes(),ordered_relocation_targets_equal=targets(info['relocations'])==targets(pi['relocations']),relocations=len(info['relocations']),allocated_noncode_equal=True)
                if prefix in ['stock-','probe-'] or name.endswith('-off'):assert rows[name]['whole_parent_object_equal']
                if name.endswith('-on'):assert (len(raw),rows[name]['aligned_slots'])==({'baseline':(2152,26),'frequency':(2144,9)}[mode])
                if prefix=='postra-':assert (len(raw),rows[name]['aligned_slots'])==({'baseline':(2136,71),'frequency':(2120,52)}[mode])
        stock=(D/('stock-'+mode)/'stderr.log').read_text();probe=(D/('probe-'+mode)/'stderr.log').read_text()
        assert pointers(stock)==pointers(re.sub(r'^SCHED_PROBE[^\n]*\n','',probe,flags=re.M))
        off=(D/('counterfactual-'+mode+'-off')/'stderr.log').read_text();enabled=(D/('counterfactual-'+mode+'-on')/'stderr.log').read_text()
        assert pointers(off)==pointers(probe)
        block,order=schedule(probe);changed,changed_order=schedule(enabled)
        assert [x['unit'] for x in order][4:10]==[37,2,3,4,36,5]
        assert [x['unit'] for x in changed_order][4:10]==[37,2,3,4,5,36]
        assert [(x['cycle'],x['unit']) for x in order if x['unit'] not in [5,36]]==[(x['cycle'],x['unit']) for x in changed_order if x['unit'] not in [5,36]]
        assert 'SCHED_PROBE decision BURRSort:(left->NodeQueueId > right->NodeQueueId) left=2 right=37 left_queue=5 right_queue=4 result=1' in block
        assert 'SCHED_PROBE decision BURRSort:LDist < RDist left=5 right=36 left_queue=10 right_queue=11 result=1' in block
        marker='V3_SCHED_COUNTERFACTUAL left=5 right=36 LDist=4 RDist=5 left_offset=0 right_offset=8'
        assert enabled.count('V3_SCHED_COUNTERFACTUAL')==1 and marker in changed
        trace_rows[mode]=dict(passive_whole_trace_equal_after_only_added_log_lines_and_block_addresses=True,default_off_trace_equal=True,scheduled_units=40,store_queue_ids=dict(offset8=4,offset16=5),store_bottom_up_cycles=dict(offset8=4,offset16=5),load_successor_distances=dict(frame17_offset0=4,frame17_offset8=5),load_bottom_up_order=[8,0],counterfactual_load_bottom_up_order=[0,8],all_other_schedule_positions_equal=True,actual_interventions=1,marker=marker)
    stages={}
    for mode in ['off','on']:
        p=D/('stages-'+mode);l,r=run(p,'capture_stages.py');parent=D/('counterfactual-frequency-'+mode)
        cmd=read(parent/'launch.json')['command'];cmd[10]=str(p/'target.o');cmd+=['-print-after-all']
        assert l['command']==cmd and (p/'target.o').read_bytes()==(parent/'target.o').read_bytes()
        t=(p/'stderr.log').read_text();stages[mode]={pid:machine_stage(t,pid) for pid in ['finalize-isel','greedy','virtregrewriter','prologepilog','machine-latecleanup','branch-folder','postrapseudos','post-RA-sched','block-placement']}
        assert stages[mode]['postrapseudos']['block']==stages[mode]['post-RA-sched']['block']
        rewrite=stages[mode]['virtregrewriter']['tail'];offsets=re.findall(r'\$(r[12]) = LDD_V1 %stack\.17, (0|8) ',rewrite)
        assert offsets==([('r1','0'),('r2','8')] if mode=='off' else [('r1','8'),('r2','0')]),offsets
        folded=stages[mode]['branch-folder']['tail']
        assert (('STD_V1' in folded)==(mode=='on'))
    save(D/'stage-evidence.json',stages)
    report=dict(result='PASS',llvm_revision='08aedd64bf3abe4f163407b7bcf680403b84b32d',source_provenance=provenance,trace=trace_rows,measurements=rows,stages_sha256=sha(D/'stage-evidence.json'),compiler_commands=dict(root_rustc=0,llc=12,host_build=6,target_executions=0),finding='The net-error return loads are created in aggregate ABI field order by SelectionDAGBuilder hidden-sret lowering. Result stores tie by queue insertion, at bottom-up cycles4/5. Their successor distances4/5 drive the load comparison; bottom-up8/0 emits0/8. One opt-in decision reversal swaps those loads only at scheduling, then the virtual register rewriter assigns r1 to the first field loaded and r2 to the second. This reverses field-to-register mapping and prevents the later branch-folder from sharing the existing tail. A supported stock post-RA scheduling control also regresses.',limits='Local diagnostic evidence. The pre-RA intervention and synthetic frequency input are not recovered Rust or original compiler provenance. No raw or normalized original identity gain. No program, VM, live-chain transaction or deployed contract executed.')
    save(D/'analysis.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':main()
