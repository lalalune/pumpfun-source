"""Passively capture all machine stages for the qualified synthetic-frequency pair."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    for mode in ['off','on']:
        prior=D/('counterfactual-frequency-'+mode);parent=read(prior/'launch.json');previous=read(prior/'result.json')
        out=D/('stages-'+mode);out.mkdir();command=parent['command'].copy();command[10]=str(out/'target.o');command+=['-print-after-all']
        inp=Path(command[8]);tool=Path(command[0])
        assert sha(inp)==parent['input_sha256'] and sha(tool)==parent['tool_sha256'] and sha(prior/'target.o')==previous['object_sha256']
        launch=dict(command=command,cwd=str(D),environment=parent['environment'],tool_sha256=sha(tool),input_sha256=sha(inp),parent_launch_sha256=sha(prior/'launch.json'),parent_object_sha256=sha(prior/'target.o'),controller_sha256=sha(Path(__file__)),target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            p=subprocess.run(command,cwd=D,env=parent['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        result=dict(returncode=p.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==launch['input_sha256'],tool_unchanged=sha(tool)==launch['tool_sha256'],object_sha256=sha(out/'target.o') if (out/'target.o').exists() else None,whole_parent_object_equal=(out/'target.o').read_bytes()==(prior/'target.o').read_bytes() if (out/'target.o').exists() else False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
        save(out/'result.json',result);print(json.dumps(dict(mode=mode,**result),indent=2),flush=True)
        assert p.returncode==0 and result['input_unchanged'] and result['tool_unchanged'] and result['whole_parent_object_equal']
if __name__=='__main__':main()
