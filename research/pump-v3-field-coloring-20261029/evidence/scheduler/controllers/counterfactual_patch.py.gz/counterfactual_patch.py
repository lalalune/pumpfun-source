"""Opt-in diagnostic of one qualified scheduler comparison; default is passive."""
def patch(text):
    a='static bool SchedulerProbeActive = false;'
    b=a+'''
static cl::opt<bool> V3DiagnosticReverseLoads(
    "v3-diagnostic-reverse-loads", cl::Hidden, cl::init(false),
    cl::desc("Diagnostic only: reverse qualified V3 frame17 load preference"));'''
    assert text.count(a)==1;text=text.replace(a,b)
    a='''  if (LDist != RDist)
    return schedulerProbeDecision("BURRSort:LDist < RDist", left, right, (LDist < RDist));'''
    b='''  if (LDist != RDist) {
    // Exact-input diagnostic, not a general compiler optimization. The named
    // function filter is active only during actual pop(), never queue dumps.
    if (V3DiagnosticReverseLoads && SchedulerProbeActive &&
        ((left->NodeNum == 5 && right->NodeNum == 36) ||
         (left->NodeNum == 36 && right->NodeNum == 5))) {
      SDNode *LN = left->getNode(), *RN = right->getNode();
      if (LN && RN && LN->isMachineOpcode() && RN->isMachineOpcode() &&
          LN->getNumOperands() >= 2 && RN->getNumOperands() >= 2) {
        auto *LF = dyn_cast<FrameIndexSDNode>(LN->getOperand(0));
        auto *RF = dyn_cast<FrameIndexSDNode>(RN->getOperand(0));
        auto *LO = dyn_cast<ConstantSDNode>(LN->getOperand(1));
        auto *RO = dyn_cast<ConstantSDNode>(RN->getOperand(1));
        if (LF && RF && LO && RO && LF->getIndex() == 17 &&
            RF->getIndex() == 17 &&
            ((LO->getZExtValue() == 0 && RO->getZExtValue() == 8) ||
             (LO->getZExtValue() == 8 && RO->getZExtValue() == 0))) {
          dbgs() << "V3_SCHED_COUNTERFACTUAL left=" << left->NodeNum
                 << " right=" << right->NodeNum << " LDist=" << LDist
                 << " RDist=" << RDist << " left_offset=" << LO->getZExtValue()
                 << " right_offset=" << RO->getZExtValue() << "\\n";
          return LO->getZExtValue() > RO->getZExtValue();
        }
      }
    }
    return schedulerProbeDecision("BURRSort:LDist < RDist", left, right, (LDist < RDist));
  }'''
    assert text.count(a)==1
    return text.replace(a,b)
