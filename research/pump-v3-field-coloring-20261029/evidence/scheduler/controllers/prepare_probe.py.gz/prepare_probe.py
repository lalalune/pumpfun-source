from pathlib import Path
import hashlib,json,shutil
D=Path(__file__).resolve().parent;L=D.parent/'l18';O=D/'derivative01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    old=L/'build_scheduler_probe.py';s=old.read_text()
    a="D=Path(__file__).resolve().parent;B=D/'build01';O=D/'scheduler-derivative01'"
    b="D=Path(__file__).resolve().parent.parent/'l18';B=D/'build01';O=Path(__file__).resolve().parent/'derivative01'"
    before='_ZN14pump_recovered14pump_recovered16buy_exact_sol_in17h28eae2e2fdc8f8b2E';after='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
    assert s.count(a)==1 and s.count(before)==1
    s=s.replace(a,b).replace(before,after)
    dest=D/'build_probe.py';assert not dest.exists();dest.write_text(s,encoding='utf-8',newline='\n')
    O.mkdir();shutil.copyfile(L/'scheduler-derivative01/stock-commands.json',O/'stock-commands.json')
    (D/'preparation.json').write_text(json.dumps(dict(parent_controller_sha256=sha(old),controller_sha256=sha(dest),stock_commands_sha256=sha(O/'stock-commands.json'),changes=['Private build destination only','Exact function-name log filter changed to V3 target'],scope='Reuse established logging-only queue instrumentation. No scheduler decision changed; complete output qualification required.'),indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
