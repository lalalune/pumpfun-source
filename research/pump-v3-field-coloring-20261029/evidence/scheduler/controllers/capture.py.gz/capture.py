"""Passively trace V3 scheduling, qualifying each complete object."""
from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;W=D.parent;F=W/'pump-v3-cost-model/ir01'
SYMBOL='_ZN14pump_recovered5trade12v3_buy_costs17h280dba79c4dad174E'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def main():
    for mode in ['baseline','frequency']:
        prior=F/mode;parent=read(prior/'launch.json');result=read(prior/'result.json')
        inp=prior/'input.ll';assert sha(inp)==parent['input_sha256'] and sha(prior/'target.o')==result['object_sha256']
        out=D/('stock-'+mode);out.mkdir();command=parent['command'][:11];command[10]=str(out/'target.o')
        command+=['-debug-only=isel-dump,pre-RA-sched','-filter-print-funcs='+SYMBOL]
        assert sha(Path(command[0]))==parent['tool_sha256']
        launch=dict(command=command,cwd=str(D),environment=parent['environment'],tool_sha256=parent['tool_sha256'],input_sha256=sha(inp),parent_object_sha256=sha(prior/'target.o'),controller_sha256=sha(Path(__file__)),scope='Passive compiler diagnostics, no changed source/IR, no target execution. Frequency mode inherits an explicitly synthetic profile input.',target_executions=0)
        save(out/'launch.json',launch);start=time.time()
        with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
            p=subprocess.run(command,cwd=D,env=parent['environment'],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        row=dict(returncode=p.returncode,seconds=time.time()-start,input_unchanged=sha(inp)==launch['input_sha256'],tool_unchanged=sha(Path(command[0]))==launch['tool_sha256'],object_sha256=sha(out/'target.o') if (out/'target.o').exists() else None,complete_object_equal=(out/'target.o').read_bytes()==(prior/'target.o').read_bytes() if (out/'target.o').exists() else False,logs={n:dict(bytes=(out/n).stat().st_size,sha256=sha(out/n)) for n in ['stdout.log','stderr.log']},target_executions=0)
        save(out/'result.json',row);print(json.dumps(dict(mode=mode,**row),indent=2),flush=True)
        assert p.returncode==0 and row['input_unchanged'] and row['tool_unchanged'] and row['complete_object_equal']
if __name__=='__main__':main()
