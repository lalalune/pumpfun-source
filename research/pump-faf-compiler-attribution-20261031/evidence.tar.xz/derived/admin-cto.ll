define hidden { i64, ptr } @_ZN14pump_recovered9admin_cto7execute17h3bd6d7f34f2e30d7E(ptr noalias nocapture noundef readonly align 8 dereferenceable(48) %ctx, i8 noundef %holder, i64 noundef %0, i64 %1, ptr noalias nocapture noundef readonly align 1 dereferenceable(33) %new) unnamed_addr #1 {
start:
  %_11.i295 = alloca [0 x i8], align 1
  %formatter.i296 = alloca [64 x i8], align 8
  %buf.i297 = alloca [24 x i8], align 8
  %formatter.i.i118 = alloca [64 x i8], align 8
  %buf.i.i119 = alloca [24 x i8], align 8
  %_162.i = alloca [288 x i8], align 8
  %_160.i = alloca [376 x i8], align 8
  %_149.i = alloca [160 x i8], align 8
  %_144.i120 = alloca [16 x i8], align 8
  %_139.i = alloca [16 x i8], align 8
  %_113.i = alloca [32 x i8], align 8
  %_112.sroa.5.i = alloca [24 x i8], align 8
  %rent.i = alloca [24 x i8], align 8
  %_110.i = alloca [1 x i8], align 1
  %_105.i = alloca [48 x i8], align 8
  %old.i = alloca [32 x i8], align 1
  %vsigner.i = alloca [16 x i8], align 8
  %_63.sroa.20.sroa.11.i = alloca [5 x i8], align 1
  %_63.sroa.21.sroa.11.i = alloca [5 x i8], align 1
  %_63.sroa.22.sroa.11.i = alloca [5 x i8], align 1
  %_55.sroa.11.i = alloca [5 x i8], align 1
  %_54.i = alloca [664 x i8], align 8
  %_42.i = alloca [160 x i8], align 8
  %_37.i = alloca [16 x i8], align 8
  %_31.i = alloca [16 x i8], align 8
  %_24.i121 = alloca [64 x i8], align 1
  %_18.i122 = alloca [24 x i8], align 8
  %_17.i = alloca [160 x i8], align 8
  %_14.i = alloca [32 x i8], align 1
  %_10.i123 = alloca [32 x i8], align 8
  %_7.i = alloca [33 x i8], align 1
  %dest.i = alloca [32 x i8], align 1
  %_5.i = alloca [32 x i8], align 1
  %formatter.i.i88 = alloca [64 x i8], align 8
  %buf.i.i89 = alloca [24 x i8], align 8
  %_204.i = alloca [24 x i8], align 8
  %_129.i = alloca [384 x i8], align 8
  %_127.i = alloca [472 x i8], align 8
  %_116.i = alloca [1 x i8], align 1
  %_112.i = alloca [32 x i8], align 8
  %_109.i = alloca [24 x i8], align 8
  %event_infos.i = alloca [48 x i8], align 8
  %_100.i = alloca [24 x i8], align 8
  %ix.i = alloca [80 x i8], align 8
  %_92.i = alloca [48 x i8], align 8
  %ix_data.i = alloca [24 x i8], align 8
  %inner_data.i = alloca [24 x i8], align 8
  %authority_info.i = alloca [48 x i8], align 8
  %_83.i = alloca [24 x i8], align 8
  %_81.i90 = alloca [16 x i8], align 8
  %_75.i91 = alloca [48 x i8], align 8
  %e.i = alloca [80 x i8], align 8
  %val.sroa.6.i = alloca [24 x i8], align 8
  %_58.i = alloca [48 x i8], align 8
  %event_signers.i = alloca [16 x i8], align 8
  %_46.i = alloca [288 x i8], align 8
  %_44.i92 = alloca [376 x i8], align 8
  %_38.i = alloca [16 x i8], align 8
  %_32.i = alloca [16 x i8], align 8
  %_24.i93 = alloca [32 x i8], align 1
  %_18.i = alloca [16 x i8], align 8
  %_10.i = alloca [24 x i8], align 8
  %_9.i = alloca [160 x i8], align 8
  %formatter.i = alloca [64 x i8], align 8
  %buf.i = alloca [24 x i8], align 8
  %formatter.i53.i = alloca [64 x i8], align 8
  %buf.i54.i = alloca [24 x i8], align 8
  %formatter.i46.i = alloca [64 x i8], align 8
  %buf.i47.i = alloca [24 x i8], align 8
  %formatter.i39.i = alloca [64 x i8], align 8
  %buf.i40.i = alloca [24 x i8], align 8
  %formatter.i32.i = alloca [64 x i8], align 8
  %buf.i33.i = alloca [24 x i8], align 8
  %formatter.i25.i = alloca [64 x i8], align 8
  %buf.i26.i = alloca [24 x i8], align 8
  %formatter.i18.i = alloca [64 x i8], align 8
  %buf.i19.i = alloca [24 x i8], align 8
  %formatter.i.i = alloca [64 x i8], align 8
  %buf.i.i = alloca [24 x i8], align 8
  %_125.i = alloca [160 x i8], align 8
  %_114.i = alloca [160 x i8], align 8
  %_104.i = alloca [160 x i8], align 8
  %_94.i = alloca [160 x i8], align 8
  %_82.i = alloca [24 x i8], align 8
  %_81.i = alloca [160 x i8], align 8
  %_75.i = alloca [64 x i8], align 1
  %_68.i = alloca [24 x i8], align 8
  %_67.i = alloca [160 x i8], align 8
  %_64.i = alloca [32 x i8], align 1
  %_56.i = alloca [24 x i8], align 8
  %_55.i = alloca [160 x i8], align 8
  %t.i = alloca [32 x i8], align 1
  %_44.i = alloca [24 x i8], align 8
  %_43.i = alloca [160 x i8], align 8
  %target.i.sroa.0 = alloca [7 x i8], align 1
  %target.i.sroa.9 = alloca [9 x i8], align 1
  %_34.i = alloca [24 x i8], align 8
  %_33.i = alloca [160 x i8], align 8
  %_24.i = alloca [24 x i8], align 8
  %_23.i = alloca [160 x i8], align 8
  %_12.i = alloca [24 x i8], align 8
  %_11.i85 = alloca [160 x i8], align 8
  %sharing_update14.sroa.3 = alloca [32 x i8], align 1
  %target13 = alloca [32 x i8], align 1
  %_539.sroa.6 = alloca [32 x i8], align 1
  %_509 = alloca [24 x i8], align 8
  %_261 = alloca [1 x i8], align 1
  %_257 = alloca [32 x i8], align 8
  %_254 = alloca [16 x i8], align 8
  %_251 = alloca [48 x i8], align 8
  %_247 = alloca [24 x i8], align 8
  %_239 = alloca [24 x i8], align 8
  %ix = alloca [80 x i8], align 8
  %_232 = alloca [48 x i8], align 8
  %ix_data = alloca [24 x i8], align 8
  %inner_data = alloca [24 x i8], align 8
  %authority_info = alloca [48 x i8], align 8
  %_223 = alloca [24 x i8], align 8
  %_221 = alloca [16 x i8], align 8
  %_209 = alloca [48 x i8], align 8
  %e = alloca [200 x i8], align 8
  %_197 = alloca [336 x i8], align 8
  %_195 = alloca [424 x i8], align 8
  %old_creator = alloca [32 x i8], align 1
  %_121.sroa.11 = alloca [5 x i8], align 1
  %_120 = alloca [424 x i8], align 8
  %val6 = alloca [33 x i8], align 1
  %_114 = alloca [1 x i8], align 1
  %_109 = alloca [48 x i8], align 8
  %_106 = alloca [16 x i8], align 8
  %_83 = alloca [24 x i8], align 8
  %_82 = alloca [160 x i8], align 8
  %_67 = alloca [32 x i8], align 1
  %_48.sroa.11 = alloca [16 x i8], align 8
  %target.sroa.0 = alloca [7 x i8], align 1
  %target.sroa.8 = alloca [9 x i8], align 1
  %sk = alloca [32 x i8], align 1
  %st = alloca [48 x i8], align 8
  %_26 = alloca [32 x i8], align 1
  %q = alloca [32 x i8], align 1
  %_18 = alloca [32 x i8], align 8
  %hk = alloca [33 x i8], align 1
  %holder_key = alloca [32 x i8], align 1
  %_9 = alloca [32 x i8], align 1
  %mint = alloca [32 x i8], align 1
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %mint)
  %2 = getelementptr inbounds i8, ptr %ctx, i64 8
  %_266 = load ptr, ptr %2, align 8, !nonnull !2, !align !3, !noundef !2
  %3 = getelementptr inbounds i8, ptr %_266, i64 16
  %_380 = load ptr, ptr %3, align 8, !nonnull !2, !align !3, !noundef !2
  %_381 = load ptr, ptr %_380, align 8, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %mint, ptr noundef nonnull align 1 dereferenceable(32) %_381, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_9)
  %4 = getelementptr inbounds i8, ptr %_266, i64 144
  %_382 = load ptr, ptr %4, align 8, !nonnull !2, !align !3, !noundef !2
  %_383 = load ptr, ptr %_382, align 8, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_9, ptr noundef nonnull align 1 dereferenceable(32) %_383, i64 32, i1 false)
  %5 = getelementptr inbounds i8, ptr %_266, i64 56
  %_269 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %_385 = getelementptr inbounds i8, ptr %_269, i64 8
  %6 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_9, ptr noundef nonnull dereferenceable(32) %_385, i64 32)
  %7 = icmp eq i32 %6, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_9)
  br i1 %7, label %bb1, label %bb6

bb1:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_382, i64 24
  %_386 = load ptr, ptr %8, align 8, !nonnull !2, !align !392, !noundef !2
  %9 = tail call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_386, ptr noundef nonnull dereferenceable(32) @_ZN14pump_recovered9pump_fees2ID17h48f30a480ea28979E, i64 32)
  %10 = icmp eq i32 %9, 0
  br i1 %10, label %bb2, label %bb6

bb2:                                              ; preds = %bb1
; call solana_account_info::AccountInfo::data_is_empty
  %_12 = tail call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_382) #27
  %11 = xor i1 %_12, true
  br label %bb6

bb6:                                              ; preds = %bb1, %start, %bb2
  %shared.sroa.0.0.off0 = phi i1 [ %11, %bb2 ], [ false, %start ], [ false, %bb1 ]
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %holder_key)
  call void @llvm.lifetime.start.p0(i64 33, ptr nonnull %hk)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_18)
  store ptr @alloc_df68464402562fbf659e5577c3ed192b, ptr %_18, align 8
  %12 = getelementptr inbounds i8, ptr %_18, i64 8
  store i64 14, ptr %12, align 8
  %13 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_18, i64 0, i64 1
  store ptr %mint, ptr %13, align 8
  %14 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_18, i64 0, i64 1, i32 1
  store i64 32, ptr %14, align 8
; call solana_pubkey::Pubkey::find_program_address
  call void @_ZN13solana_pubkey6Pubkey20find_program_address17h57945082f260e69dE(ptr noalias nocapture noundef nonnull sret([33 x i8]) align 1 dereferenceable(33) %hk, ptr noalias noundef nonnull readonly align 8 %_18, i64 noundef 2, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE) #27
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_18)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %holder_key, ptr noundef nonnull align 1 dereferenceable(32) %hk, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %q)
  %_273 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %15 = getelementptr inbounds i8, ptr %_273, i64 40
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %q, ptr noundef nonnull align 8 dereferenceable(32) %15, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_26)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_26, i8 0, i64 32, i1 false)
  %16 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %q, ptr noundef nonnull dereferenceable(32) %_26, i64 32)
  %17 = icmp eq i32 %16, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_26)
  br i1 %17, label %bb12, label %bb9

bb9:                                              ; preds = %bb6
  %18 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %q, ptr noundef nonnull dereferenceable(32) @alloc_e953c1d75e6a4349f2dca6892c168ab2, i64 32)
  %19 = icmp eq i32 %18, 0
  br i1 %19, label %bb12, label %bb11

bb11:                                             ; preds = %bb9
  %20 = getelementptr inbounds i8, ptr %_266, i64 8
  %_275 = load ptr, ptr %20, align 8, !nonnull !2, !align !3, !noundef !2
  %_13.i.i2.i.i.ptr = getelementptr inbounds i8, ptr %_275, i64 936
  %21 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_13.i.i2.i.i.ptr, ptr noundef nonnull dereferenceable(32) %q, i64 32), !alias.scope !5547, !noalias !5554
  %22 = icmp eq i32 %21, 0
  br label %bb12

bb12:                                             ; preds = %bb11, %bb9, %bb6
  %quote_locked.sroa.0.0.off0 = phi i1 [ true, %bb6 ], [ true, %bb9 ], [ %22, %bb11 ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %q)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %st)
  %23 = getelementptr inbounds i8, ptr %_273, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %st, ptr noundef nonnull align 8 dereferenceable(32) %23, i64 32, i1 false)
  %24 = getelementptr inbounds i8, ptr %_266, i64 8
  %_279 = load ptr, ptr %24, align 8, !nonnull !2, !align !3, !noundef !2
  %25 = getelementptr inbounds i8, ptr %_279, i64 1072
  %_33 = load i64, ptr %25, align 8, !noundef !2
  %26 = getelementptr inbounds i8, ptr %_273, i64 162
  %27 = load i8, ptr %26, align 2, !range !394, !noundef !2
  %28 = getelementptr inbounds i8, ptr %_273, i64 165
  %29 = load i8, ptr %28, align 1, !range !394, !noundef !2
  %30 = getelementptr inbounds i8, ptr %_273, i64 163
  %31 = load i8, ptr %30, align 1, !range !394, !noundef !2
  %32 = getelementptr inbounds i8, ptr %_279, i64 1087
  %33 = load i8, ptr %32, align 1, !range !394, !noundef !2
  %34 = getelementptr inbounds i8, ptr %_279, i64 1086
  %35 = load i8, ptr %34, align 2, !range !394, !noundef !2
  %36 = getelementptr inbounds i8, ptr %st, i64 32
  store i64 %_33, ptr %36, align 8
  %37 = getelementptr inbounds i8, ptr %st, i64 40
  store i8 %27, ptr %37, align 8
  %38 = getelementptr inbounds i8, ptr %st, i64 41
  store i8 %29, ptr %38, align 1
  %39 = getelementptr inbounds i8, ptr %st, i64 42
  store i8 %31, ptr %39, align 2
  %40 = getelementptr inbounds i8, ptr %st, i64 43
  %41 = zext i1 %quote_locked.sroa.0.0.off0 to i8
  store i8 %41, ptr %40, align 1
  %42 = getelementptr inbounds i8, ptr %st, i64 44
  store i8 %33, ptr %42, align 4
  %43 = getelementptr inbounds i8, ptr %st, i64 45
  store i8 %35, ptr %43, align 1
  %44 = and i8 %holder, -3
  %_0.sroa.0.0.off0.i = icmp ne i8 %44, 0
  %extract.t = icmp ne i8 %31, 0
  %not._0.sroa.0.0.off0.i = xor i1 %_0.sroa.0.0.off0.i, true
  %cashback.sroa.0.0.off0 = and i1 %extract.t, %not._0.sroa.0.0.off0.i
  %_45.sroa.0.0.copyload = load i8, ptr %new, align 1
  %_45.sroa.5.0.new.sroa_idx = getelementptr inbounds i8, ptr %new, i64 1
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %sk)
  %_396 = load ptr, ptr %4, align 8, !nonnull !2, !align !3, !noundef !2
  %_397 = load ptr, ptr %_396, align 8, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %sk, ptr noundef nonnull align 1 dereferenceable(32) %_397, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 7, ptr nonnull %target.sroa.0)
  call void @llvm.lifetime.start.p0(i64 9, ptr nonnull %target.sroa.8)
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_48.sroa.11)
  %_0.sroa.0.0.off0.i.not.i = icmp eq i8 %44, 0
  %_9.not.i = icmp eq i8 %27, 0
  br i1 %_9.not.i, label %bb6.i, label %bb2.i

bb6.i:                                            ; preds = %bb12
  %_19.not.i = icmp eq i8 %29, 0
  br i1 %_19.not.i, label %bb14.i, label %bb7.i

bb2.i:                                            ; preds = %bb12
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_11.i85), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_12.i), !noalias !5557
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_12.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_eb4f91695bc6f999067c65f428fcc4d8) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i.i), !noalias !5564
  store i64 0, ptr %buf.i.i, align 8, !noalias !5564
  %_9.sroa.4.0.buf.sroa_idx.i.i = getelementptr inbounds i8, ptr %buf.i.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i.i, align 8, !noalias !5564
  %_9.sroa.5.0.buf.sroa_idx.i.i = getelementptr inbounds i8, ptr %buf.i.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i.i, align 8, !noalias !5564
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i.i), !noalias !5564
  %45 = getelementptr inbounds i8, ptr %formatter.i.i, i64 52
  store i32 0, ptr %45, align 4, !noalias !5564
  %46 = getelementptr inbounds i8, ptr %formatter.i.i, i64 48
  store i32 32, ptr %46, align 8, !noalias !5564
  %47 = getelementptr inbounds i8, ptr %formatter.i.i, i64 56
  store i8 3, ptr %47, align 8, !noalias !5564
  store i64 0, ptr %formatter.i.i, align 8, !noalias !5564
  %48 = getelementptr inbounds i8, ptr %formatter.i.i, i64 16
  store i64 0, ptr %48, align 8, !noalias !5564
  %49 = getelementptr inbounds i8, ptr %formatter.i.i, i64 32
  store ptr %buf.i.i, ptr %49, align 8, !noalias !5564
  %50 = getelementptr inbounds i8, ptr %formatter.i.i, i64 40
  store ptr @vtable.4, ptr %50, align 8, !noalias !5564
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %51 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_eb4f91695bc6f999067c65f428fcc4d8, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i.i) #27, !noalias !5568
  br i1 %51, label %bb3.i.i86, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i"

bb3.i.i86:                                        ; preds = %bb2.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5564
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i": ; preds = %bb2.i
  %52 = getelementptr inbounds i8, ptr %_11.i85, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %52, ptr noundef nonnull align 8 dereferenceable(24) %buf.i.i, i64 24, i1 false), !noalias !5557
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i.i), !noalias !5564
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i.i), !noalias !5564
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  %53 = getelementptr inbounds i8, ptr %_11.i85, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %53, ptr noundef nonnull align 8 dereferenceable(24) %_12.i, i64 24, i1 false), !noalias !5557
  %54 = getelementptr inbounds i8, ptr %_11.i85, i64 152
  store i32 6088, ptr %54, align 8, !noalias !5557
  store i64 0, ptr %_11.i85, align 8, !noalias !5557
  %_15.sroa.4.0._11.sroa_idx.i = getelementptr inbounds i8, ptr %_11.i85, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_15.sroa.4.0._11.sroa_idx.i, align 8, !noalias !5557
  %_15.sroa.4.sroa.4.0._15.sroa.4.0._11.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_11.i85, i64 16
  store i64 38, ptr %_15.sroa.4.sroa.4.0._15.sroa.4.0._11.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_15.sroa.4.sroa.5.0._15.sroa.4.0._11.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_11.i85, i64 24
  store i32 284, ptr %_15.sroa.4.sroa.5.0._15.sroa.4.0._11.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %55 = getelementptr inbounds i8, ptr %_11.i85, i64 80
  store i8 2, ptr %55, align 8, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_12.i), !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %56 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_11.i85) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_11.i85), !noalias !5557
  br label %bb75

bb14.i:                                           ; preds = %bb6.i
  br i1 %_0.sroa.0.0.off0.i.not.i, label %bb23.i, label %bb16.i

bb7.i:                                            ; preds = %bb6.i
  br i1 %_0.sroa.0.0.off0.i.not.i, label %bb10.i, label %bb22.i

bb16.i:                                           ; preds = %bb14.i
  %_31.not.i = icmp eq i8 %33, 0
  br i1 %_31.not.i, label %bb17.i, label %bb22.i

bb17.i:                                           ; preds = %bb16.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_33.i), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_34.i), !noalias !5557
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_34.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_f94f166953c814e4161e699857179a1e) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i19.i), !noalias !5569
  store i64 0, ptr %buf.i19.i, align 8, !noalias !5569
  %_9.sroa.4.0.buf.sroa_idx.i20.i = getelementptr inbounds i8, ptr %buf.i19.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i20.i, align 8, !noalias !5569
  %_9.sroa.5.0.buf.sroa_idx.i21.i = getelementptr inbounds i8, ptr %buf.i19.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i21.i, align 8, !noalias !5569
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i18.i), !noalias !5569
  %57 = getelementptr inbounds i8, ptr %formatter.i18.i, i64 52
  store i32 0, ptr %57, align 4, !noalias !5569
  %58 = getelementptr inbounds i8, ptr %formatter.i18.i, i64 48
  store i32 32, ptr %58, align 8, !noalias !5569
  %59 = getelementptr inbounds i8, ptr %formatter.i18.i, i64 56
  store i8 3, ptr %59, align 8, !noalias !5569
  store i64 0, ptr %formatter.i18.i, align 8, !noalias !5569
  %60 = getelementptr inbounds i8, ptr %formatter.i18.i, i64 16
  store i64 0, ptr %60, align 8, !noalias !5569
  %61 = getelementptr inbounds i8, ptr %formatter.i18.i, i64 32
  store ptr %buf.i19.i, ptr %61, align 8, !noalias !5569
  %62 = getelementptr inbounds i8, ptr %formatter.i18.i, i64 40
  store ptr @vtable.4, ptr %62, align 8, !noalias !5569
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %63 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_f94f166953c814e4161e699857179a1e, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i18.i) #27, !noalias !5573
  br i1 %63, label %bb3.i22.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit23.i"

bb3.i22.i:                                        ; preds = %bb17.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5569
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit23.i": ; preds = %bb17.i
  %64 = getelementptr inbounds i8, ptr %_33.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %64, ptr noundef nonnull align 8 dereferenceable(24) %buf.i19.i, i64 24, i1 false), !noalias !5557
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i18.i), !noalias !5569
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i19.i), !noalias !5569
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  %65 = getelementptr inbounds i8, ptr %_33.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %65, ptr noundef nonnull align 8 dereferenceable(24) %_34.i, i64 24, i1 false), !noalias !5557
  %66 = getelementptr inbounds i8, ptr %_33.i, i64 152
  store i32 6084, ptr %66, align 8, !noalias !5557
  store i64 0, ptr %_33.i, align 8, !noalias !5557
  %_37.sroa.4.0._33.sroa_idx.i = getelementptr inbounds i8, ptr %_33.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_37.sroa.4.0._33.sroa_idx.i, align 8, !noalias !5557
  %_37.sroa.4.sroa.4.0._37.sroa.4.0._33.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_33.i, i64 16
  store i64 38, ptr %_37.sroa.4.sroa.4.0._37.sroa.4.0._33.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_37.sroa.4.sroa.5.0._37.sroa.4.0._33.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_33.i, i64 24
  store i32 296, ptr %_37.sroa.4.sroa.5.0._37.sroa.4.0._33.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %67 = getelementptr inbounds i8, ptr %_33.i, i64 80
  store i8 2, ptr %67, align 8, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_34.i), !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %68 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_33.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_33.i), !noalias !5557
  br label %bb75

bb10.i:                                           ; preds = %bb7.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_23.i), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_24.i), !noalias !5557
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_24.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8f95cb73e89711d65e95d13598508b19) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i26.i), !noalias !5574
  store i64 0, ptr %buf.i26.i, align 8, !noalias !5574
  %_9.sroa.4.0.buf.sroa_idx.i27.i = getelementptr inbounds i8, ptr %buf.i26.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i27.i, align 8, !noalias !5574
  %_9.sroa.5.0.buf.sroa_idx.i28.i = getelementptr inbounds i8, ptr %buf.i26.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i28.i, align 8, !noalias !5574
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i25.i), !noalias !5574
  %69 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 52
  store i32 0, ptr %69, align 4, !noalias !5574
  %70 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 48
  store i32 32, ptr %70, align 8, !noalias !5574
  %71 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 56
  store i8 3, ptr %71, align 8, !noalias !5574
  store i64 0, ptr %formatter.i25.i, align 8, !noalias !5574
  %72 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 16
  store i64 0, ptr %72, align 8, !noalias !5574
  %73 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 32
  store ptr %buf.i26.i, ptr %73, align 8, !noalias !5574
  %74 = getelementptr inbounds i8, ptr %formatter.i25.i, i64 40
  store ptr @vtable.4, ptr %74, align 8, !noalias !5574
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %75 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8f95cb73e89711d65e95d13598508b19, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i25.i) #27, !noalias !5578
  br i1 %75, label %bb3.i29.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i"

bb3.i29.i:                                        ; preds = %bb10.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5574
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i": ; preds = %bb10.i
  %76 = getelementptr inbounds i8, ptr %_23.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %76, ptr noundef nonnull align 8 dereferenceable(24) %buf.i26.i, i64 24, i1 false), !noalias !5557
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i25.i), !noalias !5574
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i26.i), !noalias !5574
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  %77 = getelementptr inbounds i8, ptr %_23.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %77, ptr noundef nonnull align 8 dereferenceable(24) %_24.i, i64 24, i1 false), !noalias !5557
  %78 = getelementptr inbounds i8, ptr %_23.i, i64 152
  store i32 6083, ptr %78, align 8, !noalias !5557
  store i64 0, ptr %_23.i, align 8, !noalias !5557
  %_27.sroa.4.0._23.sroa_idx.i = getelementptr inbounds i8, ptr %_23.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_27.sroa.4.0._23.sroa_idx.i, align 8, !noalias !5557
  %_27.sroa.4.sroa.4.0._27.sroa.4.0._23.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_23.i, i64 16
  store i64 38, ptr %_27.sroa.4.sroa.4.0._27.sroa.4.0._23.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_27.sroa.4.sroa.5.0._27.sroa.4.0._23.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_23.i, i64 24
  store i32 289, ptr %_27.sroa.4.sroa.5.0._27.sroa.4.0._23.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %79 = getelementptr inbounds i8, ptr %_23.i, i64 80
  store i8 2, ptr %79, align 8, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_24.i), !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %80 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_23.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_23.i), !noalias !5557
  br label %bb75

bb23.i:                                           ; preds = %bb14.i
  call void @llvm.lifetime.start.p0(i64 7, ptr nonnull %target.i.sroa.0)
  call void @llvm.lifetime.start.p0(i64 9, ptr nonnull %target.i.sroa.9)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %t.i), !noalias !5557
  %trunc.not.not.i = icmp eq i8 %_45.sroa.0.0.copyload, 0
  br i1 %trunc.not.not.i, label %bb27.i, label %bb28.i

bb22.i:                                           ; preds = %bb16.i, %bb7.i
  call void @llvm.lifetime.start.p0(i64 7, ptr nonnull %target.i.sroa.0)
  call void @llvm.lifetime.start.p0(i64 9, ptr nonnull %target.i.sroa.9)
  %trunc10.not.not.i = icmp eq i8 %_45.sroa.0.0.copyload, 0
  br i1 %trunc10.not.not.i, label %bb44.i, label %bb79.i

bb28.i:                                           ; preds = %bb23.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %t.i, ptr noundef nonnull align 1 dereferenceable(32) %_45.sroa.5.0.new.sroa_idx, i64 32, i1 false), !noalias !5579
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_64.i), !noalias !5557
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_64.i, i8 0, i64 32, i1 false), !noalias !5557
  %81 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %_64.i, i64 32), !noalias !5557
  %82 = icmp eq i32 %81, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_64.i), !noalias !5557
  br i1 %82, label %bb32.i, label %bb37.i

bb27.i:                                           ; preds = %bb23.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_55.i), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_56.i), !noalias !5557
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_56.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_1ba5e1e397ae92b788c97e688ac0b362) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i33.i), !noalias !5580
  store i64 0, ptr %buf.i33.i, align 8, !noalias !5580
  %_9.sroa.4.0.buf.sroa_idx.i34.i = getelementptr inbounds i8, ptr %buf.i33.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i34.i, align 8, !noalias !5580
  %_9.sroa.5.0.buf.sroa_idx.i35.i = getelementptr inbounds i8, ptr %buf.i33.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i35.i, align 8, !noalias !5580
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i32.i), !noalias !5580
  %83 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 52
  store i32 0, ptr %83, align 4, !noalias !5580
  %84 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 48
  store i32 32, ptr %84, align 8, !noalias !5580
  %85 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 56
  store i8 3, ptr %85, align 8, !noalias !5580
  store i64 0, ptr %formatter.i32.i, align 8, !noalias !5580
  %86 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 16
  store i64 0, ptr %86, align 8, !noalias !5580
  %87 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 32
  store ptr %buf.i33.i, ptr %87, align 8, !noalias !5580
  %88 = getelementptr inbounds i8, ptr %formatter.i32.i, i64 40
  store ptr @vtable.4, ptr %88, align 8, !noalias !5580
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %89 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_1ba5e1e397ae92b788c97e688ac0b362, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i32.i) #27, !noalias !5584
  br i1 %89, label %bb3.i36.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i"

bb3.i36.i:                                        ; preds = %bb27.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5580
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i": ; preds = %bb27.i
  %90 = getelementptr inbounds i8, ptr %_55.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %90, ptr noundef nonnull align 8 dereferenceable(24) %buf.i33.i, i64 24, i1 false), !noalias !5557
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i32.i), !noalias !5580
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i33.i), !noalias !5580
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  %91 = getelementptr inbounds i8, ptr %_55.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %91, ptr noundef nonnull align 8 dereferenceable(24) %_56.i, i64 24, i1 false), !noalias !5557
  %92 = getelementptr inbounds i8, ptr %_55.i, i64 152
  store i32 6089, ptr %92, align 8, !noalias !5557
  store i64 0, ptr %_55.i, align 8, !noalias !5557
  %_59.sroa.4.0._55.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_59.sroa.4.0._55.sroa_idx.i, align 8, !noalias !5557
  %_59.sroa.4.sroa.4.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 16
  store i64 38, ptr %_59.sroa.4.sroa.4.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_59.sroa.4.sroa.5.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_55.i, i64 24
  store i32 306, ptr %_59.sroa.4.sroa.5.0._59.sroa.4.0._55.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %93 = getelementptr inbounds i8, ptr %_55.i, i64 80
  store i8 2, ptr %93, align 8, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_56.i), !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %94 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_55.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_55.i), !noalias !5557
  br label %bb72.i

bb37.i:                                           ; preds = %bb28.i
  %95 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %sk, i64 32), !noalias !5585
  %96 = icmp eq i32 %95, 0
  br i1 %96, label %bb39.i, label %bb38.i

bb32.i:                                           ; preds = %bb28.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_67.i), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_68.i), !noalias !5557
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_68.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_0e3505805f4905816c1bd644811a7869) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i40.i), !noalias !5586
  store i64 0, ptr %buf.i40.i, align 8, !noalias !5586
  %_9.sroa.4.0.buf.sroa_idx.i41.i = getelementptr inbounds i8, ptr %buf.i40.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i41.i, align 8, !noalias !5586
  %_9.sroa.5.0.buf.sroa_idx.i42.i = getelementptr inbounds i8, ptr %buf.i40.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i42.i, align 8, !noalias !5586
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i39.i), !noalias !5586
  %97 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 52
  store i32 0, ptr %97, align 4, !noalias !5586
  %98 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 48
  store i32 32, ptr %98, align 8, !noalias !5586
  %99 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 56
  store i8 3, ptr %99, align 8, !noalias !5586
  store i64 0, ptr %formatter.i39.i, align 8, !noalias !5586
  %100 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 16
  store i64 0, ptr %100, align 8, !noalias !5586
  %101 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 32
  store ptr %buf.i40.i, ptr %101, align 8, !noalias !5586
  %102 = getelementptr inbounds i8, ptr %formatter.i39.i, i64 40
  store ptr @vtable.4, ptr %102, align 8, !noalias !5586
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %103 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_0e3505805f4905816c1bd644811a7869, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i39.i) #27, !noalias !5590
  br i1 %103, label %bb3.i43.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i"

bb3.i43.i:                                        ; preds = %bb32.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5586
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i": ; preds = %bb32.i
  %104 = getelementptr inbounds i8, ptr %_67.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %104, ptr noundef nonnull align 8 dereferenceable(24) %buf.i40.i, i64 24, i1 false), !noalias !5557
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i39.i), !noalias !5586
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i40.i), !noalias !5586
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  %105 = getelementptr inbounds i8, ptr %_67.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %105, ptr noundef nonnull align 8 dereferenceable(24) %_68.i, i64 24, i1 false), !noalias !5557
  %106 = getelementptr inbounds i8, ptr %_67.i, i64 152
  store i32 6030, ptr %106, align 8, !noalias !5557
  store i64 0, ptr %_67.i, align 8, !noalias !5557
  %_71.sroa.4.0._67.sroa_idx.i = getelementptr inbounds i8, ptr %_67.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_71.sroa.4.0._67.sroa_idx.i, align 8, !noalias !5557
  %_71.sroa.4.sroa.4.0._71.sroa.4.0._67.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_67.i, i64 16
  store i64 38, ptr %_71.sroa.4.sroa.4.0._71.sroa.4.0._67.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_71.sroa.4.sroa.5.0._71.sroa.4.0._67.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_67.i, i64 24
  store i32 307, ptr %_71.sroa.4.sroa.5.0._71.sroa.4.0._67.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %107 = getelementptr inbounds i8, ptr %_67.i, i64 80
  store i8 2, ptr %107, align 8, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_68.i), !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %108 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_67.i) #27, !noalias !5557
  %_66.0.i = extractvalue { i64, ptr } %108, 0
  %_66.1.i = extractvalue { i64, ptr } %108, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_67.i), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %_75.i), !noalias !5557
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_75.i, ptr noundef nonnull align 1 dereferenceable(32) %_45.sroa.5.0.new.sroa_idx, i64 32, i1 false), !noalias !5579
  %109 = getelementptr inbounds i8, ptr %_75.i, i64 32
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %109, i8 0, i64 32, i1 false), !noalias !5557
; call anchor_lang::error::Error::with_pubkeys
  %110 = call { i64, ptr } @_ZN11anchor_lang5error5Error12with_pubkeys17hca6dbbbe6a9a5da7E(i64 noundef %_66.0.i, ptr noundef %_66.1.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(64) %_75.i) #27
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %_75.i), !noalias !5557
  br label %bb72.i

bb38.i:                                           ; preds = %bb37.i
  %111 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %t.i, ptr noundef nonnull dereferenceable(32) %holder_key, i64 32), !noalias !5591
  %112 = icmp eq i32 %111, 0
  br i1 %112, label %bb39.i, label %bb45.i

bb39.i:                                           ; preds = %bb38.i, %bb37.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_81.i), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_82.i), !noalias !5557
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_82.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_861c8964bbad6d9cede9df277e628fe9) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i47.i), !noalias !5592
  store i64 0, ptr %buf.i47.i, align 8, !noalias !5592
  %_9.sroa.4.0.buf.sroa_idx.i48.i = getelementptr inbounds i8, ptr %buf.i47.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i48.i, align 8, !noalias !5592
  %_9.sroa.5.0.buf.sroa_idx.i49.i = getelementptr inbounds i8, ptr %buf.i47.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i49.i, align 8, !noalias !5592
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i46.i), !noalias !5592
  %113 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 52
  store i32 0, ptr %113, align 4, !noalias !5592
  %114 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 48
  store i32 32, ptr %114, align 8, !noalias !5592
  %115 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 56
  store i8 3, ptr %115, align 8, !noalias !5592
  store i64 0, ptr %formatter.i46.i, align 8, !noalias !5592
  %116 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 16
  store i64 0, ptr %116, align 8, !noalias !5592
  %117 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 32
  store ptr %buf.i47.i, ptr %117, align 8, !noalias !5592
  %118 = getelementptr inbounds i8, ptr %formatter.i46.i, i64 40
  store ptr @vtable.4, ptr %118, align 8, !noalias !5592
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %119 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_861c8964bbad6d9cede9df277e628fe9, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i46.i) #27, !noalias !5596
  br i1 %119, label %bb3.i50.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i"

bb3.i50.i:                                        ; preds = %bb39.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5592
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i": ; preds = %bb39.i
  %120 = getelementptr inbounds i8, ptr %_81.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %120, ptr noundef nonnull align 8 dereferenceable(24) %buf.i47.i, i64 24, i1 false), !noalias !5557
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i46.i), !noalias !5592
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i47.i), !noalias !5592
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  %121 = getelementptr inbounds i8, ptr %_81.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %121, ptr noundef nonnull align 8 dereferenceable(24) %_82.i, i64 24, i1 false), !noalias !5557
  %122 = getelementptr inbounds i8, ptr %_81.i, i64 152
  store i32 6019, ptr %122, align 8, !noalias !5557
  store i64 0, ptr %_81.i, align 8, !noalias !5557
  %_85.sroa.4.0._81.sroa_idx.i = getelementptr inbounds i8, ptr %_81.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_85.sroa.4.0._81.sroa_idx.i, align 8, !noalias !5557
  %_85.sroa.4.sroa.4.0._85.sroa.4.0._81.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_81.i, i64 16
  store i64 38, ptr %_85.sroa.4.sroa.4.0._85.sroa.4.0._81.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_85.sroa.4.sroa.5.0._85.sroa.4.0._81.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_81.i, i64 24
  store i32 312, ptr %_85.sroa.4.sroa.5.0._85.sroa.4.0._81.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %123 = getelementptr inbounds i8, ptr %_81.i, i64 80
  store i8 2, ptr %123, align 8, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_82.i), !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %124 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_81.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_81.i), !noalias !5557
  br label %bb72.i

bb45.i:                                           ; preds = %bb38.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %target.i.sroa.0, ptr noundef nonnull align 1 dereferenceable(7) %_45.sroa.5.0.new.sroa_idx, i64 7, i1 false), !noalias !5579
  %target.i.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %new, i64 8
  %target.i.sroa.7.0.copyload304 = load i64, ptr %target.i.sroa.7.0..sroa_idx, align 1, !noalias !5579
  %target.i.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %new, i64 16
  %target.i.sroa.8.0.copyload305 = load ptr, ptr %target.i.sroa.8.0..sroa_idx, align 1, !noalias !5579
  %target.i.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %new, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %target.i.sroa.9, ptr noundef nonnull align 1 dereferenceable(9) %target.i.sroa.9.0..sroa_idx, i64 9, i1 false), !noalias !5579
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %t.i), !noalias !5557
  %.not.i = icmp eq i8 %31, 0
  %switch13.i = icmp eq i64 %0, 0
  br i1 %switch13.i, label %bb76, label %bb47.i

bb44.i:                                           ; preds = %bb22.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %target.i.sroa.0, ptr noundef nonnull align 1 dereferenceable(7) %hk, i64 7, i1 false)
  %target.i.sroa.7.0.holder_key.sroa_idx = getelementptr inbounds i8, ptr %holder_key, i64 7
  %target.i.sroa.7.0.copyload = load i64, ptr %target.i.sroa.7.0.holder_key.sroa_idx, align 1, !noalias !5591
  %target.i.sroa.8.0.holder_key.sroa_idx = getelementptr inbounds i8, ptr %holder_key, i64 15
  %target.i.sroa.8.0.copyload = load ptr, ptr %target.i.sroa.8.0.holder_key.sroa_idx, align 1, !noalias !5591
  %target.i.sroa.9.0.holder_key.sroa_idx = getelementptr inbounds i8, ptr %holder_key, i64 23
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %target.i.sroa.9, ptr noundef nonnull align 1 dereferenceable(9) %target.i.sroa.9.0.holder_key.sroa_idx, i64 9, i1 false), !noalias !5591
  %switch14.i = icmp eq i64 %0, 0
  br i1 %switch14.i, label %bb76, label %bb93.i

bb47.i:                                           ; preds = %bb45.i
  br i1 %quote_locked.sroa.0.0.off0, label %bb48.i, label %bb52.i

bb52.i:                                           ; preds = %bb47.i
  br i1 %.not.i, label %bb54.i, label %bb53.i

bb48.i:                                           ; preds = %bb93.i, %bb47.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_94.i), !noalias !5557
  %125 = getelementptr inbounds i8, ptr %_94.i, i64 32
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %125, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e75cefee4bb91125af0ea8444b842ed0) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i297), !noalias !5597
  store i64 0, ptr %buf.i297, align 8, !noalias !5597
  %_9.sroa.4.0.buf.sroa_idx.i298 = getelementptr inbounds i8, ptr %buf.i297, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i298, align 8, !noalias !5597
  %_9.sroa.5.0.buf.sroa_idx.i299 = getelementptr inbounds i8, ptr %buf.i297, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i299, align 8, !noalias !5597
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i296), !noalias !5597
  %126 = getelementptr inbounds i8, ptr %formatter.i296, i64 52
  store i32 0, ptr %126, align 4, !noalias !5597
  %127 = getelementptr inbounds i8, ptr %formatter.i296, i64 48
  store i32 32, ptr %127, align 8, !noalias !5597
  %128 = getelementptr inbounds i8, ptr %formatter.i296, i64 56
  store i8 3, ptr %128, align 8, !noalias !5597
  store i64 0, ptr %formatter.i296, align 8, !noalias !5597
  %129 = getelementptr inbounds i8, ptr %formatter.i296, i64 16
  store i64 0, ptr %129, align 8, !noalias !5597
  %130 = getelementptr inbounds i8, ptr %formatter.i296, i64 32
  store ptr %buf.i297, ptr %130, align 8, !noalias !5597
  %131 = getelementptr inbounds i8, ptr %formatter.i296, i64 40
  store ptr @vtable.4, ptr %131, align 8, !noalias !5597
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %132 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_e75cefee4bb91125af0ea8444b842ed0, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i296) #27, !noalias !5601
  br i1 %132, label %bb3.i301, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit302"

bb3.i301:                                         ; preds = %bb48.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5597
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit302": ; preds = %bb48.i
  %133 = getelementptr inbounds i8, ptr %_94.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %133, ptr noundef nonnull align 8 dereferenceable(24) %buf.i297, i64 24, i1 false), !noalias !5602
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i296), !noalias !5597
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i297), !noalias !5597
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295)
  %134 = getelementptr inbounds i8, ptr %_94.i, i64 152
  store i32 6091, ptr %134, align 8, !noalias !5557
  store i64 0, ptr %_94.i, align 8, !noalias !5557
  %_98.sroa.4.0._94.sroa_idx.i = getelementptr inbounds i8, ptr %_94.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_98.sroa.4.0._94.sroa_idx.i, align 8, !noalias !5557
  %_98.sroa.4.sroa.4.0._98.sroa.4.0._94.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_94.i, i64 16
  store i64 38, ptr %_98.sroa.4.sroa.4.0._98.sroa.4.0._94.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_98.sroa.4.sroa.5.0._98.sroa.4.0._94.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_94.i, i64 24
  store i32 326, ptr %_98.sroa.4.sroa.5.0._98.sroa.4.0._94.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %135 = getelementptr inbounds i8, ptr %_94.i, i64 80
  store i8 2, ptr %135, align 8, !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %136 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_94.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_94.i), !noalias !5557
  br label %bb73.i

bb54.i:                                           ; preds = %bb93.i, %bb52.i
  %target.i.sroa.7.1 = phi i64 [ %target.i.sroa.7.0.copyload304, %bb52.i ], [ %target.i.sroa.7.0.copyload, %bb93.i ]
  %target.i.sroa.8.1 = phi ptr [ %target.i.sroa.8.0.copyload305, %bb52.i ], [ %target.i.sroa.8.0.copyload, %bb93.i ]
  %_112.not.i = icmp eq i8 %35, 0
  br i1 %_112.not.i, label %bb59.i, label %bb58.i

bb53.i:                                           ; preds = %bb52.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_104.i), !noalias !5557
  %137 = getelementptr inbounds i8, ptr %_104.i, i64 32
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %137, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_835bb996f1795bf0338da0490417da62) #27, !noalias !5557
  %138 = getelementptr inbounds i8, ptr %_104.i, i64 56
; call <T as alloc::string::ToString>::to_string
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %138, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_835bb996f1795bf0338da0490417da62) #27, !noalias !5557
  %139 = getelementptr inbounds i8, ptr %_104.i, i64 152
  store i32 6080, ptr %139, align 8, !noalias !5557
  store i64 0, ptr %_104.i, align 8, !noalias !5557
  %_108.sroa.4.0._104.sroa_idx.i = getelementptr inbounds i8, ptr %_104.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_108.sroa.4.0._104.sroa_idx.i, align 8, !noalias !5557
  %_108.sroa.4.sroa.4.0._108.sroa.4.0._104.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_104.i, i64 16
  store i64 38, ptr %_108.sroa.4.sroa.4.0._108.sroa.4.0._104.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_108.sroa.4.sroa.5.0._108.sroa.4.0._104.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_104.i, i64 24
  store i32 330, ptr %_108.sroa.4.sroa.5.0._108.sroa.4.0._104.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %140 = getelementptr inbounds i8, ptr %_104.i, i64 80
  store i8 2, ptr %140, align 8, !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %141 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_104.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_104.i), !noalias !5557
  br label %bb73.i

bb72.i:                                           ; preds = %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i"
  %.pn.i = phi { i64, ptr } [ %94, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit37.i" ], [ %110, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit44.i" ], [ %124, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit51.i" ]
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %t.i), !noalias !5557
  br label %bb73.i

bb73.i:                                           ; preds = %bb66.i, %bb59.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i", %bb72.i, %bb53.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit302"
  %.pn.i.pn = phi { i64, ptr } [ %.pn.i, %bb72.i ], [ %158, %bb59.i ], [ %164, %bb66.i ], [ %141, %bb53.i ], [ %136, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit302" ], [ %153, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i" ]
  call void @llvm.lifetime.end.p0(i64 7, ptr nonnull %target.i.sroa.0)
  call void @llvm.lifetime.end.p0(i64 9, ptr nonnull %target.i.sroa.9)
  br label %bb75

bb79.i:                                           ; preds = %bb22.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_43.i), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_44.i), !noalias !5557
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_44.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_b5f839a6bda937f2cae73e49fc88071f) #27, !noalias !5557
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i54.i), !noalias !5603
  store i64 0, ptr %buf.i54.i, align 8, !noalias !5603
  %_9.sroa.4.0.buf.sroa_idx.i55.i = getelementptr inbounds i8, ptr %buf.i54.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i55.i, align 8, !noalias !5603
  %_9.sroa.5.0.buf.sroa_idx.i56.i = getelementptr inbounds i8, ptr %buf.i54.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i56.i, align 8, !noalias !5603
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i53.i), !noalias !5603
  %142 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 52
  store i32 0, ptr %142, align 4, !noalias !5603
  %143 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 48
  store i32 32, ptr %143, align 8, !noalias !5603
  %144 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 56
  store i8 3, ptr %144, align 8, !noalias !5603
  store i64 0, ptr %formatter.i53.i, align 8, !noalias !5603
  %145 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 16
  store i64 0, ptr %145, align 8, !noalias !5603
  %146 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 32
  store ptr %buf.i54.i, ptr %146, align 8, !noalias !5603
  %147 = getelementptr inbounds i8, ptr %formatter.i53.i, i64 40
  store ptr @vtable.4, ptr %147, align 8, !noalias !5603
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %148 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_b5f839a6bda937f2cae73e49fc88071f, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i53.i) #27, !noalias !5607
  br i1 %148, label %bb3.i57.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i"

bb3.i57.i:                                        ; preds = %bb79.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5603
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit58.i": ; preds = %bb79.i
  %149 = getelementptr inbounds i8, ptr %_43.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %149, ptr noundef nonnull align 8 dereferenceable(24) %buf.i54.i, i64 24, i1 false), !noalias !5557
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i53.i), !noalias !5603
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i54.i), !noalias !5603
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5557
  %150 = getelementptr inbounds i8, ptr %_43.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %150, ptr noundef nonnull align 8 dereferenceable(24) %_44.i, i64 24, i1 false), !noalias !5557
  %151 = getelementptr inbounds i8, ptr %_43.i, i64 152
  store i32 6090, ptr %151, align 8, !noalias !5557
  store i64 0, ptr %_43.i, align 8, !noalias !5557
  %_47.sroa.4.0._43.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_47.sroa.4.0._43.sroa_idx.i, align 8, !noalias !5557
  %_47.sroa.4.sroa.4.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 16
  store i64 38, ptr %_47.sroa.4.sroa.4.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_47.sroa.4.sroa.5.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_43.i, i64 24
  store i32 298, ptr %_47.sroa.4.sroa.5.0._47.sroa.4.0._43.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %152 = getelementptr inbounds i8, ptr %_43.i, i64 80
  store i8 2, ptr %152, align 8, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_44.i), !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %153 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_43.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_43.i), !noalias !5557
  br label %bb73.i

bb93.i:                                           ; preds = %bb44.i
  br i1 %quote_locked.sroa.0.0.off0, label %bb48.i, label %bb54.i

bb59.i:                                           ; preds = %bb54.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_114.i), !noalias !5557
  %154 = getelementptr inbounds i8, ptr %_114.i, i64 32
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %154, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_01eaaa187d2be542d4425f23ab284310) #27, !noalias !5557
  %155 = getelementptr inbounds i8, ptr %_114.i, i64 56
; call <T as alloc::string::ToString>::to_string
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %155, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_01eaaa187d2be542d4425f23ab284310) #27, !noalias !5557
  %156 = getelementptr inbounds i8, ptr %_114.i, i64 152
  store i32 6077, ptr %156, align 8, !noalias !5557
  store i64 0, ptr %_114.i, align 8, !noalias !5557
  %_118.sroa.4.0._114.sroa_idx.i = getelementptr inbounds i8, ptr %_114.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_118.sroa.4.0._114.sroa_idx.i, align 8, !noalias !5557
  %_118.sroa.4.sroa.4.0._118.sroa.4.0._114.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_114.i, i64 16
  store i64 38, ptr %_118.sroa.4.sroa.4.0._118.sroa.4.0._114.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_118.sroa.4.sroa.5.0._118.sroa.4.0._114.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_114.i, i64 24
  store i32 334, ptr %_118.sroa.4.sroa.5.0._118.sroa.4.0._114.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %157 = getelementptr inbounds i8, ptr %_114.i, i64 80
  store i8 2, ptr %157, align 8, !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %158 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_114.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_114.i), !noalias !5557
  br label %bb73.i

bb58.i:                                           ; preds = %bb54.i
  %159 = add i64 %1, -1
  %or.cond.not.i = icmp ult i64 %159, %_33
  br i1 %or.cond.not.i, label %bb76, label %bb66.i

bb66.i:                                           ; preds = %bb58.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_125.i), !noalias !5557
  %160 = getelementptr inbounds i8, ptr %_125.i, i64 32
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %160, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_973adb9e8664e25d4750ddb14e0de56a) #27, !noalias !5557
  %161 = getelementptr inbounds i8, ptr %_125.i, i64 56
; call <T as alloc::string::ToString>::to_string
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %161, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_973adb9e8664e25d4750ddb14e0de56a) #27, !noalias !5557
  %162 = getelementptr inbounds i8, ptr %_125.i, i64 152
  store i32 6078, ptr %162, align 8, !noalias !5557
  store i64 0, ptr %_125.i, align 8, !noalias !5557
  %_129.sroa.4.0._125.sroa_idx.i = getelementptr inbounds i8, ptr %_125.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_129.sroa.4.0._125.sroa_idx.i, align 8, !noalias !5557
  %_129.sroa.4.sroa.4.0._129.sroa.4.0._125.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_125.i, i64 16
  store i64 38, ptr %_129.sroa.4.sroa.4.0._129.sroa.4.0._125.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %_129.sroa.4.sroa.5.0._129.sroa.4.0._125.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_125.i, i64 24
  store i32 338, ptr %_129.sroa.4.sroa.5.0._129.sroa.4.0._125.sroa_idx.sroa_idx.i, align 8, !noalias !5557
  %163 = getelementptr inbounds i8, ptr %_125.i, i64 80
  store i8 2, ptr %163, align 8, !noalias !5557
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %164 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_125.i) #27, !noalias !5557
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_125.i), !noalias !5557
  br label %bb73.i

bb76:                                             ; preds = %bb58.i, %bb44.i, %bb45.i
  %target.i.sroa.7.0 = phi i64 [ %target.i.sroa.7.0.copyload304, %bb45.i ], [ %target.i.sroa.7.1, %bb58.i ], [ %target.i.sroa.7.0.copyload, %bb44.i ]
  %target.i.sroa.8.0 = phi ptr [ %target.i.sroa.8.0.copyload305, %bb45.i ], [ %target.i.sroa.8.1, %bb58.i ], [ %target.i.sroa.8.0.copyload, %bb44.i ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %target.sroa.0, ptr noundef nonnull align 1 dereferenceable(7) %target.i.sroa.0, i64 7, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(9) %_48.sroa.11, ptr noundef nonnull align 1 dereferenceable(9) %target.i.sroa.9, i64 9, i1 false)
  call void @llvm.lifetime.end.p0(i64 7, ptr nonnull %target.i.sroa.0)
  call void @llvm.lifetime.end.p0(i64 9, ptr nonnull %target.i.sroa.9)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %target.sroa.8, ptr noundef nonnull align 8 dereferenceable(9) %_48.sroa.11, i64 9, i1 false)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_48.sroa.11)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_539.sroa.6)
  br i1 %shared.sroa.0.0.off0, label %bb19, label %bb22

bb75:                                             ; preds = %bb73.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit23.i", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i", %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i"
  %.pn322 = phi { i64, ptr } [ %56, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i" ], [ %80, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit30.i" ], [ %68, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit23.i" ], [ %.pn.i.pn, %bb73.i ]
  %_49.sroa.16.1.ph = extractvalue { i64, ptr } %.pn322, 0
  %_49.sroa.27.1.ph = extractvalue { i64, ptr } %.pn322, 1
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_48.sroa.11)
  call void @llvm.lifetime.end.p0(i64 7, ptr nonnull %target.sroa.0)
  call void @llvm.lifetime.end.p0(i64 9, ptr nonnull %target.sroa.8)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %sk)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %st)
  br label %bb67

bb22:                                             ; preds = %bb76
  br i1 %_19.not.i, label %bb23, label %bb26

bb19:                                             ; preds = %bb76
  br i1 %_0.sroa.0.0.off0.i, label %bb26, label %bb21

bb23:                                             ; preds = %bb22
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_67)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_67, i8 0, i64 32, i1 false)
  %165 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %st, ptr noundef nonnull dereferenceable(32) %_67, i64 32)
  %166 = icmp ne i32 %165, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_67)
  br label %bb26

bb26:                                             ; preds = %bb19, %bb23, %bb22, %bb21
  %target.sroa.7.0 = phi ptr [ %_62.sroa.5.0.copyload, %bb21 ], [ %target.i.sroa.8.0, %bb22 ], [ %target.i.sroa.8.0, %bb23 ], [ %target.i.sroa.8.0, %bb19 ]
  %target.sroa.6.0 = phi i64 [ %_62.sroa.4.0.copyload, %bb21 ], [ %target.i.sroa.7.0, %bb22 ], [ %target.i.sroa.7.0, %bb23 ], [ %target.i.sroa.7.0, %bb19 ]
  %_538.sroa.0.0.off0 = phi i1 [ false, %bb21 ], [ false, %bb22 ], [ %166, %bb23 ], [ false, %bb19 ]
  %_539.sroa.0.0 = phi i8 [ %_45.sroa.0.0.copyload, %bb21 ], [ 2, %bb22 ], [ 2, %bb23 ], [ 0, %bb19 ]
  %_540.sroa.0.0.off0 = phi i1 [ false, %bb21 ], [ false, %bb22 ], [ false, %bb23 ], [ true, %bb19 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %sharing_update14.sroa.3, ptr noundef nonnull align 1 dereferenceable(32) %_539.sroa.6, i64 32, i1 false)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_539.sroa.6)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %target13, ptr noundef nonnull align 1 dereferenceable(7) %target.sroa.0, i64 7, i1 false)
  %_71.sroa.3.sroa.7.33.target13.sroa_idx = getelementptr inbounds i8, ptr %target13, i64 23
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %_71.sroa.3.sroa.7.33.target13.sroa_idx, ptr noundef nonnull align 1 dereferenceable(9) %target.sroa.8, i64 9, i1 false)
  call void @llvm.lifetime.end.p0(i64 7, ptr nonnull %target.sroa.0)
  call void @llvm.lifetime.end.p0(i64 9, ptr nonnull %target.sroa.8)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %sk)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %st)
  %167 = zext i1 %cashback.sroa.0.0.off0 to i8
  %_71.sroa.3.sroa.5.33.target13.sroa_idx = getelementptr inbounds i8, ptr %target13, i64 7
  store i64 %target.sroa.6.0, ptr %_71.sroa.3.sroa.5.33.target13.sroa_idx, align 1
  %_71.sroa.3.sroa.6.33.target13.sroa_idx = getelementptr inbounds i8, ptr %target13, i64 15
  store ptr %target.sroa.7.0, ptr %_71.sroa.3.sroa.6.33.target13.sroa_idx, align 1
  %_77 = getelementptr inbounds i8, ptr %_266, i64 48
; call pump_recovered::extend::prepare_bonding_curve
  %168 = call { i64, ptr } @_ZN14pump_recovered6extend21prepare_bonding_curve17hd9c6422a7455e9efE(ptr noalias noundef nonnull readonly align 8 dereferenceable(168) %_273, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_77, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_266) #27
  %169 = extractvalue { i64, ptr } %168, 0
  %170 = icmp eq i64 %169, 2
  br i1 %170, label %bb80, label %bb79

bb21:                                             ; preds = %bb19
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %target.sroa.0, ptr noundef nonnull align 8 dereferenceable(7) %23, i64 7, i1 false)
  %_62.sroa.4.0.st.sroa_idx = getelementptr inbounds i8, ptr %st, i64 7
  %_62.sroa.4.0.copyload = load i64, ptr %_62.sroa.4.0.st.sroa_idx, align 1
  %_62.sroa.5.0.st.sroa_idx = getelementptr inbounds i8, ptr %st, i64 15
  %_62.sroa.5.0.copyload = load ptr, ptr %_62.sroa.5.0.st.sroa_idx, align 1
  %_62.sroa.6.0.st.sroa_idx = getelementptr inbounds i8, ptr %st, i64 23
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %target.sroa.8, ptr noundef nonnull align 1 dereferenceable(9) %_62.sroa.6.0.st.sroa_idx, i64 9, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_539.sroa.6, ptr noundef nonnull align 1 dereferenceable(32) %_45.sroa.5.0.new.sroa_idx, i64 32, i1 false)
  br label %bb26

bb80:                                             ; preds = %bb26
  %_296 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %171 = getelementptr inbounds i8, ptr %_296, i64 120
  %_80 = load i64, ptr %171, align 8, !noundef !2
  %172 = icmp eq i64 %_80, 0
  br i1 %172, label %bb28, label %bb29

bb79:                                             ; preds = %bb26
  %173 = extractvalue { i64, ptr } %168, 1
  br label %bb67

bb28:                                             ; preds = %bb80
  br i1 %_538.sroa.0.0.off0, label %bb33, label %bb35

bb29:                                             ; preds = %bb80
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_82)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_83)
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_83, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8c4fa5903d7de618e7d31a64bef65c37) #27
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i), !noalias !5608
  store i64 0, ptr %buf.i, align 8, !noalias !5608
  %_9.sroa.4.0.buf.sroa_idx.i = getelementptr inbounds i8, ptr %buf.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i, align 8, !noalias !5608
  %_9.sroa.5.0.buf.sroa_idx.i = getelementptr inbounds i8, ptr %buf.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i, align 8, !noalias !5608
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i), !noalias !5608
  %174 = getelementptr inbounds i8, ptr %formatter.i, i64 52
  store i32 0, ptr %174, align 4, !noalias !5608
  %175 = getelementptr inbounds i8, ptr %formatter.i, i64 48
  store i32 32, ptr %175, align 8, !noalias !5608
  %176 = getelementptr inbounds i8, ptr %formatter.i, i64 56
  store i8 3, ptr %176, align 8, !noalias !5608
  store i64 0, ptr %formatter.i, align 8, !noalias !5608
  %177 = getelementptr inbounds i8, ptr %formatter.i, i64 16
  store i64 0, ptr %177, align 8, !noalias !5608
  %178 = getelementptr inbounds i8, ptr %formatter.i, i64 32
  store ptr %buf.i, ptr %178, align 8, !noalias !5608
  %179 = getelementptr inbounds i8, ptr %formatter.i, i64 40
  store ptr @vtable.4, ptr %179, align 8, !noalias !5608
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %180 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_8c4fa5903d7de618e7d31a64bef65c37, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i) #27, !noalias !5612
  br i1 %180, label %bb3.i, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit"

bb3.i:                                            ; preds = %bb29
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5608
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit": ; preds = %bb29
  %181 = getelementptr inbounds i8, ptr %_82, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %181, ptr noundef nonnull align 8 dereferenceable(24) %buf.i, i64 24, i1 false)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i), !noalias !5608
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i), !noalias !5608
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295)
  %182 = getelementptr inbounds i8, ptr %_82, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %182, ptr noundef nonnull align 8 dereferenceable(24) %_83, i64 24, i1 false)
  %183 = getelementptr inbounds i8, ptr %_82, i64 152
  store i32 6095, ptr %183, align 8
  store i64 0, ptr %_82, align 8
  %_86.sroa.4.0._82.sroa_idx = getelementptr inbounds i8, ptr %_82, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_86.sroa.4.0._82.sroa_idx, align 8
  %_86.sroa.4.sroa.4.0._86.sroa.4.0._82.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_82, i64 16
  store i64 38, ptr %_86.sroa.4.sroa.4.0._86.sroa.4.0._82.sroa_idx.sroa_idx, align 8
  %_86.sroa.4.sroa.5.0._86.sroa.4.0._82.sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_82, i64 24
  store i32 410, ptr %_86.sroa.4.sroa.5.0._86.sroa.4.0._82.sroa_idx.sroa_idx, align 8
  %184 = getelementptr inbounds i8, ptr %_82, i64 80
  store i8 2, ptr %184, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_83)
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %185 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_82) #27
  %_81.0 = extractvalue { i64, ptr } %185, 0
  %_81.1 = extractvalue { i64, ptr } %185, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_82)
  br label %bb67

bb35:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit, %bb28
  br i1 %_540.sroa.0.0.off0, label %bb84, label %bb89

bb33:                                             ; preds = %bb28
  call void @llvm.experimental.noalias.scope.decl(metadata !5613)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %val.sroa.6.i)
  %186 = getelementptr inbounds i8, ptr %_266, i64 168
  %187 = getelementptr inbounds i8, ptr %_266, i64 210
  %188 = load i8, ptr %187, align 2, !range !394, !noalias !5613, !noundef !2
  %_3.not.i = icmp eq i8 %188, 0
  br i1 %_3.not.i, label %bb2.i95, label %bb1.i

bb2.i95:                                          ; preds = %bb33
  %189 = getelementptr inbounds i8, ptr %_266, i64 192
  %_156.i = load ptr, ptr %189, align 8, !noalias !5613, !nonnull !2, !align !392, !noundef !2
  %190 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_156.i, ptr noundef nonnull dereferenceable(32) @alloc_6ca8591423d98ecbd315de1d1a6fea68, i64 32), !noalias !5613
  %.not.i96 = icmp eq i32 %190, 0
  br i1 %.not.i96, label %bb4.i, label %bb3.i97

bb1.i:                                            ; preds = %bb33
  call void @sol_log_(ptr noundef nonnull @alloc_39e806604c4c413eab24b47c5266f52c, i64 noundef 45) #27, !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb4.i:                                            ; preds = %bb2.i95
  %191 = getelementptr inbounds i8, ptr %_266, i64 209
  %192 = load i8, ptr %191, align 1, !range !394, !noalias !5613, !noundef !2
  %_7.not.i = icmp eq i8 %192, 0
  br i1 %_7.not.i, label %bb5.i, label %bb9.i

bb3.i97:                                          ; preds = %bb2.i95
  call void @sol_log_(ptr noundef nonnull @alloc_84e4dd413cb0e2cff6ff4abdd65f9f92, i64 noundef 61) #27, !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb5.i:                                            ; preds = %bb4.i
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_9.i), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_10.i), !noalias !5613
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_10.i, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_ee8d284dcc9255c78333f4d983077741) #27, !noalias !5613
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i.i89), !noalias !5616
  store i64 0, ptr %buf.i.i89, align 8, !noalias !5616
  %_9.sroa.4.0.buf.sroa_idx.i.i113 = getelementptr inbounds i8, ptr %buf.i.i89, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i.i113, align 8, !noalias !5616
  %_9.sroa.5.0.buf.sroa_idx.i.i114 = getelementptr inbounds i8, ptr %buf.i.i89, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i.i114, align 8, !noalias !5616
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i.i88), !noalias !5616
  %193 = getelementptr inbounds i8, ptr %formatter.i.i88, i64 52
  store i32 0, ptr %193, align 4, !noalias !5616
  %194 = getelementptr inbounds i8, ptr %formatter.i.i88, i64 48
  store i32 32, ptr %194, align 8, !noalias !5616
  %195 = getelementptr inbounds i8, ptr %formatter.i.i88, i64 56
  store i8 3, ptr %195, align 8, !noalias !5616
  store i64 0, ptr %formatter.i.i88, align 8, !noalias !5616
  %196 = getelementptr inbounds i8, ptr %formatter.i.i88, i64 16
  store i64 0, ptr %196, align 8, !noalias !5616
  %197 = getelementptr inbounds i8, ptr %formatter.i.i88, i64 32
  store ptr %buf.i.i89, ptr %197, align 8, !noalias !5616
  %198 = getelementptr inbounds i8, ptr %formatter.i.i88, i64 40
  store ptr @vtable.4, ptr %198, align 8, !noalias !5616
; call <pump_recovered::PumpError as core::fmt::Display>::fmt
  %199 = call noundef zeroext i1 @"_ZN64_$LT$pump_recovered..PumpError$u20$as$u20$core..fmt..Display$GT$3fmt17hbf6a90ed7cf777ebE"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_ee8d284dcc9255c78333f4d983077741, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i.i88) #27, !noalias !5620
  br i1 %199, label %bb3.i.i116, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i115"

bb3.i.i116:                                       ; preds = %bb5.i
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5616
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i115": ; preds = %bb5.i
  %200 = getelementptr inbounds i8, ptr %_9.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %200, ptr noundef nonnull align 8 dereferenceable(24) %buf.i.i89, i64 24, i1 false), !noalias !5613
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i.i88), !noalias !5616
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i.i89), !noalias !5616
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5613
  %201 = getelementptr inbounds i8, ptr %_9.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %201, ptr noundef nonnull align 8 dereferenceable(24) %_10.i, i64 24, i1 false), !noalias !5613
  %202 = getelementptr inbounds i8, ptr %_9.i, i64 152
  store i32 6092, ptr %202, align 8, !noalias !5613
  store i64 0, ptr %_9.i, align 8, !noalias !5613
  %_13.sroa.4.0._9.sroa_idx.i = getelementptr inbounds i8, ptr %_9.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_13.sroa.4.0._9.sroa_idx.i, align 8, !noalias !5613
  %_13.sroa.4.sroa.4.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_9.i, i64 16
  store i64 38, ptr %_13.sroa.4.sroa.4.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i, align 8, !noalias !5613
  %_13.sroa.4.sroa.5.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_9.i, i64 24
  store i32 556, ptr %_13.sroa.4.sroa.5.0._13.sroa.4.0._9.sroa_idx.sroa_idx.i, align 8, !noalias !5613
  %203 = getelementptr inbounds i8, ptr %_9.i, i64 80
  store i8 2, ptr %203, align 8, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_10.i), !noalias !5613
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %204 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_9.i) #27, !noalias !5613
  %_8.0.i = extractvalue { i64, ptr } %204, 0
  %_8.1.i = extractvalue { i64, ptr } %204, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_9.i), !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit

bb9.i:                                            ; preds = %bb4.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_18.i), !noalias !5613
  %205 = getelementptr inbounds i8, ptr %_266, i64 64
  %_19.i = load ptr, ptr %205, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::admin_cto::token_frozen
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_18.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_19.i) #27, !noalias !5613
  %206 = load i64, ptr %_18.i, align 8, !range !318, !noalias !5613, !noundef !2
  %207 = icmp eq i64 %206, 2
  %208 = getelementptr inbounds i8, ptr %_18.i, i64 8
  br i1 %207, label %bb66.i98, label %bb65.i

bb66.i98:                                         ; preds = %bb9.i
  %209 = load i8, ptr %208, align 8, !range !394, !noalias !5613, !noundef !2
  %_165.not.i = icmp eq i8 %209, 0
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_18.i), !noalias !5613
  br i1 %_165.not.i, label %bb60.i, label %bb59.i99

bb65.i:                                           ; preds = %bb9.i
  %_166.1.i = load ptr, ptr %208, align 8, !noalias !5613, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_18.i), !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316

bb60.i:                                           ; preds = %bb66.i98
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_24.i93), !noalias !5613
  %210 = getelementptr inbounds i8, ptr %_266, i64 24
  %_143.i = load ptr, ptr %210, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %211 = getelementptr inbounds i8, ptr %_143.i, i64 88
  %_248.i = load ptr, ptr %211, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %_249.i = load ptr, ptr %_248.i, align 8, !noalias !5613, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_24.i93, ptr noundef nonnull align 1 dereferenceable(32) %_249.i, i64 32, i1 false), !noalias !5613
  %212 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_24.i93, ptr noundef nonnull dereferenceable(32) @alloc_e953c1d75e6a4349f2dca6892c168ab2, i64 32), !noalias !5613
  %213 = icmp eq i32 %212, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_24.i93), !noalias !5613
  %214 = getelementptr inbounds i8, ptr %_266, i64 136
  %_27.i = load ptr, ptr %214, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call solana_account_info::AccountInfo::data_is_empty
  %_26.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_27.i) #27, !noalias !5613
  %coin_present.i = xor i1 %_26.i, true
  br i1 %213, label %bb13.i, label %bb14.i100

bb59.i99:                                         ; preds = %bb66.i98
  call void @sol_log_(ptr noundef nonnull @alloc_deddac2d627577b5c14e9bbeacabf74e, i64 noundef 62) #27, !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb14.i100:                                        ; preds = %bb60.i
  %215 = getelementptr inbounds i8, ptr %_266, i64 72
  %_30.i = load ptr, ptr %215, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call solana_account_info::AccountInfo::data_is_empty
  %_29.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_30.i) #27, !noalias !5613
  br i1 %_29.i, label %bb19.i, label %bb17.i101

bb13.i:                                           ; preds = %bb60.i
  br i1 %_26.i, label %bb27.i107, label %bb20.i

bb17.i101:                                        ; preds = %bb14.i100
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_32.i), !noalias !5613
  %_33.i102 = load ptr, ptr %215, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::admin_cto::token_frozen
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_32.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_33.i102) #27, !noalias !5613
  %216 = load i64, ptr %_32.i, align 8, !range !318, !noalias !5613, !noundef !2
  %217 = icmp eq i64 %216, 2
  %218 = getelementptr inbounds i8, ptr %_32.i, i64 8
  br i1 %217, label %bb69.i, label %bb68.i

bb69.i:                                           ; preds = %bb17.i101
  %219 = load i8, ptr %218, align 8, !range !394, !noalias !5613, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_32.i), !noalias !5613
  %extract.t37.i = icmp eq i8 %219, 0
  br label %bb19.i

bb68.i:                                           ; preds = %bb17.i101
  %_173.1.i = load ptr, ptr %218, align 8, !noalias !5613, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_32.i), !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316

bb19.i:                                           ; preds = %bb69.i, %bb14.i100
  %do_collect.sroa.0.0.off0.i = phi i1 [ %extract.t37.i, %bb69.i ], [ false, %bb14.i100 ]
  br i1 %_26.i, label %bb24.i, label %bb20.i

bb20.i:                                           ; preds = %bb19.i, %bb13.i
  %do_collect.sroa.0.1.off0.i = phi i1 [ true, %bb13.i ], [ %do_collect.sroa.0.0.off0.i, %bb19.i ]
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_38.i), !noalias !5613
  %_39.i = load ptr, ptr %214, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::admin_cto::token_frozen
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_38.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_39.i) #27, !noalias !5613
  %220 = load i64, ptr %_38.i, align 8, !range !318, !noalias !5613, !noundef !2
  %221 = icmp eq i64 %220, 2
  %222 = getelementptr inbounds i8, ptr %_38.i, i64 8
  br i1 %221, label %bb71.i, label %bb70.i103

bb24.i:                                           ; preds = %bb71.i, %bb19.i
  %do_collect.sroa.0.2.off0.i = phi i1 [ %do_collect.sroa.0.1.off0.i, %bb71.i ], [ %do_collect.sroa.0.0.off0.i, %bb19.i ]
  %do_coin.sroa.0.0.off0.i = phi i1 [ %extract.t39.i, %bb71.i ], [ false, %bb19.i ]
  call void @llvm.lifetime.start.p0(i64 376, ptr nonnull %_44.i92), !noalias !5613
  %223 = getelementptr inbounds i8, ptr %_266, i64 40
  %_181.i = load ptr, ptr %223, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %224 = getelementptr inbounds i8, ptr %_44.i92, i64 24
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %224, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_181.i) #27, !noalias !5613
  call void @llvm.lifetime.start.p0(i64 288, ptr nonnull %_46.i), !noalias !5613
  %_182.i = load ptr, ptr %_266, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_46.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_182.i) #27, !noalias !5613
  %_183.i = load ptr, ptr %205, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %225 = getelementptr inbounds i8, ptr %_46.i, i64 48
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %225, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_183.i) #27, !noalias !5613
  %226 = getelementptr inbounds i8, ptr %_46.i, i64 96
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %226, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %186) #27, !noalias !5613
  %_144.i = load ptr, ptr %210, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %227 = getelementptr inbounds i8, ptr %_144.i, i64 88
  %_184.i = load ptr, ptr %227, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %228 = getelementptr inbounds i8, ptr %_46.i, i64 144
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %228, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_184.i) #27, !noalias !5613
  %_185.i = load ptr, ptr %_77, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %229 = getelementptr inbounds i8, ptr %_46.i, i64 192
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %229, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_185.i) #27, !noalias !5613
  %230 = getelementptr inbounds i8, ptr %_266, i64 32
  %_186.i = load ptr, ptr %230, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %231 = getelementptr inbounds i8, ptr %_46.i, i64 240
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %231, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_186.i) #27, !noalias !5613
  %232 = getelementptr inbounds i8, ptr %_44.i92, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(288) %232, ptr noundef nonnull align 8 dereferenceable(288) %_46.i, i64 288, i1 false), !noalias !5613
  store i64 0, ptr %_44.i92, align 8, !noalias !5613
  %_187.sroa.4.0._44.sroa_idx.i = getelementptr inbounds i8, ptr %_44.i92, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_187.sroa.4.0._44.sroa_idx.i, align 8, !noalias !5613
  %_187.sroa.5.0._44.sroa_idx.i = getelementptr inbounds i8, ptr %_44.i92, i64 16
  store i64 0, ptr %_187.sroa.5.0._44.sroa_idx.i, align 8, !noalias !5613
  %233 = getelementptr inbounds i8, ptr %_44.i92, i64 360
  store ptr inttoptr (i64 8 to ptr), ptr %233, align 8, !noalias !5613
  %234 = getelementptr inbounds i8, ptr %_44.i92, i64 368
  store i64 0, ptr %234, align 8, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 288, ptr nonnull %_46.i), !noalias !5613
; call anchor_spl::associated_token::create_idempotent
  %235 = call { i64, ptr } @_ZN10anchor_spl16associated_token17create_idempotent17h6d66b04320e05cf1E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(376) %_44.i92) #27, !noalias !5613
  %236 = extractvalue { i64, ptr } %235, 0
  call void @llvm.lifetime.end.p0(i64 376, ptr nonnull %_44.i92), !noalias !5613
  %237 = icmp eq i64 %236, 2
  br i1 %237, label %bb26.i, label %bb79.i104

bb26.i:                                           ; preds = %bb24.i
  br i1 %do_collect.sroa.0.2.off0.i, label %bb27.i107, label %bb43.i

bb71.i:                                           ; preds = %bb20.i
  %238 = load i8, ptr %222, align 8, !range !394, !noalias !5613, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_38.i), !noalias !5613
  %extract.t39.i = icmp eq i8 %238, 0
  br label %bb24.i

bb70.i103:                                        ; preds = %bb20.i
  %_178.1.i = load ptr, ptr %222, align 8, !noalias !5613, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_38.i), !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316

bb79.i104:                                        ; preds = %bb24.i
  %239 = extractvalue { i64, ptr } %235, 1
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316

bb43.i:                                           ; preds = %bb42.i, %bb26.i
  %do_coin.sroa.0.1.off076.i = phi i1 [ %do_coin.sroa.0.1.off077.i, %bb42.i ], [ %do_coin.sroa.0.0.off0.i, %bb26.i ]
  %_123.i105 = and i1 %do_coin.sroa.0.1.off076.i, %coin_present.i
  br i1 %_123.i105, label %bb44.i106, label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread

bb27.i107:                                        ; preds = %bb26.i, %bb13.i
  %do_coin.sroa.0.1.off077.i = phi i1 [ %do_coin.sroa.0.0.off0.i, %bb26.i ], [ false, %bb13.i ]
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %event_signers.i), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_58.i), !noalias !5613
  %_60.i = load ptr, ptr %205, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %_61.i = getelementptr inbounds i8, ptr %_266, i64 216
  %240 = getelementptr inbounds i8, ptr %ctx, i64 35
  %_62.i = load i8, ptr %240, align 1, !alias.scope !5613, !noundef !2
  %241 = getelementptr inbounds i8, ptr %_266, i64 72
  %_63.i = load ptr, ptr %241, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %_145.i = load ptr, ptr %210, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %242 = getelementptr inbounds i8, ptr %_145.i, i64 48
  %_64.i108 = load i8, ptr %242, align 8, !noalias !5613, !noundef !2
  %243 = getelementptr inbounds i8, ptr %_145.i, i64 88
  %_65.i = load ptr, ptr %243, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %_66.i = getelementptr inbounds i8, ptr %_266, i64 32
  %_67.i109 = load ptr, ptr %_77, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::creator::collect_creator_fee::collect
  call void @_ZN14pump_recovered7creator19collect_creator_fee7collect17h70ccda2c71c42078E(ptr noalias nocapture noundef nonnull sret([48 x i8]) align 8 dereferenceable(48) %_58.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %186, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_60.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_61.i, i8 noundef %_62.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_63.i, i8 noundef %_64.i108, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_65.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_66.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_67.i109) #27, !noalias !5613
  %244 = load i64, ptr %_58.i, align 8, !range !318, !noalias !5613, !noundef !2
  %245 = icmp eq i64 %244, 2
  %246 = getelementptr inbounds i8, ptr %_58.i, i64 8
  %_196.0.i = load i64, ptr %246, align 8, !noalias !5613
  %247 = getelementptr inbounds i8, ptr %_58.i, i64 16
  %_196.1.i = load ptr, ptr %247, align 8, !noalias !5613
  br i1 %245, label %bb81.i, label %bb82.i

bb82.i:                                           ; preds = %bb27.i107
  %_195.sroa.7.0._58.sroa_idx.i = getelementptr inbounds i8, ptr %_58.i, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %val.sroa.6.i, ptr noundef nonnull align 8 dereferenceable(24) %_195.sroa.7.0._58.sroa_idx.i, i64 24, i1 false), !noalias !5613
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_58.i), !noalias !5613
  %switch.i = icmp eq i64 %244, 1
  br i1 %switch.i, label %bb29.i, label %bb42.i

bb81.i:                                           ; preds = %bb27.i107
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_58.i), !noalias !5613
  br label %bb54.i112

bb29.i:                                           ; preds = %bb82.i
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %e.i), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_75.i91), !noalias !5613
; call solana_sysvar::clock::<impl solana_sysvar::Sysvar for solana_clock::Clock>::get
  call void @"_ZN13solana_sysvar5clock71_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_clock..Clock$GT$3get17hf864a57fc372ac1bE"(ptr noalias nocapture noundef nonnull sret([48 x i8]) align 8 dereferenceable(48) %_75.i91) #27, !noalias !5613
  %_199.i = load i64, ptr %_75.i91, align 8, !range !410, !noalias !5613, !noundef !2
  %trunc.not.i = icmp eq i64 %_199.i, 0
  br i1 %trunc.not.i, label %bb84.i, label %bb83.i

bb42.i:                                           ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i", %bb82.i
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %event_signers.i), !noalias !5613
  br label %bb43.i

bb84.i:                                           ; preds = %bb29.i
  %_200.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %_75.i91, i64 40
  %_200.sroa.8.0.copyload.i = load i64, ptr %_200.sroa.8.0..sroa_idx.i, align 8, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_75.i91), !noalias !5613
  %_203.i = load ptr, ptr %186, align 8, !noalias !5613, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %e.i, ptr noundef nonnull align 1 dereferenceable(32) %_203.i, i64 32, i1 false), !noalias !5613
  %248 = getelementptr inbounds i8, ptr %e.i, i64 64
  store i64 %_200.sroa.8.0.copyload.i, ptr %248, align 8, !noalias !5613
  %249 = getelementptr inbounds i8, ptr %e.i, i64 72
  store i64 %_196.0.i, ptr %249, align 8, !noalias !5613
  %250 = getelementptr inbounds i8, ptr %e.i, i64 32
  store ptr %_196.1.i, ptr %250, align 8, !noalias !5613
  %quote_mint.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %e.i, i64 40
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %quote_mint.sroa.2.0..sroa_idx.i, ptr noundef nonnull align 8 dereferenceable(24) %val.sroa.6.i, i64 24, i1 false), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_81.i90), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_83.i), !noalias !5613
; call <pump_recovered::creator::collect_creator_fee::CollectCreatorFeeEvent as anchor_lang::Event>::data
  call void @"_ZN107_$LT$pump_recovered..creator..collect_creator_fee..CollectCreatorFeeEvent$u20$as$u20$anchor_lang..Event$GT$4data17hf265883adc14d6aaE"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_83.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %e.i) #27, !noalias !5613
  %251 = getelementptr inbounds i8, ptr %_83.i, i64 8
  %_208.i = load ptr, ptr %251, align 8, !noalias !5613, !nonnull !2, !noundef !2
  %252 = getelementptr inbounds i8, ptr %_83.i, i64 16
  %_207.i = load i64, ptr %252, align 8, !noalias !5613, !noundef !2
  store ptr %_208.i, ptr %_81.i90, align 8, !noalias !5613
  %253 = getelementptr inbounds i8, ptr %_81.i90, i64 8
  store i64 %_207.i, ptr %253, align 8, !noalias !5613
; call solana_program::log::sol_log_data
  call void @_ZN14solana_program3log12sol_log_data17h1e024b73f122854fE(ptr noalias noundef nonnull readonly align 8 %_81.i90, i64 noundef 1) #27, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_83.i), !noalias !5613
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_81.i90), !noalias !5613
  %_86.i = getelementptr inbounds i8, ptr %_266, i64 312
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %authority_info.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_86.i) #27, !noalias !5613
  %254 = getelementptr inbounds i8, ptr %ctx, i64 46
  %authority_bump.i = load i8, ptr %254, align 2, !alias.scope !5613, !noundef !2
; call <pump_recovered::creator::collect_creator_fee::CollectCreatorFeeEvent as anchor_lang::Event>::data
  call void @"_ZN107_$LT$pump_recovered..creator..collect_creator_fee..CollectCreatorFeeEvent$u20$as$u20$anchor_lang..Event$GT$4data17hf265883adc14d6aaE"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %inner_data.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %e.i) #27, !noalias !5613
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ix_data.i), !noalias !5613
  %me.sroa.0.0.copyload.i.i = load i64, ptr %inner_data.i, align 8, !alias.scope !5621, !noalias !5624
  %me.sroa.4.0.self.sroa_idx.i.i = getelementptr inbounds i8, ptr %inner_data.i, i64 8
  %me.sroa.4.0.copyload.i.i = load ptr, ptr %me.sroa.4.0.self.sroa_idx.i.i, align 8, !alias.scope !5621, !noalias !5624, !nonnull !2, !noundef !2
  %me.sroa.5.0.self.sroa_idx.i.i = getelementptr inbounds i8, ptr %inner_data.i, i64 16
  %me.sroa.5.0.copyload.i.i = load i64, ptr %me.sroa.5.0.self.sroa_idx.i.i, align 8, !alias.scope !5621, !noalias !5624
  %_18.i.i = getelementptr inbounds i8, ptr %me.sroa.4.0.copyload.i.i, i64 %me.sroa.5.0.copyload.i.i
  %255 = getelementptr inbounds i8, ptr %_92.i, i64 32
  store ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, ptr %255, align 8, !noalias !5613
  %256 = getelementptr inbounds i8, ptr %_92.i, i64 40
  store ptr getelementptr inbounds (<{ [8 x i8] }>, ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, i64 1, i32 0, i64 0), ptr %256, align 8, !noalias !5613
  store ptr %me.sroa.4.0.copyload.i.i, ptr %_92.i, align 8, !noalias !5613
  %_218.sroa.4.0._92.sroa_idx.i = getelementptr inbounds i8, ptr %_92.i, i64 8
  store ptr %me.sroa.4.0.copyload.i.i, ptr %_218.sroa.4.0._92.sroa_idx.i, align 8, !noalias !5613
  %_218.sroa.5.0._92.sroa_idx.i = getelementptr inbounds i8, ptr %_92.i, i64 16
  store i64 %me.sroa.0.0.copyload.i.i, ptr %_218.sroa.5.0._92.sroa_idx.i, align 8, !noalias !5613
  %_218.sroa.6.0._92.sroa_idx.i = getelementptr inbounds i8, ptr %_92.i, i64 24
  store ptr %_18.i.i, ptr %_218.sroa.6.0._92.sroa_idx.i, align 8, !noalias !5613
; call <alloc::vec::Vec<T> as alloc::vec::spec_from_iter::SpecFromIter<T,I>>::from_iter
  call fastcc void @"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h05834ec09ece64f1E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %ix_data.i, ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_92.i) #27, !noalias !5613
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %ix.i), !noalias !5613
  %257 = getelementptr inbounds i8, ptr %ix_data.i, i64 8
  %_221.i = load ptr, ptr %257, align 8, !noalias !5613, !nonnull !2, !noundef !2
  %258 = getelementptr inbounds i8, ptr %ix_data.i, i64 16
  %_220.i = load i64, ptr %258, align 8, !noalias !5613, !noundef !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_100.i), !noalias !5613
; call alloc::alloc::exchange_malloc
  %_102.i = call fastcc noundef ptr @_ZN5alloc5alloc15exchange_malloc17h6cd8dd11b0e3424eE(i64 noundef 34, i64 noundef 1) #27, !noalias !5613
  %_146.i = load ptr, ptr %authority_info.i, align 8, !noalias !5613, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_102.i, ptr noundef nonnull align 1 dereferenceable(32) %_146.i, i64 32, i1 false), !noalias !5613
  %_104.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_102.i, i64 32
  store i8 1, ptr %_104.sroa.4.0..sroa_idx.i, align 1, !noalias !5613
  %_104.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_102.i, i64 33
  store i8 0, ptr %_104.sroa.5.0..sroa_idx.i, align 1, !noalias !5613
  store i64 1, ptr %_100.i, align 8, !alias.scope !5626, !noalias !5629
  %259 = getelementptr inbounds i8, ptr %_100.i, i64 8
  store ptr %_102.i, ptr %259, align 8, !alias.scope !5626, !noalias !5629
  %260 = getelementptr inbounds i8, ptr %_100.i, i64 16
  store i64 1, ptr %260, align 8, !alias.scope !5626, !noalias !5629
; call solana_instruction::Instruction::new_with_bytes
  call void @_ZN18solana_instruction11Instruction14new_with_bytes17h836fab8fb6401158E(ptr noalias nocapture noundef nonnull sret([80 x i8]) align 8 dereferenceable(80) %ix.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE, ptr noalias noundef nonnull readonly align 1 %_221.i, i64 noundef %_220.i, ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_100.i) #27, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_100.i), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %event_infos.i), !noalias !5613
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %event_infos.i, ptr noundef nonnull align 8 dereferenceable(48) %authority_info.i, i64 48, i1 false), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_112.i), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_116.i), !noalias !5613
  store i8 %authority_bump.i, ptr %_116.i, align 1, !noalias !5613
  store ptr @alloc_7a7952b5e0d15f2b72d0341cef6d4739, ptr %_112.i, align 8, !noalias !5613
  %261 = getelementptr inbounds i8, ptr %_112.i, i64 8
  store i64 17, ptr %261, align 8, !noalias !5613
  %262 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_112.i, i64 0, i64 1
  store ptr %_116.i, ptr %262, align 8, !noalias !5613
  %263 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_112.i, i64 0, i64 1, i32 1
  store i64 1, ptr %263, align 8, !noalias !5613
  store ptr %_112.i, ptr %event_signers.i, align 8, !noalias !5613
  %264 = getelementptr inbounds i8, ptr %event_signers.i, i64 8
  store i64 2, ptr %264, align 8, !noalias !5613
; call solana_program::program::invoke_signed
  call void @_ZN14solana_program7program13invoke_signed17h01c3b84bc1fc491eE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_109.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %ix.i, ptr noalias noundef nonnull readonly align 8 %event_infos.i, i64 noundef 1, ptr noalias noundef nonnull readonly align 8 %event_signers.i, i64 noundef 1) #27, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_116.i), !noalias !5613
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_112.i), !noalias !5613
  %265 = load i64, ptr %_109.i, align 8, !range !408, !noalias !5613, !noundef !2
  %266 = icmp eq i64 %265, -9223372036854775782
  br i1 %266, label %bb90.i, label %bb89.i

bb83.i:                                           ; preds = %bb29.i
  %267 = getelementptr inbounds i8, ptr %_75.i91, i64 8
  %_201.sroa.0.0.copyload.i = load i64, ptr %267, align 8, !noalias !5613
  %_201.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_75.i91, i64 16
  %_201.sroa.5.0.copyload.i = load i64, ptr %_201.sroa.5.0..sroa_idx.i, align 8, !noalias !5613
  %_201.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_75.i91, i64 24
  %_201.sroa.6.0.copyload.i = load i64, ptr %_201.sroa.6.0..sroa_idx.i, align 8, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_75.i91), !noalias !5613
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_204.i), !noalias !5613
  store i64 %_201.sroa.0.0.copyload.i, ptr %_204.i, align 8, !noalias !5613
  %residual5.sroa.2.0._204.sroa_idx.i = getelementptr inbounds i8, ptr %_204.i, i64 8
  store i64 %_201.sroa.5.0.copyload.i, ptr %residual5.sroa.2.0._204.sroa_idx.i, align 8, !noalias !5613
  %residual5.sroa.3.0._204.sroa_idx.i = getelementptr inbounds i8, ptr %_204.i, i64 16
  store i64 %_201.sroa.6.0.copyload.i, ptr %residual5.sroa.3.0._204.sroa_idx.i, align 8, !noalias !5613
; call <anchor_lang::error::Error as core::convert::From<solana_program_error::ProgramError>>::from
  %268 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_204.i) #27, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_204.i), !noalias !5613
  br label %bb53.i110

bb90.i:                                           ; preds = %bb84.i
  %269 = getelementptr inbounds i8, ptr %event_infos.i, i64 8
  %event_infos.val48.i = load ptr, ptr %269, align 8, !noalias !5613, !nonnull !2, !noundef !2
  %270 = getelementptr inbounds i8, ptr %event_infos.i, i64 16
  %event_infos.val49.i = load ptr, ptr %270, align 8, !noalias !5613
  %self1.val.i.i.i.i.i = load i64, ptr %event_infos.val48.i, align 8, !noalias !5613, !noundef !2
  %val.i.i.i.i.i = add i64 %self1.val.i.i.i.i.i, -1
  store i64 %val.i.i.i.i.i, ptr %event_infos.val48.i, align 8, !noalias !5613
  %271 = icmp eq i64 %val.i.i.i.i.i, 0
  br i1 %271, label %bb1.i.i.i.i.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"

bb1.i.i.i.i.i:                                    ; preds = %bb90.i
  %272 = getelementptr i8, ptr %event_infos.val48.i, i64 8
  %self2.val.i.i.i.i.i = load i64, ptr %272, align 8, !noalias !5613, !noundef !2
  %val6.i.i.i.i.i = add i64 %self2.val.i.i.i.i.i, -1
  store i64 %val6.i.i.i.i.i, ptr %272, align 8, !noalias !5613
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i": ; preds = %bb1.i.i.i.i.i, %bb90.i
  %273 = icmp ne ptr %event_infos.val49.i, null
  call void @llvm.assume(i1 %273)
  %self1.val.i.i2.i.i.i = load i64, ptr %event_infos.val49.i, align 8, !noalias !5613, !noundef !2
  %val.i.i3.i.i.i = add i64 %self1.val.i.i2.i.i.i, -1
  store i64 %val.i.i3.i.i.i, ptr %event_infos.val49.i, align 8, !noalias !5613
  %274 = icmp eq i64 %val.i.i3.i.i.i, 0
  br i1 %274, label %bb1.i.i4.i.i.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"

bb1.i.i4.i.i.i:                                   ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"
  %275 = getelementptr i8, ptr %event_infos.val49.i, i64 8
  %self2.val.i.i5.i.i.i = load i64, ptr %275, align 8, !noalias !5613, !noundef !2
  %val6.i.i6.i.i.i = add i64 %self2.val.i.i5.i.i.i, -1
  store i64 %val6.i.i6.i.i.i, ptr %275, align 8, !noalias !5613
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i": ; preds = %bb1.i.i4.i.i.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %event_infos.i), !noalias !5613
  %_1.val.i.i = load i64, ptr %ix.i, align 8, !alias.scope !5631, !noalias !5613, !noundef !2
  %276 = icmp eq i64 %_1.val.i.i, 0
  br i1 %276, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i", label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"
  %277 = getelementptr inbounds i8, ptr %ix.i, i64 8
  %_1.val2.i.i = load ptr, ptr %277, align 8, !alias.scope !5631, !noalias !5613
  %278 = icmp ne ptr %_1.val2.i.i, null
  call void @llvm.assume(i1 %278)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i": ; preds = %bb2.i.i.i.i.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit.i"
  %279 = getelementptr inbounds i8, ptr %ix.i, i64 24
  %.val.i.i = load i64, ptr %279, align 8, !alias.scope !5631, !noalias !5613, !noundef !2
  %280 = icmp eq i64 %.val.i.i, 0
  br i1 %280, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i"
  %281 = getelementptr inbounds i8, ptr %ix.i, i64 32
  %.val1.i.i = load ptr, ptr %281, align 8, !alias.scope !5631, !noalias !5613
  %282 = icmp ne ptr %.val1.i.i, null
  call void @llvm.assume(i1 %282)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix.i), !noalias !5613
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data.i), !noalias !5613
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %e.i), !noalias !5613
  br label %bb42.i

bb89.i:                                           ; preds = %bb84.i
; call <anchor_lang::error::Error as core::convert::From<solana_program_error::ProgramError>>::from
  %283 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_109.i) #27, !noalias !5613
  %284 = getelementptr inbounds i8, ptr %event_infos.i, i64 8
  %event_infos.val.i = load ptr, ptr %284, align 8, !noalias !5613, !nonnull !2, !noundef !2
  %285 = getelementptr inbounds i8, ptr %event_infos.i, i64 16
  %event_infos.val47.i = load ptr, ptr %285, align 8, !noalias !5613
  %self1.val.i.i.i.i52.i = load i64, ptr %event_infos.val.i, align 8, !noalias !5613, !noundef !2
  %val.i.i.i.i53.i = add i64 %self1.val.i.i.i.i52.i, -1
  store i64 %val.i.i.i.i53.i, ptr %event_infos.val.i, align 8, !noalias !5613
  %286 = icmp eq i64 %val.i.i.i.i53.i, 0
  br i1 %286, label %bb1.i.i.i.i60.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"

bb1.i.i.i.i60.i:                                  ; preds = %bb89.i
  %287 = getelementptr i8, ptr %event_infos.val.i, i64 8
  %self2.val.i.i.i.i61.i = load i64, ptr %287, align 8, !noalias !5613, !noundef !2
  %val6.i.i.i.i62.i = add i64 %self2.val.i.i.i.i61.i, -1
  store i64 %val6.i.i.i.i62.i, ptr %287, align 8, !noalias !5613
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i": ; preds = %bb1.i.i.i.i60.i, %bb89.i
  %288 = icmp ne ptr %event_infos.val47.i, null
  call void @llvm.assume(i1 %288)
  %self1.val.i.i2.i.i55.i = load i64, ptr %event_infos.val47.i, align 8, !noalias !5613, !noundef !2
  %val.i.i3.i.i56.i = add i64 %self1.val.i.i2.i.i55.i, -1
  store i64 %val.i.i3.i.i56.i, ptr %event_infos.val47.i, align 8, !noalias !5613
  %289 = icmp eq i64 %val.i.i3.i.i56.i, 0
  br i1 %289, label %bb1.i.i4.i.i57.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"

bb1.i.i4.i.i57.i:                                 ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"
  %290 = getelementptr i8, ptr %event_infos.val47.i, i64 8
  %self2.val.i.i5.i.i58.i = load i64, ptr %290, align 8, !noalias !5613, !noundef !2
  %val6.i.i6.i.i59.i = add i64 %self2.val.i.i5.i.i58.i, -1
  store i64 %val6.i.i6.i.i59.i, ptr %290, align 8, !noalias !5613
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i": ; preds = %bb1.i.i4.i.i57.i, %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i54.i"
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %event_infos.i), !noalias !5613
  %_1.val.i64.i = load i64, ptr %ix.i, align 8, !alias.scope !5634, !noalias !5613, !noundef !2
  %291 = icmp eq i64 %_1.val.i64.i, 0
  br i1 %291, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i", label %bb2.i.i.i.i65.i

bb2.i.i.i.i65.i:                                  ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"
  %292 = getelementptr inbounds i8, ptr %ix.i, i64 8
  %_1.val2.i66.i = load ptr, ptr %292, align 8, !alias.scope !5634, !noalias !5613
  %293 = icmp ne ptr %_1.val2.i66.i, null
  call void @llvm.assume(i1 %293)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i": ; preds = %bb2.i.i.i.i65.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit63.i"
  %294 = getelementptr inbounds i8, ptr %ix.i, i64 24
  %.val.i68.i = load i64, ptr %294, align 8, !alias.scope !5634, !noalias !5613, !noundef !2
  %295 = icmp eq i64 %.val.i68.i, 0
  br i1 %295, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i69.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i69.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i"
  %296 = getelementptr inbounds i8, ptr %ix.i, i64 32
  %.val1.i70.i = load ptr, ptr %296, align 8, !alias.scope !5634, !noalias !5613
  %297 = icmp ne ptr %.val1.i70.i, null
  call void @llvm.assume(i1 %297)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i": ; preds = %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i69.i", %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i67.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix.i), !noalias !5613
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data.i), !noalias !5613
  br label %bb53.i110

bb53.i110:                                        ; preds = %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i", %bb83.i
  %.pn.i111 = phi { i64, ptr } [ %268, %bb83.i ], [ %283, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit71.i" ]
  %_0.sroa.0.1.i = extractvalue { i64, ptr } %.pn.i111, 0
  %_0.sroa.11.1.i = extractvalue { i64, ptr } %.pn.i111, 1
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %e.i), !noalias !5613
  br label %bb54.i112

bb54.i112:                                        ; preds = %bb53.i110, %bb81.i
  %_0.sroa.11.2.i = phi ptr [ %_196.1.i, %bb81.i ], [ %_0.sroa.11.1.i, %bb53.i110 ]
  %_0.sroa.0.2.i = phi i64 [ %_196.0.i, %bb81.i ], [ %_0.sroa.0.1.i, %bb53.i110 ]
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %event_signers.i), !noalias !5613
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit

bb44.i106:                                        ; preds = %bb43.i
  call void @llvm.lifetime.start.p0(i64 472, ptr nonnull %_127.i), !noalias !5613
  %298 = getelementptr inbounds i8, ptr %_266, i64 88
  %_231.i = load ptr, ptr %298, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %299 = getelementptr inbounds i8, ptr %_127.i, i64 24
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %299, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_231.i) #27, !noalias !5613
  call void @llvm.lifetime.start.p0(i64 384, ptr nonnull %_129.i), !noalias !5613
  %_147.i = load ptr, ptr %210, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %300 = getelementptr inbounds i8, ptr %_147.i, i64 88
  %_232.i = load ptr, ptr %300, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_129.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_232.i) #27, !noalias !5613
  %301 = getelementptr inbounds i8, ptr %_266, i64 32
  %_233.i = load ptr, ptr %301, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %302 = getelementptr inbounds i8, ptr %_129.i, i64 48
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %302, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_233.i) #27, !noalias !5613
  %303 = getelementptr inbounds i8, ptr %_129.i, i64 96
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %303, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %186) #27, !noalias !5613
  %304 = getelementptr inbounds i8, ptr %_266, i64 128
  %_234.i = load ptr, ptr %304, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %305 = getelementptr inbounds i8, ptr %_129.i, i64 144
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %305, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_234.i) #27, !noalias !5613
  %_235.i = load ptr, ptr %214, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %306 = getelementptr inbounds i8, ptr %_129.i, i64 192
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %306, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_235.i) #27, !noalias !5613
  %_236.i = load ptr, ptr %205, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %307 = getelementptr inbounds i8, ptr %_129.i, i64 240
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %307, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_236.i) #27, !noalias !5613
  %308 = getelementptr inbounds i8, ptr %_266, i64 120
  %_237.i = load ptr, ptr %308, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %309 = getelementptr inbounds i8, ptr %_129.i, i64 288
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %309, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_237.i) #27, !noalias !5613
  %_238.i = load ptr, ptr %298, align 8, !noalias !5613, !nonnull !2, !align !3, !noundef !2
  %310 = getelementptr inbounds i8, ptr %_129.i, i64 336
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %310, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_238.i) #27, !noalias !5613
  %311 = getelementptr inbounds i8, ptr %_127.i, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(384) %311, ptr noundef nonnull align 8 dereferenceable(384) %_129.i, i64 384, i1 false), !noalias !5613
  store i64 0, ptr %_127.i, align 8, !noalias !5613
  %_239.sroa.4.0._127.sroa_idx.i = getelementptr inbounds i8, ptr %_127.i, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_239.sroa.4.0._127.sroa_idx.i, align 8, !noalias !5613
  %_239.sroa.5.0._127.sroa_idx.i = getelementptr inbounds i8, ptr %_127.i, i64 16
  store i64 0, ptr %_239.sroa.5.0._127.sroa_idx.i, align 8, !noalias !5613
  %312 = getelementptr inbounds i8, ptr %_127.i, i64 456
  store ptr inttoptr (i64 8 to ptr), ptr %312, align 8, !noalias !5613
  %313 = getelementptr inbounds i8, ptr %_127.i, i64 464
  store i64 0, ptr %313, align 8, !noalias !5613
  call void @llvm.lifetime.end.p0(i64 384, ptr nonnull %_129.i), !noalias !5613
; call pump_recovered::pump_amm::cpi::collect_coin_creator_fee
  %314 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi24collect_coin_creator_fee17h3c275eaedaa4ba35E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(472) %_127.i) #27, !noalias !5613
  %315 = extractvalue { i64, ptr } %314, 0
  call void @llvm.lifetime.end.p0(i64 472, ptr nonnull %_127.i), !noalias !5613
  %316 = icmp eq i64 %315, 2
  br i1 %316, label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread, label %bb101.i

bb101.i:                                          ; preds = %bb44.i106
  %317 = extractvalue { i64, ptr } %314, 1
  br label %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316

_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread: ; preds = %bb44.i106, %bb43.i, %bb59.i99, %bb3.i97, %bb1.i
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %val.sroa.6.i)
  br label %bb35

_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316: ; preds = %bb65.i, %bb68.i, %bb101.i, %bb79.i104, %bb70.i103
  %_0.sroa.11.4.i.ph = phi ptr [ %_178.1.i, %bb70.i103 ], [ %239, %bb79.i104 ], [ %317, %bb101.i ], [ %_173.1.i, %bb68.i ], [ %_166.1.i, %bb65.i ]
  %_0.sroa.0.4.i.ph = phi i64 [ %220, %bb70.i103 ], [ %236, %bb79.i104 ], [ %315, %bb101.i ], [ %216, %bb68.i ], [ %206, %bb65.i ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %val.sroa.6.i)
  br label %bb67

_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit: ; preds = %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i115", %bb54.i112
  %_0.sroa.11.4.i = phi ptr [ %_8.1.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i115" ], [ %_0.sroa.11.2.i, %bb54.i112 ]
  %_0.sroa.0.4.i = phi i64 [ %_8.0.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit.i115" ], [ %_0.sroa.0.2.i, %bb54.i112 ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_109.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_92.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %inner_data.i)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %authority_info.i)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %val.sroa.6.i)
  %318 = icmp eq i64 %_0.sroa.0.4.i, 2
  br i1 %318, label %bb35, label %bb67

bb84:                                             ; preds = %bb35
  %319 = getelementptr inbounds i8, ptr %ctx, i64 35
  %ctx.val84 = load i8, ptr %319, align 1
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_112.sroa.5.i)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_5.i), !noalias !5637
  %320 = getelementptr inbounds i8, ptr %_266, i64 24
  %_183.i124 = load ptr, ptr %320, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %321 = getelementptr inbounds i8, ptr %_183.i124, i64 88
  %_199.i125 = load ptr, ptr %321, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %_200.i = load ptr, ptr %_199.i125, align 8, !noalias !5637, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_5.i, ptr noundef nonnull align 1 dereferenceable(32) %_200.i, i64 32, i1 false), !noalias !5637
  %322 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_5.i, ptr noundef nonnull dereferenceable(32) @alloc_e953c1d75e6a4349f2dca6892c168ab2, i64 32), !noalias !5637
  %323 = icmp eq i32 %322, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_5.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %dest.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 33, ptr nonnull %_7.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_10.i123), !noalias !5637
  store ptr @alloc_ed0c7b53f6fd188c408cb80c27c2e0f7, ptr %_10.i123, align 8, !noalias !5637
  %324 = getelementptr inbounds i8, ptr %_10.i123, i64 8
  store i64 13, ptr %324, align 8, !noalias !5637
  %325 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_10.i123, i64 0, i64 1
  store ptr %holder_key, ptr %325, align 8, !noalias !5637
  %326 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_10.i123, i64 0, i64 1, i32 1
  store i64 32, ptr %326, align 8, !noalias !5637
; call solana_pubkey::Pubkey::find_program_address
  call void @_ZN13solana_pubkey6Pubkey20find_program_address17h57945082f260e69dE(ptr noalias nocapture noundef nonnull sret([33 x i8]) align 1 dereferenceable(33) %_7.i, ptr noalias noundef nonnull readonly align 8 %_10.i123, i64 noundef 2, ptr noalias noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE) #27, !noalias !5641
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %dest.i, ptr noundef nonnull align 1 dereferenceable(32) %_7.i, i64 32, i1 false), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_10.i123), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %_7.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_14.i), !noalias !5637
  %327 = getelementptr inbounds i8, ptr %_266, i64 264
  %_204.i126 = load ptr, ptr %327, align 8, !noalias !5637, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_14.i, ptr noundef nonnull align 1 dereferenceable(32) %_204.i126, i64 32, i1 false), !noalias !5641
  %328 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_14.i, ptr noundef nonnull dereferenceable(32) %dest.i, i64 32), !noalias !5637
  %.not.i127 = icmp eq i32 %328, 0
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_14.i), !noalias !5637
  br i1 %.not.i127, label %bb7.i135, label %bb2.i128

bb7.i135:                                         ; preds = %bb84
  %329 = getelementptr inbounds i8, ptr %_266, i64 136
  %_29.i136 = load ptr, ptr %329, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call solana_account_info::AccountInfo::data_is_empty
  %_28.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_29.i136) #27, !noalias !5641
  br i1 %_28.i, label %bb20.i152, label %bb10.i137

bb2.i128:                                         ; preds = %bb84
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_17.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_18.i122), !noalias !5637
; call anchor_lang::error::ErrorCode::name
  call void @_ZN11anchor_lang5error9ErrorCode4name17h4f8143ac990f2107E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_18.i122, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2f475e84d260dce0bf2e60beae6b9ec7) #27, !noalias !5641
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %_11.i295), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %buf.i.i119), !noalias !5642
  store i64 0, ptr %buf.i.i119, align 8, !noalias !5642
  %_9.sroa.4.0.buf.sroa_idx.i.i129 = getelementptr inbounds i8, ptr %buf.i.i119, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.buf.sroa_idx.i.i129, align 8, !noalias !5642
  %_9.sroa.5.0.buf.sroa_idx.i.i130 = getelementptr inbounds i8, ptr %buf.i.i119, i64 16
  store i64 0, ptr %_9.sroa.5.0.buf.sroa_idx.i.i130, align 8, !noalias !5642
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %formatter.i.i118), !noalias !5642
  %330 = getelementptr inbounds i8, ptr %formatter.i.i118, i64 52
  store i32 0, ptr %330, align 4, !noalias !5642
  %331 = getelementptr inbounds i8, ptr %formatter.i.i118, i64 48
  store i32 32, ptr %331, align 8, !noalias !5642
  %332 = getelementptr inbounds i8, ptr %formatter.i.i118, i64 56
  store i8 3, ptr %332, align 8, !noalias !5642
  store i64 0, ptr %formatter.i.i118, align 8, !noalias !5642
  %333 = getelementptr inbounds i8, ptr %formatter.i.i118, i64 16
  store i64 0, ptr %333, align 8, !noalias !5642
  %334 = getelementptr inbounds i8, ptr %formatter.i.i118, i64 32
  store ptr %buf.i.i119, ptr %334, align 8, !noalias !5642
  %335 = getelementptr inbounds i8, ptr %formatter.i.i118, i64 40
  store ptr @vtable.4, ptr %335, align 8, !noalias !5642
; call <anchor_lang::error::ErrorCode as core::fmt::Display>::fmt
  %336 = call noundef zeroext i1 @"_ZN68_$LT$anchor_lang..error..ErrorCode$u20$as$u20$core..fmt..Display$GT$3fmt17h3149de8d83148b03E"(ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_2f475e84d260dce0bf2e60beae6b9ec7, ptr noalias noundef nonnull align 8 dereferenceable(64) %formatter.i.i118) #27, !noalias !5646
  br i1 %336, label %bb3.i.i134, label %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i"

bb3.i.i134:                                       ; preds = %bb2.i128
; call core::result::unwrap_failed
  call void @_ZN4core6result13unwrap_failed17h2dbd2ef42161686dE(ptr noalias noundef nonnull readonly align 1 @alloc_cc656815297f75969399c3f4b1ad3de4, i64 noundef 55, ptr noundef nonnull align 1 %_11.i295, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @vtable.5, ptr noalias noundef nonnull readonly align 8 dereferenceable(24) @alloc_d5d9fccaf545b6e0545ef73245a3c43f) #28, !noalias !5646
  unreachable

"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i": ; preds = %bb2.i128
  %337 = getelementptr inbounds i8, ptr %_17.i, i64 56
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %337, ptr noundef nonnull align 8 dereferenceable(24) %buf.i.i119, i64 24, i1 false), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %formatter.i.i118), !noalias !5642
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %buf.i.i119), !noalias !5642
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %_11.i295), !noalias !5637
  %338 = getelementptr inbounds i8, ptr %_17.i, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %338, ptr noundef nonnull align 8 dereferenceable(24) %_18.i122, i64 24, i1 false), !noalias !5637
  %339 = getelementptr inbounds i8, ptr %_17.i, i64 152
  store i32 2006, ptr %339, align 8, !noalias !5637
  store i64 0, ptr %_17.i, align 8, !noalias !5637
  %_20.sroa.4.0._17.sroa_idx.i = getelementptr inbounds i8, ptr %_17.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_20.sroa.4.0._17.sroa_idx.i, align 8, !noalias !5637
  %_20.sroa.4.sroa.4.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_17.i, i64 16
  store i64 38, ptr %_20.sroa.4.sroa.4.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_20.sroa.4.sroa.5.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_17.i, i64 24
  store i32 648, ptr %_20.sroa.4.sroa.5.0._20.sroa.4.0._17.sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %340 = getelementptr inbounds i8, ptr %_17.i, i64 80
  store i8 2, ptr %340, align 8, !noalias !5637
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_18.i122), !noalias !5637
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %341 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_17.i) #27, !noalias !5641
  %_16.0.i = extractvalue { i64, ptr } %341, 0
  %_16.1.i = extractvalue { i64, ptr } %341, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_17.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %_24.i121), !noalias !5637
  %_208.i131 = load ptr, ptr %327, align 8, !noalias !5637, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_24.i121, ptr noundef nonnull align 1 dereferenceable(32) %_208.i131, i64 32, i1 false), !noalias !5641
  %342 = getelementptr inbounds i8, ptr %_24.i121, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %342, ptr noundef nonnull align 1 dereferenceable(32) %dest.i, i64 32, i1 false), !noalias !5637
; call anchor_lang::error::Error::with_pubkeys
  %343 = call { i64, ptr } @_ZN11anchor_lang5error5Error12with_pubkeys17hca6dbbbe6a9a5da7E(i64 noundef %_16.0.i, ptr noundef %_16.1.i, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(64) %_24.i121) #27
  %_15.0.i = extractvalue { i64, ptr } %343, 0
  %_15.1.i = extractvalue { i64, ptr } %343, 1
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %_24.i121), !noalias !5637
  br label %bb59.i132

bb10.i137:                                        ; preds = %bb7.i135
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_31.i), !noalias !5637
  %_32.i138 = load ptr, ptr %329, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::admin_cto::token_frozen
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_31.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_32.i138) #27, !noalias !5641
  %344 = load i64, ptr %_31.i, align 8, !range !318, !noalias !5637, !noundef !2
  %345 = icmp eq i64 %344, 2
  %346 = getelementptr inbounds i8, ptr %_31.i, i64 8
  br i1 %345, label %bb64.i, label %bb63.i

bb64.i:                                           ; preds = %bb10.i137
  %347 = load i8, ptr %346, align 8, !range !394, !noalias !5637, !noundef !2
  %_210.not.i = icmp eq i8 %347, 0
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_31.i), !noalias !5637
  br i1 %_210.not.i, label %bb20.i152, label %bb13.i139

bb63.i:                                           ; preds = %bb10.i137
  %_211.1.i = load ptr, ptr %346, align 8, !noalias !5637, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_31.i), !noalias !5637
  br label %bb59.i132

bb20.i152:                                        ; preds = %bb64.i, %bb7.i135
  %_51.i = load ptr, ptr %329, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call solana_account_info::AccountInfo::data_is_empty
  %_50.i = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_51.i) #27, !noalias !5641
  br i1 %_50.i, label %bb25.i, label %bb22.i153

bb13.i139:                                        ; preds = %bb64.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_37.i), !noalias !5637
  %_38.i140 = load ptr, ptr %329, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::admin_cto::token_raw_amount
  call fastcc void @_ZN14pump_recovered9admin_cto16token_raw_amount17h5c5bab1f81c4ceb2E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_37.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_38.i140) #27, !noalias !5641
  %348 = load i64, ptr %_37.i, align 8, !range !318, !noalias !5637, !noundef !2
  %349 = icmp eq i64 %348, 2
  %350 = getelementptr inbounds i8, ptr %_37.i, i64 8
  br i1 %349, label %bb66.i142, label %bb65.i141

bb66.i142:                                        ; preds = %bb13.i139
  %_215.i = load i64, ptr %350, align 8, !noalias !5637, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_37.i), !noalias !5637
  %351 = icmp eq i64 %_215.i, 0
  br i1 %351, label %bb25.i, label %bb16.i143

bb65.i141:                                        ; preds = %bb13.i139
  %_216.1.i = load ptr, ptr %350, align 8, !noalias !5637, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_37.i), !noalias !5637
  br label %bb59.i132

bb16.i143:                                        ; preds = %bb66.i142
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_42.i), !noalias !5637
  %352 = getelementptr inbounds i8, ptr %_42.i, i64 32
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %352, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #27, !noalias !5641
  %353 = getelementptr inbounds i8, ptr %_42.i, i64 56
; call <T as alloc::string::ToString>::to_string
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %353, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #27, !noalias !5641
  %354 = getelementptr inbounds i8, ptr %_42.i, i64 152
  store i32 6093, ptr %354, align 8, !noalias !5637
  store i64 0, ptr %_42.i, align 8, !noalias !5637
  %_46.sroa.4.0._42.sroa_idx.i = getelementptr inbounds i8, ptr %_42.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_46.sroa.4.0._42.sroa_idx.i, align 8, !noalias !5637
  %_46.sroa.4.sroa.4.0._46.sroa.4.0._42.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_42.i, i64 16
  store i64 38, ptr %_46.sroa.4.sroa.4.0._46.sroa.4.0._42.sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_46.sroa.4.sroa.5.0._46.sroa.4.0._42.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_42.i, i64 24
  store i32 660, ptr %_46.sroa.4.sroa.5.0._46.sroa.4.0._42.sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %355 = getelementptr inbounds i8, ptr %_42.i, i64 80
  store i8 2, ptr %355, align 8, !noalias !5637
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %356 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_42.i) #27, !noalias !5641
  %_41.0.i = extractvalue { i64, ptr } %356, 0
  %_41.1.i = extractvalue { i64, ptr } %356, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_42.i), !noalias !5637
  br label %bb59.i132

bb25.i:                                           ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209.i, %bb66.i142, %bb20.i152
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %vsigner.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %old.i), !noalias !5637
  %357 = getelementptr inbounds i8, ptr %_266, i64 168
  %_264.i = load ptr, ptr %357, align 8, !noalias !5637, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %old.i, ptr noundef nonnull align 1 dereferenceable(32) %_264.i, i64 32, i1 false), !noalias !5641
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_105.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_110.i), !noalias !5637
  store i8 %ctx.val84, ptr %_110.i, align 1, !noalias !5637
  store ptr @alloc_ed0c7b53f6fd188c408cb80c27c2e0f7, ptr %_105.i, align 8, !noalias !5637
  %358 = getelementptr inbounds i8, ptr %_105.i, i64 8
  store i64 13, ptr %358, align 8, !noalias !5637
  %359 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_105.i, i64 0, i64 1
  store ptr %old.i, ptr %359, align 8, !noalias !5637
  %360 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_105.i, i64 0, i64 1, i32 1
  store i64 32, ptr %360, align 8, !noalias !5637
  %361 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_105.i, i64 0, i64 2
  store ptr %_110.i, ptr %361, align 8, !noalias !5637
  %362 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_105.i, i64 0, i64 2, i32 1
  store i64 1, ptr %362, align 8, !noalias !5637
  store ptr %_105.i, ptr %vsigner.i, align 8, !noalias !5637
  %363 = getelementptr inbounds i8, ptr %vsigner.i, i64 8
  store i64 3, ptr %363, align 8, !noalias !5637
  br i1 %323, label %bb26.i148, label %bb35.i

bb22.i153:                                        ; preds = %bb20.i152
  call void @llvm.lifetime.start.p0(i64 664, ptr nonnull %_54.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_55.sroa.11.i)
  %364 = getelementptr inbounds i8, ptr %_266, i64 88
  %x.i = load ptr, ptr %364, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %_184.i154 = load ptr, ptr %x.i, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %365 = getelementptr inbounds i8, ptr %x.i, i64 24
  %_185.i155 = load ptr, ptr %365, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %366 = getelementptr inbounds i8, ptr %x.i, i64 8
  %_221.i156 = load ptr, ptr %366, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i.i = load i64, ptr %_221.i156, align 8, !noalias !5641, !noundef !2
  %cond.i.i = icmp ne i64 %self.val.i.i, 0
  call void @llvm.assume(i1 %cond.i.i)
  %strong1.i.i = add i64 %self.val.i.i, 1
  store i64 %strong1.i.i, ptr %_221.i156, align 8, !noalias !5641
  %_7.i.i = icmp eq i64 %strong1.i.i, 0
  br i1 %_7.i.i, label %bb4.i.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i

bb4.i.i:                                          ; preds = %bb22.i153
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i: ; preds = %bb22.i153
  %367 = getelementptr inbounds i8, ptr %x.i, i64 16
  %_225.i = load ptr, ptr %367, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i33.i = load i64, ptr %_225.i, align 8, !noalias !5641, !noundef !2
  %cond.i34.i = icmp ne i64 %self.val.i33.i, 0
  call void @llvm.assume(i1 %cond.i34.i)
  %strong1.i35.i = add i64 %self.val.i33.i, 1
  store i64 %strong1.i35.i, ptr %_225.i, align 8, !noalias !5641
  %_7.i36.i = icmp eq i64 %strong1.i35.i, 0
  br i1 %_7.i36.i, label %bb4.i37.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i

bb4.i37.i:                                        ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i
  %368 = getelementptr inbounds i8, ptr %x.i, i64 32
  %_59.i = load i64, ptr %368, align 8, !noalias !5641, !noundef !2
  %369 = getelementptr inbounds i8, ptr %x.i, i64 42
  %370 = load i8, ptr %369, align 2, !range !394, !noalias !5641, !noundef !2
  %371 = getelementptr inbounds i8, ptr %x.i, i64 41
  %372 = load i8, ptr %371, align 1, !range !394, !noalias !5641, !noundef !2
  %373 = getelementptr inbounds i8, ptr %x.i, i64 40
  %374 = load i8, ptr %373, align 8, !range !394, !noalias !5641, !noundef !2
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_63.sroa.20.sroa.11.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_63.sroa.21.sroa.11.i)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_63.sroa.22.sroa.11.i)
  %_227.i = load ptr, ptr %_266, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5647)
  %_2.i.i = load ptr, ptr %_227.i, align 8, !alias.scope !5647, !noalias !5650, !nonnull !2, !align !392, !noundef !2
  %375 = getelementptr inbounds i8, ptr %_227.i, i64 8
  %_12.i.i = load ptr, ptr %375, align 8, !alias.scope !5647, !noalias !5650, !nonnull !2, !noundef !2
  %self.val.i.i.i = load i64, ptr %_12.i.i, align 8, !noalias !5652, !noundef !2
  %cond.i.i.i = icmp ne i64 %self.val.i.i.i, 0
  call void @llvm.assume(i1 %cond.i.i.i)
  %strong1.i.i.i = add i64 %self.val.i.i.i, 1
  store i64 %strong1.i.i.i, ptr %_12.i.i, align 8, !noalias !5652
  %_7.i.i.i = icmp eq i64 %strong1.i.i.i, 0
  br i1 %_7.i.i.i, label %bb4.i.i.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i

bb4.i.i.i:                                        ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit.i
  %376 = getelementptr inbounds i8, ptr %_227.i, i64 16
  %_16.i.i = load ptr, ptr %376, align 8, !alias.scope !5647, !noalias !5650, !nonnull !2, !noundef !2
  %self.val.i1.i.i = load i64, ptr %_16.i.i, align 8, !noalias !5652, !noundef !2
  %cond.i2.i.i = icmp ne i64 %self.val.i1.i.i, 0
  call void @llvm.assume(i1 %cond.i2.i.i)
  %strong1.i3.i.i = add i64 %self.val.i1.i.i, 1
  store i64 %strong1.i3.i.i, ptr %_16.i.i, align 8, !noalias !5652
  %_7.i4.i.i = icmp eq i64 %strong1.i3.i.i, 0
  br i1 %_7.i4.i.i, label %bb4.i5.i.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i"

bb4.i5.i.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i.i
  %377 = getelementptr inbounds i8, ptr %_227.i, i64 24
  %_5.i.i = load ptr, ptr %377, align 8, !alias.scope !5647, !noalias !5650, !nonnull !2, !align !392, !noundef !2
  %378 = getelementptr inbounds i8, ptr %_227.i, i64 32
  %_6.i.i = load i64, ptr %378, align 8, !alias.scope !5647, !noalias !5650, !noundef !2
  %379 = getelementptr inbounds i8, ptr %_227.i, i64 40
  %380 = load i8, ptr %379, align 8, !range !394, !alias.scope !5647, !noalias !5650, !noundef !2
  %381 = getelementptr inbounds i8, ptr %_227.i, i64 41
  %382 = load i8, ptr %381, align 1, !range !394, !alias.scope !5647, !noalias !5650, !noundef !2
  %383 = getelementptr inbounds i8, ptr %_227.i, i64 42
  %384 = load i8, ptr %383, align 2, !range !394, !alias.scope !5647, !noalias !5650, !noundef !2
  %_186.i157 = load ptr, ptr %320, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %385 = getelementptr inbounds i8, ptr %_186.i157, i64 88
  %_228.i = load ptr, ptr %385, align 8, !noalias !5641, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5653)
  %_2.i38.i = load ptr, ptr %_228.i, align 8, !alias.scope !5653, !noalias !5656, !nonnull !2, !align !392, !noundef !2
  %386 = getelementptr inbounds i8, ptr %_228.i, i64 8
  %_12.i39.i = load ptr, ptr %386, align 8, !alias.scope !5653, !noalias !5656, !nonnull !2, !noundef !2
  %self.val.i.i40.i = load i64, ptr %_12.i39.i, align 8, !noalias !5658, !noundef !2
  %cond.i.i41.i = icmp ne i64 %self.val.i.i40.i, 0
  call void @llvm.assume(i1 %cond.i.i41.i)
  %strong1.i.i42.i = add i64 %self.val.i.i40.i, 1
  store i64 %strong1.i.i42.i, ptr %_12.i39.i, align 8, !noalias !5658
  %_7.i.i43.i = icmp eq i64 %strong1.i.i42.i, 0
  br i1 %_7.i.i43.i, label %bb4.i.i53.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i44.i

bb4.i.i53.i:                                      ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i44.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit.i"
  %387 = getelementptr inbounds i8, ptr %_228.i, i64 16
  %_16.i45.i = load ptr, ptr %387, align 8, !alias.scope !5653, !noalias !5656, !nonnull !2, !noundef !2
  %self.val.i1.i46.i = load i64, ptr %_16.i45.i, align 8, !noalias !5658, !noundef !2
  %cond.i2.i47.i = icmp ne i64 %self.val.i1.i46.i, 0
  call void @llvm.assume(i1 %cond.i2.i47.i)
  %strong1.i3.i48.i = add i64 %self.val.i1.i46.i, 1
  store i64 %strong1.i3.i48.i, ptr %_16.i45.i, align 8, !noalias !5658
  %_7.i4.i49.i = icmp eq i64 %strong1.i3.i48.i, 0
  br i1 %_7.i4.i49.i, label %bb4.i5.i52.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit54.i"

bb4.i5.i52.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i44.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit54.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i44.i
  %388 = getelementptr inbounds i8, ptr %_228.i, i64 24
  %_5.i50.i = load ptr, ptr %388, align 8, !alias.scope !5653, !noalias !5656, !nonnull !2, !align !392, !noundef !2
  %389 = getelementptr inbounds i8, ptr %_228.i, i64 32
  %_6.i51.i = load i64, ptr %389, align 8, !alias.scope !5653, !noalias !5656, !noundef !2
  %390 = getelementptr inbounds i8, ptr %_228.i, i64 40
  %391 = load i8, ptr %390, align 8, !range !394, !alias.scope !5653, !noalias !5656, !noundef !2
  %392 = getelementptr inbounds i8, ptr %_228.i, i64 41
  %393 = load i8, ptr %392, align 1, !range !394, !alias.scope !5653, !noalias !5656, !noundef !2
  %394 = getelementptr inbounds i8, ptr %_228.i, i64 42
  %395 = load i8, ptr %394, align 2, !range !394, !alias.scope !5653, !noalias !5656, !noundef !2
  %396 = getelementptr inbounds i8, ptr %_266, i64 32
  %_229.i = load ptr, ptr %396, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5659)
  %_2.i55.i = load ptr, ptr %_229.i, align 8, !alias.scope !5659, !noalias !5662, !nonnull !2, !align !392, !noundef !2
  %397 = getelementptr inbounds i8, ptr %_229.i, i64 8
  %_12.i56.i = load ptr, ptr %397, align 8, !alias.scope !5659, !noalias !5662, !nonnull !2, !noundef !2
  %self.val.i.i57.i = load i64, ptr %_12.i56.i, align 8, !noalias !5664, !noundef !2
  %cond.i.i58.i = icmp ne i64 %self.val.i.i57.i, 0
  call void @llvm.assume(i1 %cond.i.i58.i)
  %strong1.i.i59.i = add i64 %self.val.i.i57.i, 1
  store i64 %strong1.i.i59.i, ptr %_12.i56.i, align 8, !noalias !5664
  %_7.i.i60.i = icmp eq i64 %strong1.i.i59.i, 0
  br i1 %_7.i.i60.i, label %bb4.i.i70.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i61.i

bb4.i.i70.i:                                      ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit54.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i61.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit54.i"
  %398 = getelementptr inbounds i8, ptr %_229.i, i64 16
  %_16.i62.i = load ptr, ptr %398, align 8, !alias.scope !5659, !noalias !5662, !nonnull !2, !noundef !2
  %self.val.i1.i63.i = load i64, ptr %_16.i62.i, align 8, !noalias !5664, !noundef !2
  %cond.i2.i64.i = icmp ne i64 %self.val.i1.i63.i, 0
  call void @llvm.assume(i1 %cond.i2.i64.i)
  %strong1.i3.i65.i = add i64 %self.val.i1.i63.i, 1
  store i64 %strong1.i3.i65.i, ptr %_16.i62.i, align 8, !noalias !5664
  %_7.i4.i66.i = icmp eq i64 %strong1.i3.i65.i, 0
  br i1 %_7.i4.i66.i, label %bb4.i5.i69.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit71.i"

bb4.i5.i69.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i61.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit71.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i61.i
  %399 = getelementptr inbounds i8, ptr %_229.i, i64 24
  %_5.i67.i = load ptr, ptr %399, align 8, !alias.scope !5659, !noalias !5662, !nonnull !2, !align !392, !noundef !2
  %400 = getelementptr inbounds i8, ptr %_229.i, i64 32
  %_6.i68.i = load i64, ptr %400, align 8, !alias.scope !5659, !noalias !5662, !noundef !2
  %401 = getelementptr inbounds i8, ptr %_229.i, i64 40
  %402 = load i8, ptr %401, align 8, !range !394, !alias.scope !5659, !noalias !5662, !noundef !2
  %403 = getelementptr inbounds i8, ptr %_229.i, i64 41
  %404 = load i8, ptr %403, align 1, !range !394, !alias.scope !5659, !noalias !5662, !noundef !2
  %405 = getelementptr inbounds i8, ptr %_229.i, i64 42
  %406 = load i8, ptr %405, align 2, !range !394, !alias.scope !5659, !noalias !5662, !noundef !2
  %_230.i = load ptr, ptr %_77, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5665)
  %_2.i72.i = load ptr, ptr %_230.i, align 8, !alias.scope !5665, !noalias !5668, !nonnull !2, !align !392, !noundef !2
  %407 = getelementptr inbounds i8, ptr %_230.i, i64 8
  %_12.i73.i = load ptr, ptr %407, align 8, !alias.scope !5665, !noalias !5668, !nonnull !2, !noundef !2
  %self.val.i.i74.i = load i64, ptr %_12.i73.i, align 8, !noalias !5670, !noundef !2
  %cond.i.i75.i = icmp ne i64 %self.val.i.i74.i, 0
  call void @llvm.assume(i1 %cond.i.i75.i)
  %strong1.i.i76.i = add i64 %self.val.i.i74.i, 1
  store i64 %strong1.i.i76.i, ptr %_12.i73.i, align 8, !noalias !5670
  %_7.i.i77.i = icmp eq i64 %strong1.i.i76.i, 0
  br i1 %_7.i.i77.i, label %bb4.i.i87.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i78.i

bb4.i.i87.i:                                      ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit71.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i78.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit71.i"
  %408 = getelementptr inbounds i8, ptr %_230.i, i64 16
  %_16.i79.i = load ptr, ptr %408, align 8, !alias.scope !5665, !noalias !5668, !nonnull !2, !noundef !2
  %self.val.i1.i80.i = load i64, ptr %_16.i79.i, align 8, !noalias !5670, !noundef !2
  %cond.i2.i81.i = icmp ne i64 %self.val.i1.i80.i, 0
  call void @llvm.assume(i1 %cond.i2.i81.i)
  %strong1.i3.i82.i = add i64 %self.val.i1.i80.i, 1
  store i64 %strong1.i3.i82.i, ptr %_16.i79.i, align 8, !noalias !5670
  %_7.i4.i83.i = icmp eq i64 %strong1.i3.i82.i, 0
  br i1 %_7.i4.i83.i, label %bb4.i5.i86.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit88.i"

bb4.i5.i86.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i78.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit88.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i78.i
  %409 = getelementptr inbounds i8, ptr %_230.i, i64 24
  %_5.i84.i = load ptr, ptr %409, align 8, !alias.scope !5665, !noalias !5668, !nonnull !2, !align !392, !noundef !2
  %410 = getelementptr inbounds i8, ptr %_230.i, i64 32
  %_6.i85.i = load i64, ptr %410, align 8, !alias.scope !5665, !noalias !5668, !noundef !2
  %411 = getelementptr inbounds i8, ptr %_230.i, i64 40
  %412 = load i8, ptr %411, align 8, !range !394, !alias.scope !5665, !noalias !5668, !noundef !2
  %413 = getelementptr inbounds i8, ptr %_230.i, i64 41
  %414 = load i8, ptr %413, align 1, !range !394, !alias.scope !5665, !noalias !5668, !noundef !2
  %415 = getelementptr inbounds i8, ptr %_230.i, i64 42
  %416 = load i8, ptr %415, align 2, !range !394, !alias.scope !5665, !noalias !5668, !noundef !2
  %417 = getelementptr inbounds i8, ptr %_266, i64 40
  %_231.i158 = load ptr, ptr %417, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5671)
  %_2.i89.i = load ptr, ptr %_231.i158, align 8, !alias.scope !5671, !noalias !5674, !nonnull !2, !align !392, !noundef !2
  %418 = getelementptr inbounds i8, ptr %_231.i158, i64 8
  %_12.i90.i = load ptr, ptr %418, align 8, !alias.scope !5671, !noalias !5674, !nonnull !2, !noundef !2
  %self.val.i.i91.i = load i64, ptr %_12.i90.i, align 8, !noalias !5676, !noundef !2
  %cond.i.i92.i = icmp ne i64 %self.val.i.i91.i, 0
  call void @llvm.assume(i1 %cond.i.i92.i)
  %strong1.i.i93.i = add i64 %self.val.i.i91.i, 1
  store i64 %strong1.i.i93.i, ptr %_12.i90.i, align 8, !noalias !5676
  %_7.i.i94.i = icmp eq i64 %strong1.i.i93.i, 0
  br i1 %_7.i.i94.i, label %bb4.i.i104.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i95.i

bb4.i.i104.i:                                     ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit88.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i95.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit88.i"
  %419 = getelementptr inbounds i8, ptr %_231.i158, i64 16
  %_16.i96.i = load ptr, ptr %419, align 8, !alias.scope !5671, !noalias !5674, !nonnull !2, !noundef !2
  %self.val.i1.i97.i = load i64, ptr %_16.i96.i, align 8, !noalias !5676, !noundef !2
  %cond.i2.i98.i = icmp ne i64 %self.val.i1.i97.i, 0
  call void @llvm.assume(i1 %cond.i2.i98.i)
  %strong1.i3.i99.i = add i64 %self.val.i1.i97.i, 1
  store i64 %strong1.i3.i99.i, ptr %_16.i96.i, align 8, !noalias !5676
  %_7.i4.i100.i = icmp eq i64 %strong1.i3.i99.i, 0
  br i1 %_7.i4.i100.i, label %bb4.i5.i103.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit105.i"

bb4.i5.i103.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i95.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit105.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i95.i
  %420 = getelementptr inbounds i8, ptr %_231.i158, i64 24
  %_5.i101.i = load ptr, ptr %420, align 8, !alias.scope !5671, !noalias !5674, !nonnull !2, !align !392, !noundef !2
  %421 = getelementptr inbounds i8, ptr %_231.i158, i64 32
  %_6.i102.i = load i64, ptr %421, align 8, !alias.scope !5671, !noalias !5674, !noundef !2
  %422 = getelementptr inbounds i8, ptr %_231.i158, i64 40
  %423 = load i8, ptr %422, align 8, !range !394, !alias.scope !5671, !noalias !5674, !noundef !2
  %424 = getelementptr inbounds i8, ptr %_231.i158, i64 41
  %425 = load i8, ptr %424, align 1, !range !394, !alias.scope !5671, !noalias !5674, !noundef !2
  %426 = getelementptr inbounds i8, ptr %_231.i158, i64 42
  %427 = load i8, ptr %426, align 2, !range !394, !alias.scope !5671, !noalias !5674, !noundef !2
  %_70.i = getelementptr inbounds i8, ptr %_266, i64 168
  call void @llvm.experimental.noalias.scope.decl(metadata !5677)
  %_2.i106.i = load ptr, ptr %_70.i, align 8, !alias.scope !5677, !noalias !5680, !nonnull !2, !align !392, !noundef !2
  %428 = getelementptr inbounds i8, ptr %_266, i64 176
  %_12.i107.i = load ptr, ptr %428, align 8, !alias.scope !5677, !noalias !5680, !nonnull !2, !noundef !2
  %self.val.i.i108.i = load i64, ptr %_12.i107.i, align 8, !noalias !5682, !noundef !2
  %cond.i.i109.i = icmp ne i64 %self.val.i.i108.i, 0
  call void @llvm.assume(i1 %cond.i.i109.i)
  %strong1.i.i110.i = add i64 %self.val.i.i108.i, 1
  store i64 %strong1.i.i110.i, ptr %_12.i107.i, align 8, !noalias !5682
  %_7.i.i111.i = icmp eq i64 %strong1.i.i110.i, 0
  br i1 %_7.i.i111.i, label %bb4.i.i121.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i112.i

bb4.i.i121.i:                                     ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit105.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i112.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit105.i"
  %429 = getelementptr inbounds i8, ptr %_266, i64 184
  %_16.i113.i = load ptr, ptr %429, align 8, !alias.scope !5677, !noalias !5680, !nonnull !2, !noundef !2
  %self.val.i1.i114.i = load i64, ptr %_16.i113.i, align 8, !noalias !5682, !noundef !2
  %cond.i2.i115.i = icmp ne i64 %self.val.i1.i114.i, 0
  call void @llvm.assume(i1 %cond.i2.i115.i)
  %strong1.i3.i116.i = add i64 %self.val.i1.i114.i, 1
  store i64 %strong1.i3.i116.i, ptr %_16.i113.i, align 8, !noalias !5682
  %_7.i4.i117.i = icmp eq i64 %strong1.i3.i116.i, 0
  br i1 %_7.i4.i117.i, label %bb4.i5.i120.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit122.i"

bb4.i5.i120.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i112.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit122.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i112.i
  %430 = getelementptr inbounds i8, ptr %_266, i64 192
  %_5.i118.i = load ptr, ptr %430, align 8, !alias.scope !5677, !noalias !5680, !nonnull !2, !align !392, !noundef !2
  %431 = getelementptr inbounds i8, ptr %_266, i64 200
  %_6.i119.i = load i64, ptr %431, align 8, !alias.scope !5677, !noalias !5680, !noundef !2
  %432 = getelementptr inbounds i8, ptr %_266, i64 208
  %433 = load i8, ptr %432, align 8, !range !394, !alias.scope !5677, !noalias !5680, !noundef !2
  %434 = getelementptr inbounds i8, ptr %_266, i64 209
  %435 = load i8, ptr %434, align 1, !range !394, !alias.scope !5677, !noalias !5680, !noundef !2
  %436 = getelementptr inbounds i8, ptr %_266, i64 210
  %437 = load i8, ptr %436, align 2, !range !394, !alias.scope !5677, !noalias !5680, !noundef !2
  %438 = getelementptr inbounds i8, ptr %_266, i64 128
  %_232.i159 = load ptr, ptr %438, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5683)
  %_2.i123.i = load ptr, ptr %_232.i159, align 8, !alias.scope !5683, !noalias !5686, !nonnull !2, !align !392, !noundef !2
  %439 = getelementptr inbounds i8, ptr %_232.i159, i64 8
  %_12.i124.i = load ptr, ptr %439, align 8, !alias.scope !5683, !noalias !5686, !nonnull !2, !noundef !2
  %self.val.i.i125.i = load i64, ptr %_12.i124.i, align 8, !noalias !5688, !noundef !2
  %cond.i.i126.i = icmp ne i64 %self.val.i.i125.i, 0
  call void @llvm.assume(i1 %cond.i.i126.i)
  %strong1.i.i127.i = add i64 %self.val.i.i125.i, 1
  store i64 %strong1.i.i127.i, ptr %_12.i124.i, align 8, !noalias !5688
  %_7.i.i128.i = icmp eq i64 %strong1.i.i127.i, 0
  br i1 %_7.i.i128.i, label %bb4.i.i138.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i129.i

bb4.i.i138.i:                                     ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit122.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i129.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit122.i"
  %440 = getelementptr inbounds i8, ptr %_232.i159, i64 16
  %_16.i130.i = load ptr, ptr %440, align 8, !alias.scope !5683, !noalias !5686, !nonnull !2, !noundef !2
  %self.val.i1.i131.i = load i64, ptr %_16.i130.i, align 8, !noalias !5688, !noundef !2
  %cond.i2.i132.i = icmp ne i64 %self.val.i1.i131.i, 0
  call void @llvm.assume(i1 %cond.i2.i132.i)
  %strong1.i3.i133.i = add i64 %self.val.i1.i131.i, 1
  store i64 %strong1.i3.i133.i, ptr %_16.i130.i, align 8, !noalias !5688
  %_7.i4.i134.i = icmp eq i64 %strong1.i3.i133.i, 0
  br i1 %_7.i4.i134.i, label %bb4.i5.i137.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit139.i"

bb4.i5.i137.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i129.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit139.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i129.i
  %441 = getelementptr inbounds i8, ptr %_232.i159, i64 24
  %_5.i135.i = load ptr, ptr %441, align 8, !alias.scope !5683, !noalias !5686, !nonnull !2, !align !392, !noundef !2
  %442 = getelementptr inbounds i8, ptr %_232.i159, i64 32
  %_6.i136.i = load i64, ptr %442, align 8, !alias.scope !5683, !noalias !5686, !noundef !2
  %443 = getelementptr inbounds i8, ptr %_232.i159, i64 40
  %444 = load i8, ptr %443, align 8, !range !394, !alias.scope !5683, !noalias !5686, !noundef !2
  %445 = getelementptr inbounds i8, ptr %_232.i159, i64 41
  %446 = load i8, ptr %445, align 1, !range !394, !alias.scope !5683, !noalias !5686, !noundef !2
  %447 = getelementptr inbounds i8, ptr %_232.i159, i64 42
  %448 = load i8, ptr %447, align 2, !range !394, !alias.scope !5683, !noalias !5686, !noundef !2
  %x11.i = load ptr, ptr %329, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %449 = getelementptr inbounds i8, ptr %x11.i, i64 8
  %_235.i160 = load ptr, ptr %449, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i140.i = load i64, ptr %_235.i160, align 8, !noalias !5641, !noundef !2
  %cond.i141.i = icmp ne i64 %self.val.i140.i, 0
  call void @llvm.assume(i1 %cond.i141.i)
  %strong1.i142.i = add i64 %self.val.i140.i, 1
  store i64 %strong1.i142.i, ptr %_235.i160, align 8, !noalias !5641
  %_7.i143.i = icmp eq i64 %strong1.i142.i, 0
  br i1 %_7.i143.i, label %bb4.i144.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit145.i

bb4.i144.i:                                       ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit139.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit145.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit139.i"
  %_187.i = load ptr, ptr %x11.i, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %450 = getelementptr inbounds i8, ptr %x11.i, i64 16
  %_239.i = load ptr, ptr %450, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i146.i = load i64, ptr %_239.i, align 8, !noalias !5641, !noundef !2
  %cond.i147.i = icmp ne i64 %self.val.i146.i, 0
  call void @llvm.assume(i1 %cond.i147.i)
  %strong1.i148.i = add i64 %self.val.i146.i, 1
  store i64 %strong1.i148.i, ptr %_239.i, align 8, !noalias !5641
  %_7.i149.i = icmp eq i64 %strong1.i148.i, 0
  br i1 %_7.i149.i, label %bb4.i150.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit151.i

bb4.i150.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit145.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit151.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit145.i
  %451 = getelementptr inbounds i8, ptr %x11.i, i64 24
  %_188.i = load ptr, ptr %451, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %452 = getelementptr inbounds i8, ptr %x11.i, i64 32
  %_76.i = load i64, ptr %452, align 8, !noalias !5641, !noundef !2
  %453 = getelementptr inbounds i8, ptr %x11.i, i64 40
  %454 = load i8, ptr %453, align 8, !range !394, !noalias !5641, !noundef !2
  %455 = getelementptr inbounds i8, ptr %x11.i, i64 41
  %456 = load i8, ptr %455, align 1, !range !394, !noalias !5641, !noundef !2
  %457 = getelementptr inbounds i8, ptr %x11.i, i64 42
  %458 = load i8, ptr %457, align 2, !range !394, !noalias !5641, !noundef !2
  %_81.i161 = getelementptr inbounds i8, ptr %_266, i64 216
  call void @llvm.experimental.noalias.scope.decl(metadata !5689)
  %_2.i152.i = load ptr, ptr %_81.i161, align 8, !alias.scope !5689, !noalias !5692, !nonnull !2, !align !392, !noundef !2
  %459 = getelementptr inbounds i8, ptr %_266, i64 224
  %_12.i153.i = load ptr, ptr %459, align 8, !alias.scope !5689, !noalias !5692, !nonnull !2, !noundef !2
  %self.val.i.i154.i = load i64, ptr %_12.i153.i, align 8, !noalias !5694, !noundef !2
  %cond.i.i155.i = icmp ne i64 %self.val.i.i154.i, 0
  call void @llvm.assume(i1 %cond.i.i155.i)
  %strong1.i.i156.i = add i64 %self.val.i.i154.i, 1
  store i64 %strong1.i.i156.i, ptr %_12.i153.i, align 8, !noalias !5694
  %_7.i.i157.i = icmp eq i64 %strong1.i.i156.i, 0
  br i1 %_7.i.i157.i, label %bb4.i.i167.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i158.i

bb4.i.i167.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit151.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i158.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit151.i
  %460 = getelementptr inbounds i8, ptr %_266, i64 232
  %_16.i159.i = load ptr, ptr %460, align 8, !alias.scope !5689, !noalias !5692, !nonnull !2, !noundef !2
  %self.val.i1.i160.i = load i64, ptr %_16.i159.i, align 8, !noalias !5694, !noundef !2
  %cond.i2.i161.i = icmp ne i64 %self.val.i1.i160.i, 0
  call void @llvm.assume(i1 %cond.i2.i161.i)
  %strong1.i3.i162.i = add i64 %self.val.i1.i160.i, 1
  store i64 %strong1.i3.i162.i, ptr %_16.i159.i, align 8, !noalias !5694
  %_7.i4.i163.i = icmp eq i64 %strong1.i3.i162.i, 0
  br i1 %_7.i4.i163.i, label %bb4.i5.i166.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit168.i"

bb4.i5.i166.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i158.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit168.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i158.i
  %461 = getelementptr inbounds i8, ptr %_266, i64 240
  %_5.i164.i = load ptr, ptr %461, align 8, !alias.scope !5689, !noalias !5692, !nonnull !2, !align !392, !noundef !2
  %462 = getelementptr inbounds i8, ptr %_266, i64 248
  %_6.i165.i = load i64, ptr %462, align 8, !alias.scope !5689, !noalias !5692, !noundef !2
  %463 = getelementptr inbounds i8, ptr %_266, i64 256
  %464 = load i8, ptr %463, align 8, !range !394, !alias.scope !5689, !noalias !5692, !noundef !2
  %465 = getelementptr inbounds i8, ptr %_266, i64 257
  %466 = load i8, ptr %465, align 1, !range !394, !alias.scope !5689, !noalias !5692, !noundef !2
  %467 = getelementptr inbounds i8, ptr %_266, i64 258
  %468 = load i8, ptr %467, align 2, !range !394, !alias.scope !5689, !noalias !5692, !noundef !2
  %469 = getelementptr inbounds i8, ptr %_266, i64 72
  %x12.i = load ptr, ptr %469, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %_189.i = load ptr, ptr %x12.i, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %470 = getelementptr inbounds i8, ptr %x12.i, i64 8
  %_243.i = load ptr, ptr %470, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i169.i = load i64, ptr %_243.i, align 8, !noalias !5641, !noundef !2
  %cond.i170.i = icmp ne i64 %self.val.i169.i, 0
  call void @llvm.assume(i1 %cond.i170.i)
  %strong1.i171.i = add i64 %self.val.i169.i, 1
  store i64 %strong1.i171.i, ptr %_243.i, align 8, !noalias !5641
  %_7.i172.i = icmp eq i64 %strong1.i171.i, 0
  br i1 %_7.i172.i, label %bb4.i173.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit174.i

bb4.i173.i:                                       ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit168.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit174.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit168.i"
  %471 = getelementptr inbounds i8, ptr %x12.i, i64 24
  %_190.i = load ptr, ptr %471, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %472 = getelementptr inbounds i8, ptr %x12.i, i64 16
  %_247.i = load ptr, ptr %472, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i175.i = load i64, ptr %_247.i, align 8, !noalias !5641, !noundef !2
  %cond.i176.i = icmp ne i64 %self.val.i175.i, 0
  call void @llvm.assume(i1 %cond.i176.i)
  %strong1.i177.i = add i64 %self.val.i175.i, 1
  store i64 %strong1.i177.i, ptr %_247.i, align 8, !noalias !5641
  %_7.i178.i = icmp eq i64 %strong1.i177.i, 0
  br i1 %_7.i178.i, label %bb4.i179.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit180.i

bb4.i179.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit174.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit180.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit174.i
  %473 = getelementptr inbounds i8, ptr %x12.i, i64 32
  %_86.i162 = load i64, ptr %473, align 8, !noalias !5641, !noundef !2
  %474 = getelementptr inbounds i8, ptr %x12.i, i64 40
  %475 = load i8, ptr %474, align 8, !range !394, !noalias !5641, !noundef !2
  %476 = getelementptr inbounds i8, ptr %x12.i, i64 41
  %477 = load i8, ptr %476, align 1, !range !394, !noalias !5641, !noundef !2
  %478 = getelementptr inbounds i8, ptr %x12.i, i64 42
  %479 = load i8, ptr %478, align 2, !range !394, !noalias !5641, !noundef !2
  %480 = getelementptr inbounds i8, ptr %_266, i64 120
  %_249.i163 = load ptr, ptr %480, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5695)
  %_2.i181.i = load ptr, ptr %_249.i163, align 8, !alias.scope !5695, !noalias !5698, !nonnull !2, !align !392, !noundef !2
  %481 = getelementptr inbounds i8, ptr %_249.i163, i64 8
  %_12.i182.i = load ptr, ptr %481, align 8, !alias.scope !5695, !noalias !5698, !nonnull !2, !noundef !2
  %self.val.i.i183.i = load i64, ptr %_12.i182.i, align 8, !noalias !5700, !noundef !2
  %cond.i.i184.i = icmp ne i64 %self.val.i.i183.i, 0
  call void @llvm.assume(i1 %cond.i.i184.i)
  %strong1.i.i185.i = add i64 %self.val.i.i183.i, 1
  store i64 %strong1.i.i185.i, ptr %_12.i182.i, align 8, !noalias !5700
  %_7.i.i186.i = icmp eq i64 %strong1.i.i185.i, 0
  br i1 %_7.i.i186.i, label %bb4.i.i196.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i187.i

bb4.i.i196.i:                                     ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit180.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i187.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit180.i
  %482 = getelementptr inbounds i8, ptr %_249.i163, i64 16
  %_16.i188.i = load ptr, ptr %482, align 8, !alias.scope !5695, !noalias !5698, !nonnull !2, !noundef !2
  %self.val.i1.i189.i = load i64, ptr %_16.i188.i, align 8, !noalias !5700, !noundef !2
  %cond.i2.i190.i = icmp ne i64 %self.val.i1.i189.i, 0
  call void @llvm.assume(i1 %cond.i2.i190.i)
  %strong1.i3.i191.i = add i64 %self.val.i1.i189.i, 1
  store i64 %strong1.i3.i191.i, ptr %_16.i188.i, align 8, !noalias !5700
  %_7.i4.i192.i = icmp eq i64 %strong1.i3.i191.i, 0
  br i1 %_7.i4.i192.i, label %bb4.i5.i195.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit197.i"

bb4.i5.i195.i:                                    ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i187.i
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit197.i": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i187.i
  %483 = getelementptr inbounds i8, ptr %_249.i163, i64 24
  %_5.i193.i = load ptr, ptr %483, align 8, !alias.scope !5695, !noalias !5698, !nonnull !2, !align !392, !noundef !2
  %484 = getelementptr inbounds i8, ptr %_249.i163, i64 32
  %_6.i194.i = load i64, ptr %484, align 8, !alias.scope !5695, !noalias !5698, !noundef !2
  %485 = getelementptr inbounds i8, ptr %_249.i163, i64 40
  %486 = load i8, ptr %485, align 8, !range !394, !alias.scope !5695, !noalias !5698, !noundef !2
  %487 = getelementptr inbounds i8, ptr %_249.i163, i64 41
  %488 = load i8, ptr %487, align 1, !range !394, !alias.scope !5695, !noalias !5698, !noundef !2
  %489 = getelementptr inbounds i8, ptr %_249.i163, i64 42
  %490 = load i8, ptr %489, align 2, !range !394, !alias.scope !5695, !noalias !5698, !noundef !2
  %x13.i = load ptr, ptr %364, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %_191.i = load ptr, ptr %x13.i, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %491 = getelementptr inbounds i8, ptr %x13.i, i64 24
  %_192.i = load ptr, ptr %491, align 8, !noalias !5641, !nonnull !2, !align !392, !noundef !2
  %492 = getelementptr inbounds i8, ptr %x13.i, i64 8
  %_252.i = load ptr, ptr %492, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i198.i = load i64, ptr %_252.i, align 8, !noalias !5641, !noundef !2
  %cond.i199.i = icmp ne i64 %self.val.i198.i, 0
  call void @llvm.assume(i1 %cond.i199.i)
  %strong1.i200.i = add i64 %self.val.i198.i, 1
  store i64 %strong1.i200.i, ptr %_252.i, align 8, !noalias !5641
  %_7.i201.i = icmp eq i64 %strong1.i200.i, 0
  br i1 %_7.i201.i, label %bb4.i202.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit203.i

bb4.i202.i:                                       ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit197.i"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit203.i: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit197.i"
  %493 = getelementptr inbounds i8, ptr %x13.i, i64 16
  %_256.i = load ptr, ptr %493, align 8, !noalias !5641, !nonnull !2, !noundef !2
  %self.val.i204.i = load i64, ptr %_256.i, align 8, !noalias !5641, !noundef !2
  %cond.i205.i = icmp ne i64 %self.val.i204.i, 0
  call void @llvm.assume(i1 %cond.i205.i)
  %strong1.i206.i = add i64 %self.val.i204.i, 1
  store i64 %strong1.i206.i, ptr %_256.i, align 8, !noalias !5641
  %_7.i207.i = icmp eq i64 %strong1.i206.i, 0
  br i1 %_7.i207.i, label %bb4.i208.i, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209.i

bb4.i208.i:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit203.i
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209.i: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit203.i
  %494 = getelementptr inbounds i8, ptr %x13.i, i64 32
  %_95.i = load i64, ptr %494, align 8, !noalias !5641, !noundef !2
  %495 = getelementptr inbounds i8, ptr %x13.i, i64 40
  %496 = load i8, ptr %495, align 8, !range !394, !noalias !5641, !noundef !2
  %497 = getelementptr inbounds i8, ptr %x13.i, i64 41
  %498 = load i8, ptr %497, align 1, !range !394, !noalias !5641, !noundef !2
  %499 = getelementptr inbounds i8, ptr %x13.i, i64 42
  %500 = load i8, ptr %499, align 2, !range !394, !noalias !5641, !noundef !2
  %501 = getelementptr inbounds i8, ptr %_54.i, i64 72
  store ptr %_2.i.i, ptr %501, align 8, !noalias !5637
  %_63.sroa.0.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 80
  store ptr %_12.i.i, ptr %_63.sroa.0.sroa.4.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 88
  store ptr %_16.i.i, ptr %_63.sroa.0.sroa.5.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 96
  store ptr %_5.i.i, ptr %_63.sroa.0.sroa.6.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 104
  store i64 %_6.i.i, ptr %_63.sroa.0.sroa.7.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 112
  store i8 %380, ptr %_63.sroa.0.sroa.8.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.9.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 113
  store i8 %382, ptr %_63.sroa.0.sroa.9.0..sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.0.sroa.10.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 114
  store i8 %384, ptr %_63.sroa.0.sroa.10.0..sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.0.sroa.12.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 120
  store ptr %_2.i38.i, ptr %_63.sroa.0.sroa.12.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.12.sroa.4.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 128
  store ptr %_12.i39.i, ptr %_63.sroa.0.sroa.12.sroa.4.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.12.sroa.5.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 136
  store ptr %_16.i45.i, ptr %_63.sroa.0.sroa.12.sroa.5.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.12.sroa.6.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 144
  store ptr %_5.i50.i, ptr %_63.sroa.0.sroa.12.sroa.6.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.12.sroa.7.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 152
  store i64 %_6.i51.i, ptr %_63.sroa.0.sroa.12.sroa.7.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.12.sroa.8.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 160
  store i8 %391, ptr %_63.sroa.0.sroa.12.sroa.8.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.12.sroa.9.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 161
  store i8 %393, ptr %_63.sroa.0.sroa.12.sroa.9.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.0.sroa.12.sroa.10.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 162
  store i8 %395, ptr %_63.sroa.0.sroa.12.sroa.10.0._63.sroa.0.sroa.12.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.0.sroa.13.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 168
  store ptr %_2.i55.i, ptr %_63.sroa.0.sroa.13.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.13.sroa.4.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 176
  store ptr %_12.i56.i, ptr %_63.sroa.0.sroa.13.sroa.4.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.13.sroa.5.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 184
  store ptr %_16.i62.i, ptr %_63.sroa.0.sroa.13.sroa.5.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.13.sroa.6.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 192
  store ptr %_5.i67.i, ptr %_63.sroa.0.sroa.13.sroa.6.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.13.sroa.7.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 200
  store i64 %_6.i68.i, ptr %_63.sroa.0.sroa.13.sroa.7.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.13.sroa.8.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 208
  store i8 %402, ptr %_63.sroa.0.sroa.13.sroa.8.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.13.sroa.9.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 209
  store i8 %404, ptr %_63.sroa.0.sroa.13.sroa.9.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.0.sroa.13.sroa.10.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 210
  store i8 %406, ptr %_63.sroa.0.sroa.13.sroa.10.0._63.sroa.0.sroa.13.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.0.sroa.14.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 216
  store ptr %_2.i72.i, ptr %_63.sroa.0.sroa.14.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.14.sroa.4.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 224
  store ptr %_12.i73.i, ptr %_63.sroa.0.sroa.14.sroa.4.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.14.sroa.5.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 232
  store ptr %_16.i79.i, ptr %_63.sroa.0.sroa.14.sroa.5.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.14.sroa.6.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 240
  store ptr %_5.i84.i, ptr %_63.sroa.0.sroa.14.sroa.6.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.14.sroa.7.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 248
  store i64 %_6.i85.i, ptr %_63.sroa.0.sroa.14.sroa.7.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.14.sroa.8.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 256
  store i8 %412, ptr %_63.sroa.0.sroa.14.sroa.8.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.14.sroa.9.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 257
  store i8 %414, ptr %_63.sroa.0.sroa.14.sroa.9.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.0.sroa.14.sroa.10.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 258
  store i8 %416, ptr %_63.sroa.0.sroa.14.sroa.10.0._63.sroa.0.sroa.14.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.0.sroa.15.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 264
  store ptr %_2.i89.i, ptr %_63.sroa.0.sroa.15.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.15.sroa.4.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 272
  store ptr %_12.i90.i, ptr %_63.sroa.0.sroa.15.sroa.4.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.15.sroa.5.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 280
  store ptr %_16.i96.i, ptr %_63.sroa.0.sroa.15.sroa.5.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.15.sroa.6.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 288
  store ptr %_5.i101.i, ptr %_63.sroa.0.sroa.15.sroa.6.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.15.sroa.7.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 296
  store i64 %_6.i102.i, ptr %_63.sroa.0.sroa.15.sroa.7.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.15.sroa.8.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 304
  store i8 %423, ptr %_63.sroa.0.sroa.15.sroa.8.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.15.sroa.9.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 305
  store i8 %425, ptr %_63.sroa.0.sroa.15.sroa.9.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.0.sroa.15.sroa.10.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 306
  store i8 %427, ptr %_63.sroa.0.sroa.15.sroa.10.0._63.sroa.0.sroa.15.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.0.sroa.16.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 312
  store ptr %_2.i106.i, ptr %_63.sroa.0.sroa.16.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.16.sroa.4.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 320
  store ptr %_12.i107.i, ptr %_63.sroa.0.sroa.16.sroa.4.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.16.sroa.5.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 328
  store ptr %_16.i113.i, ptr %_63.sroa.0.sroa.16.sroa.5.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.16.sroa.6.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 336
  store ptr %_5.i118.i, ptr %_63.sroa.0.sroa.16.sroa.6.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.16.sroa.7.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 344
  store i64 %_6.i119.i, ptr %_63.sroa.0.sroa.16.sroa.7.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.16.sroa.8.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 352
  store i8 %433, ptr %_63.sroa.0.sroa.16.sroa.8.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.16.sroa.9.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 353
  store i8 %435, ptr %_63.sroa.0.sroa.16.sroa.9.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.0.sroa.16.sroa.10.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 354
  store i8 %437, ptr %_63.sroa.0.sroa.16.sroa.10.0._63.sroa.0.sroa.16.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.0.sroa.17.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 360
  store ptr %_2.i123.i, ptr %_63.sroa.0.sroa.17.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.17.sroa.4.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 368
  store ptr %_12.i124.i, ptr %_63.sroa.0.sroa.17.sroa.4.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.17.sroa.5.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 376
  store ptr %_16.i130.i, ptr %_63.sroa.0.sroa.17.sroa.5.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.17.sroa.6.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 384
  store ptr %_5.i135.i, ptr %_63.sroa.0.sroa.17.sroa.6.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.17.sroa.7.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 392
  store i64 %_6.i136.i, ptr %_63.sroa.0.sroa.17.sroa.7.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.17.sroa.8.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 400
  store i8 %444, ptr %_63.sroa.0.sroa.17.sroa.8.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.0.sroa.17.sroa.9.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 401
  store i8 %446, ptr %_63.sroa.0.sroa.17.sroa.9.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.0.sroa.17.sroa.10.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 402
  store i8 %448, ptr %_63.sroa.0.sroa.17.sroa.10.0._63.sroa.0.sroa.17.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.10.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 408
  store ptr %_187.i, ptr %_63.sroa.10.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.11.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 416
  store ptr %_235.i160, ptr %_63.sroa.11.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.12.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 424
  store ptr %_239.i, ptr %_63.sroa.12.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.13.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 432
  store ptr %_188.i, ptr %_63.sroa.13.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.14.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 440
  store i64 %_76.i, ptr %_63.sroa.14.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.15.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 448
  store i8 %454, ptr %_63.sroa.15.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.16.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 449
  store i8 %456, ptr %_63.sroa.16.0..sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.17.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 450
  store i8 %458, ptr %_63.sroa.17.0..sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.19.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 456
  store ptr %_2.i152.i, ptr %_63.sroa.19.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.19.sroa.4.0._63.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 464
  store ptr %_12.i153.i, ptr %_63.sroa.19.sroa.4.0._63.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.19.sroa.5.0._63.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 472
  store ptr %_16.i159.i, ptr %_63.sroa.19.sroa.5.0._63.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.19.sroa.6.0._63.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 480
  store ptr %_5.i164.i, ptr %_63.sroa.19.sroa.6.0._63.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.19.sroa.7.0._63.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 488
  store i64 %_6.i165.i, ptr %_63.sroa.19.sroa.7.0._63.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.19.sroa.8.0._63.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 496
  store i8 %464, ptr %_63.sroa.19.sroa.8.0._63.sroa.19.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.19.sroa.9.0._63.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 497
  store i8 %466, ptr %_63.sroa.19.sroa.9.0._63.sroa.19.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.19.sroa.10.0._63.sroa.19.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 498
  store i8 %468, ptr %_63.sroa.19.sroa.10.0._63.sroa.19.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.20.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 504
  store ptr %_189.i, ptr %_63.sroa.20.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.20.sroa.4.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 512
  store ptr %_243.i, ptr %_63.sroa.20.sroa.4.0._63.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.20.sroa.5.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 520
  store ptr %_247.i, ptr %_63.sroa.20.sroa.5.0._63.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.20.sroa.6.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 528
  store ptr %_190.i, ptr %_63.sroa.20.sroa.6.0._63.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.20.sroa.7.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 536
  store i64 %_86.i162, ptr %_63.sroa.20.sroa.7.0._63.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.20.sroa.8.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 544
  store i8 %475, ptr %_63.sroa.20.sroa.8.0._63.sroa.20.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.20.sroa.9.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 545
  store i8 %477, ptr %_63.sroa.20.sroa.9.0._63.sroa.20.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.20.sroa.10.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 546
  store i8 %479, ptr %_63.sroa.20.sroa.10.0._63.sroa.20.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.20.sroa.11.0._63.sroa.20.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 547
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_63.sroa.20.sroa.11.0._63.sroa.20.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_63.sroa.20.sroa.11.i, i64 5, i1 false), !noalias !5637
  %_63.sroa.21.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 552
  store ptr %_2.i181.i, ptr %_63.sroa.21.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.21.sroa.4.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 560
  store ptr %_12.i182.i, ptr %_63.sroa.21.sroa.4.0._63.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.21.sroa.5.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 568
  store ptr %_16.i188.i, ptr %_63.sroa.21.sroa.5.0._63.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.21.sroa.6.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 576
  store ptr %_5.i193.i, ptr %_63.sroa.21.sroa.6.0._63.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.21.sroa.7.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 584
  store i64 %_6.i194.i, ptr %_63.sroa.21.sroa.7.0._63.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.21.sroa.8.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 592
  store i8 %486, ptr %_63.sroa.21.sroa.8.0._63.sroa.21.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.21.sroa.9.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 593
  store i8 %488, ptr %_63.sroa.21.sroa.9.0._63.sroa.21.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.21.sroa.10.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 594
  store i8 %490, ptr %_63.sroa.21.sroa.10.0._63.sroa.21.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.21.sroa.11.0._63.sroa.21.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 595
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_63.sroa.21.sroa.11.0._63.sroa.21.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_63.sroa.21.sroa.11.i, i64 5, i1 false), !noalias !5637
  %_63.sroa.22.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 600
  store ptr %_191.i, ptr %_63.sroa.22.0..sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.22.sroa.4.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 608
  store ptr %_252.i, ptr %_63.sroa.22.sroa.4.0._63.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.22.sroa.5.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 616
  store ptr %_256.i, ptr %_63.sroa.22.sroa.5.0._63.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.22.sroa.6.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 624
  store ptr %_192.i, ptr %_63.sroa.22.sroa.6.0._63.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.22.sroa.7.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 632
  store i64 %_95.i, ptr %_63.sroa.22.sroa.7.0._63.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.22.sroa.8.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 640
  store i8 %496, ptr %_63.sroa.22.sroa.8.0._63.sroa.22.0..sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_63.sroa.22.sroa.9.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 641
  store i8 %498, ptr %_63.sroa.22.sroa.9.0._63.sroa.22.0..sroa_idx.sroa_idx.i, align 1, !noalias !5637
  %_63.sroa.22.sroa.10.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 642
  store i8 %500, ptr %_63.sroa.22.sroa.10.0._63.sroa.22.0..sroa_idx.sroa_idx.i, align 2, !noalias !5637
  %_63.sroa.22.sroa.11.0._63.sroa.22.0..sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 643
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_63.sroa.22.sroa.11.0._63.sroa.22.0..sroa_idx.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_63.sroa.22.sroa.11.i, i64 5, i1 false), !noalias !5637
  store i64 0, ptr %_54.i, align 8, !noalias !5637
  %_258.sroa.4.0._54.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_258.sroa.4.0._54.sroa_idx.i, align 8, !noalias !5637
  %_258.sroa.5.0._54.sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 16
  store i64 0, ptr %_258.sroa.5.0._54.sroa_idx.i, align 8, !noalias !5637
  %502 = getelementptr inbounds i8, ptr %_54.i, i64 24
  store ptr %_184.i154, ptr %502, align 8, !noalias !5637
  %_55.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 32
  store ptr %_221.i156, ptr %_55.sroa.4.0..sroa_idx.i, align 8, !noalias !5637
  %_55.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 40
  store ptr %_225.i, ptr %_55.sroa.5.0..sroa_idx.i, align 8, !noalias !5637
  %_55.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 48
  store ptr %_185.i155, ptr %_55.sroa.6.0..sroa_idx.i, align 8, !noalias !5637
  %_55.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 56
  store i64 %_59.i, ptr %_55.sroa.7.0..sroa_idx.i, align 8, !noalias !5637
  %_55.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 64
  store i8 %374, ptr %_55.sroa.8.0..sroa_idx.i, align 8, !noalias !5637
  %_55.sroa.9.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 65
  store i8 %372, ptr %_55.sroa.9.0..sroa_idx.i, align 1, !noalias !5637
  %_55.sroa.10.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 66
  store i8 %370, ptr %_55.sroa.10.0..sroa_idx.i, align 2, !noalias !5637
  %_55.sroa.11.0..sroa_idx.i = getelementptr inbounds i8, ptr %_54.i, i64 67
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_55.sroa.11.0..sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(5) %_55.sroa.11.i, i64 5, i1 false), !noalias !5637
  %503 = getelementptr inbounds i8, ptr %_54.i, i64 648
  store ptr inttoptr (i64 8 to ptr), ptr %503, align 8, !noalias !5637
  %504 = getelementptr inbounds i8, ptr %_54.i, i64 656
  store i64 0, ptr %504, align 8, !noalias !5637
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_63.sroa.20.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_63.sroa.21.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_63.sroa.22.sroa.11.i)
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_55.sroa.11.i)
; call pump_recovered::pump_amm::cpi::transfer_creator_fees_to_pump_v2
  %505 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi32transfer_creator_fees_to_pump_v217he7f9c8783c313da6E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(664) %_54.i) #27, !noalias !5641
  %506 = extractvalue { i64, ptr } %505, 0
  call void @llvm.lifetime.end.p0(i64 664, ptr nonnull %_54.i), !noalias !5637
  %507 = icmp eq i64 %506, 2
  br i1 %507, label %bb25.i, label %bb85.i

bb85.i:                                           ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209.i
  %508 = extractvalue { i64, ptr } %505, 1
  br label %bb59.i132

bb35.i:                                           ; preds = %bb25.i
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_139.i), !noalias !5637
  %509 = getelementptr inbounds i8, ptr %_266, i64 72
  %_140.i = load ptr, ptr %509, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::admin_cto::token_raw_amount
  call fastcc void @_ZN14pump_recovered9admin_cto16token_raw_amount17h5c5bab1f81c4ceb2E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_139.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_140.i) #27, !noalias !5641
  %510 = load i64, ptr %_139.i, align 8, !range !318, !noalias !5637, !noundef !2
  %511 = icmp eq i64 %510, 2
  %512 = getelementptr inbounds i8, ptr %_139.i, i64 8
  br i1 %511, label %bb97.i, label %bb96.i

bb26.i148:                                        ; preds = %bb25.i
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %rent.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_113.i), !noalias !5637
; call solana_sysvar::rent::<impl solana_sysvar::Sysvar for solana_rent::Rent>::get
  call void @"_ZN13solana_sysvar4rent69_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_rent..Rent$GT$3get17hd4b89a48ea901882E"(ptr noalias nocapture noundef nonnull sret([32 x i8]) align 8 dereferenceable(32) %_113.i) #27, !noalias !5641
  %_266.i = load i64, ptr %_113.i, align 8, !range !410, !noalias !5637, !noundef !2
  %trunc.not.i149 = icmp eq i64 %_266.i, 0
  %513 = getelementptr inbounds i8, ptr %_113.i, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_112.sroa.5.i, ptr noundef nonnull align 8 dereferenceable(24) %513, i64 24, i1 false), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_113.i), !noalias !5637
  br i1 %trunc.not.i149, label %bb88.i, label %bb87.i

bb97.i:                                           ; preds = %bb35.i
  %_280.i = load i64, ptr %512, align 8, !noalias !5637, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_139.i), !noalias !5637
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_144.i120), !noalias !5637
  %_145.i144 = load ptr, ptr %509, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::admin_cto::token_frozen
  call fastcc void @_ZN14pump_recovered9admin_cto12token_frozen17h1658d4a62a0640cfE(ptr noalias nocapture noundef nonnull align 8 dereferenceable(16) %_144.i120, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_145.i144) #27, !noalias !5641
  %514 = load i64, ptr %_144.i120, align 8, !range !318, !noalias !5637, !noundef !2
  %515 = icmp eq i64 %514, 2
  %516 = getelementptr inbounds i8, ptr %_144.i120, i64 8
  br i1 %515, label %bb99.i, label %bb98.i

bb96.i:                                           ; preds = %bb35.i
  %_281.1.i = load ptr, ptr %512, align 8, !noalias !5637, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_139.i), !noalias !5637
  br label %bb55.i

bb99.i:                                           ; preds = %bb97.i
  %517 = load i8, ptr %516, align 8, !range !394, !noalias !5637, !noundef !2
  %_285.not.i = icmp eq i8 %517, 0
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_144.i120), !noalias !5637
  %_157.not.i = icmp eq i64 %_280.i, 0
  br i1 %_285.not.i, label %bb44.i146, label %bb38.i145

bb98.i:                                           ; preds = %bb97.i
  %_286.1.i = load ptr, ptr %516, align 8, !noalias !5637, !noundef !2
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_144.i120), !noalias !5637
  br label %bb55.i

bb44.i146:                                        ; preds = %bb99.i
  br i1 %_157.not.i, label %bb50.i, label %bb45.i147

bb38.i145:                                        ; preds = %bb99.i
  br i1 %_157.not.i, label %bb50.i, label %bb40.i

bb45.i147:                                        ; preds = %bb44.i146
  call void @llvm.lifetime.start.p0(i64 376, ptr nonnull %_160.i), !noalias !5637
  %518 = getelementptr inbounds i8, ptr %_266, i64 40
  %_289.i = load ptr, ptr %518, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %519 = getelementptr inbounds i8, ptr %_160.i, i64 24
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %519, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_289.i) #27, !noalias !5641
  call void @llvm.lifetime.start.p0(i64 288, ptr nonnull %_162.i), !noalias !5637
  %_290.i = load ptr, ptr %_266, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_162.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_290.i) #27, !noalias !5641
  %520 = getelementptr inbounds i8, ptr %_266, i64 80
  %_291.i = load ptr, ptr %520, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %521 = getelementptr inbounds i8, ptr %_162.i, i64 48
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %521, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_291.i) #27, !noalias !5641
  %522 = getelementptr inbounds i8, ptr %_162.i, i64 96
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %522, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %327) #27, !noalias !5641
  %_193.i = load ptr, ptr %320, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %523 = getelementptr inbounds i8, ptr %_193.i, i64 88
  %_292.i = load ptr, ptr %523, align 8, !noalias !5641, !nonnull !2, !align !3, !noundef !2
  %524 = getelementptr inbounds i8, ptr %_162.i, i64 144
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %524, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_292.i) #27, !noalias !5641
  %_293.i = load ptr, ptr %_77, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %525 = getelementptr inbounds i8, ptr %_162.i, i64 192
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %525, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_293.i) #27, !noalias !5641
  %526 = getelementptr inbounds i8, ptr %_266, i64 32
  %_294.i = load ptr, ptr %526, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %527 = getelementptr inbounds i8, ptr %_162.i, i64 240
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %527, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_294.i) #27, !noalias !5641
  %528 = getelementptr inbounds i8, ptr %_160.i, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(288) %528, ptr noundef nonnull align 8 dereferenceable(288) %_162.i, i64 288, i1 false), !noalias !5637
  store i64 0, ptr %_160.i, align 8, !noalias !5637
  %_295.sroa.4.0._160.sroa_idx.i = getelementptr inbounds i8, ptr %_160.i, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_295.sroa.4.0._160.sroa_idx.i, align 8, !noalias !5637
  %_295.sroa.5.0._160.sroa_idx.i = getelementptr inbounds i8, ptr %_160.i, i64 16
  store i64 0, ptr %_295.sroa.5.0._160.sroa_idx.i, align 8, !noalias !5637
  %529 = getelementptr inbounds i8, ptr %_160.i, i64 360
  store ptr inttoptr (i64 8 to ptr), ptr %529, align 8, !noalias !5637
  %530 = getelementptr inbounds i8, ptr %_160.i, i64 368
  store i64 0, ptr %530, align 8, !noalias !5637
  call void @llvm.lifetime.end.p0(i64 288, ptr nonnull %_162.i), !noalias !5637
; call anchor_spl::associated_token::create_idempotent
  %531 = call { i64, ptr } @_ZN10anchor_spl16associated_token17create_idempotent17h6d66b04320e05cf1E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(376) %_160.i) #27, !noalias !5641
  %532 = extractvalue { i64, ptr } %531, 0
  call void @llvm.lifetime.end.p0(i64 376, ptr nonnull %_160.i), !noalias !5637
  %533 = icmp eq i64 %532, 2
  br i1 %533, label %bb109.i, label %bb108.i

bb109.i:                                          ; preds = %bb45.i147
  %_176.i = getelementptr inbounds i8, ptr %_266, i64 216
  %_194.i = load ptr, ptr %320, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
  %534 = getelementptr inbounds i8, ptr %_194.i, i64 48
  %_177.i = load i8, ptr %534, align 8, !noalias !5641, !noundef !2
  %535 = getelementptr inbounds i8, ptr %_194.i, i64 88
  %_178.i = load ptr, ptr %535, align 8, !noalias !5641, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::payments::collect_transfer_vault_tokens
  %536 = call { i64, ptr } @_ZN14pump_recovered8payments29collect_transfer_vault_tokens17hc9f594ce95aedac6E(ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %526, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %509, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %520, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_176.i, i8 noundef %_177.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_178.i, i64 noundef %_280.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(16) %vsigner.i) #27, !noalias !5641
  %537 = extractvalue { i64, ptr } %536, 0
  %538 = icmp eq i64 %537, 2
  br i1 %538, label %bb50.i, label %bb110.i

bb108.i:                                          ; preds = %bb45.i147
  %539 = extractvalue { i64, ptr } %531, 1
  br label %bb55.i

bb110.i:                                          ; preds = %bb109.i
  %540 = extractvalue { i64, ptr } %536, 1
  br label %bb55.i

bb40.i:                                           ; preds = %bb38.i145
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %_149.i), !noalias !5637
  %541 = getelementptr inbounds i8, ptr %_149.i, i64 32
; call pump_recovered::PumpError::name
  call void @_ZN14pump_recovered9PumpError4name17h61022c7ff53288d0E(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %541, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #27, !noalias !5641
  %542 = getelementptr inbounds i8, ptr %_149.i, i64 56
; call <T as alloc::string::ToString>::to_string
  call fastcc void @"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %542, ptr noalias noundef nonnull readonly align 4 dereferenceable(4) @alloc_cd7b816cab57a667caebec1ad637a70c) #27, !noalias !5641
  %543 = getelementptr inbounds i8, ptr %_149.i, i64 152
  store i32 6093, ptr %543, align 8, !noalias !5637
  store i64 0, ptr %_149.i, align 8, !noalias !5637
  %_153.sroa.4.0._149.sroa_idx.i = getelementptr inbounds i8, ptr %_149.i, i64 8
  store ptr @alloc_ebe040a358b3132776a16f34a7b7aa5b, ptr %_153.sroa.4.0._149.sroa_idx.i, align 8, !noalias !5637
  %_153.sroa.4.sroa.4.0._153.sroa.4.0._149.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_149.i, i64 16
  store i64 38, ptr %_153.sroa.4.sroa.4.0._153.sroa.4.0._149.sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %_153.sroa.4.sroa.5.0._153.sroa.4.0._149.sroa_idx.sroa_idx.i = getelementptr inbounds i8, ptr %_149.i, i64 24
  store i32 719, ptr %_153.sroa.4.sroa.5.0._153.sroa.4.0._149.sroa_idx.sroa_idx.i, align 8, !noalias !5637
  %544 = getelementptr inbounds i8, ptr %_149.i, i64 80
  store i8 2, ptr %544, align 8, !noalias !5637
; call <anchor_lang::error::Error as core::convert::From<anchor_lang::error::AnchorError>>::from
  %545 = call { i64, ptr } @"_ZN104_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$anchor_lang..error..AnchorError$GT$$GT$4from17h4ec711440ff80a00E"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(160) %_149.i) #27, !noalias !5641
  %_148.0.i = extractvalue { i64, ptr } %545, 0
  %_148.1.i = extractvalue { i64, ptr } %545, 1
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %_149.i), !noalias !5637
  br label %bb55.i

bb50.i:                                           ; preds = %bb44.i146, %bb38.i145, %bb109.i, %bb34.i
  %_415.sroa.0.0 = phi i64 [ %_415.sroa.0.2, %bb34.i ], [ 2, %bb109.i ], [ 2, %bb38.i145 ], [ 2, %bb44.i146 ]
  %_415.sroa.18.0 = phi i64 [ %_415.sroa.18.2, %bb34.i ], [ %_280.i, %bb109.i ], [ 0, %bb38.i145 ], [ 0, %bb44.i146 ]
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_110.i), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_105.i), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %old.i), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %vsigner.i), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %dest.i), !noalias !5637
  br label %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit

bb55.i:                                           ; preds = %bb54.i150, %bb40.i, %bb110.i, %bb108.i, %bb98.i, %bb96.i
  %_415.sroa.0.1 = phi i64 [ %_271.0.sink.i, %bb54.i150 ], [ %537, %bb110.i ], [ %532, %bb108.i ], [ %_148.0.i, %bb40.i ], [ %514, %bb98.i ], [ %510, %bb96.i ]
  %_415.sroa.18.1.in = phi ptr [ %_271.1.i, %bb54.i150 ], [ %540, %bb110.i ], [ %539, %bb108.i ], [ %_148.1.i, %bb40.i ], [ %_286.1.i, %bb98.i ], [ %_281.1.i, %bb96.i ]
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_110.i), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_105.i), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %old.i), !noalias !5637
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %vsigner.i), !noalias !5637
  br label %bb59.i132

bb88.i:                                           ; preds = %bb26.i148
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %rent.i, ptr noundef nonnull align 8 dereferenceable(24) %_112.sroa.5.i, i64 24, i1 false), !noalias !5637
; call solana_rent::Rent::minimum_balance
  %min.i = call noundef i64 @_ZN11solana_rent4Rent15minimum_balance17h06f7367e702730e1E(ptr noalias noundef nonnull readonly align 8 dereferenceable(24) %rent.i, i64 noundef 0) #27, !noalias !5641
  %_120.i = getelementptr inbounds i8, ptr %_266, i64 216
; call solana_account_info::AccountInfo::lamports
  %_119.i = call noundef i64 @_ZN19solana_account_info11AccountInfo8lamports17h0ca2b04e77f2c7d8E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_120.i) #27, !noalias !5641
  %546 = call i64 @llvm.usub.sat.i64(i64 %_119.i, i64 %min.i)
  %_121.not.not.i = icmp ugt i64 %_119.i, %min.i
  br i1 %_121.not.not.i, label %bb30.i, label %bb34.i

bb87.i:                                           ; preds = %bb26.i148
; call <anchor_lang::error::Error as core::convert::From<solana_program_error::ProgramError>>::from
  %547 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_112.sroa.5.i) #27, !noalias !5641
  %_271.0.i = extractvalue { i64, ptr } %547, 0
  br label %bb54.i150

bb30.i:                                           ; preds = %bb88.i
; call pump_recovered::legacy_native_payments::ensure_rent_exempt
  %548 = call { i64, ptr } @_ZN14pump_recovered22legacy_native_payments18ensure_rent_exempt17h8f9b2dcab7b02290E(ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_77, ptr noalias noundef nonnull readonly align 8 dereferenceable(8) %_266, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %327) #27, !noalias !5641
  %549 = extractvalue { i64, ptr } %548, 0
  %550 = icmp eq i64 %549, 2
  br i1 %550, label %bb92.i, label %bb54.i150

bb34.i:                                           ; preds = %bb92.i, %bb88.i, %bb94.i
  %_415.sroa.0.2 = phi i64 [ %552, %bb94.i ], [ 2, %bb88.i ], [ 2, %bb92.i ]
  %_415.sroa.18.2 = phi i64 [ %555, %bb94.i ], [ 0, %bb88.i ], [ %546, %bb92.i ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %rent.i), !noalias !5637
  br label %bb50.i

bb92.i:                                           ; preds = %bb30.i
  %_130.i = load ptr, ptr %_77, align 8, !noalias !5637, !nonnull !2, !align !3, !noundef !2
; call pump_recovered::payments::collect_transfer_native
  %551 = call fastcc { i64, ptr } @_ZN14pump_recovered8payments23collect_transfer_native17h5f701d700d8b4137E(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_130.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_120.i, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %327, i64 noundef %546, ptr noalias noundef nonnull readonly align 8 %vsigner.i) #27
  %552 = extractvalue { i64, ptr } %551, 0
  %553 = icmp eq i64 %552, 2
  br i1 %553, label %bb34.i, label %bb94.i

bb94.i:                                           ; preds = %bb92.i
  %554 = extractvalue { i64, ptr } %551, 1
  %555 = ptrtoint ptr %554 to i64
  br label %bb34.i

bb54.i150:                                        ; preds = %bb30.i, %bb87.i
  %.sink.i = phi { i64, ptr } [ %547, %bb87.i ], [ %548, %bb30.i ]
  %_271.0.sink.i = phi i64 [ %_271.0.i, %bb87.i ], [ %549, %bb30.i ]
  %_271.1.i = extractvalue { i64, ptr } %.sink.i, 1
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %rent.i), !noalias !5637
  br label %bb55.i

bb59.i132:                                        ; preds = %bb55.i, %bb85.i, %bb16.i143, %bb65.i141, %bb63.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i"
  %_415.sroa.0.3 = phi i64 [ %_415.sroa.0.1, %bb55.i ], [ %506, %bb85.i ], [ %_41.0.i, %bb16.i143 ], [ %348, %bb65.i141 ], [ %344, %bb63.i ], [ %_15.0.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i" ]
  %_415.sroa.18.3.in = phi ptr [ %_415.sroa.18.1.in, %bb55.i ], [ %508, %bb85.i ], [ %_41.1.i, %bb16.i143 ], [ %_216.1.i, %bb65.i141 ], [ %_211.1.i, %bb63.i ], [ %_15.1.i, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h4b386cbefe3ebd9eE.exit.i" ]
  %_415.sroa.18.3 = ptrtoint ptr %_415.sroa.18.3.in to i64
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %dest.i), !noalias !5637
  br label %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit

_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit: ; preds = %bb50.i, %bb59.i132
  %_415.sroa.0.4 = phi i64 [ %_415.sroa.0.0, %bb50.i ], [ %_415.sroa.0.3, %bb59.i132 ]
  %_415.sroa.18.4 = phi i64 [ %_415.sroa.18.0, %bb50.i ], [ %_415.sroa.18.3, %bb59.i132 ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_112.sroa.5.i)
  %556 = icmp eq i64 %_415.sroa.0.4, 2
  br i1 %556, label %bb89, label %bb88

bb89:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit, %bb35
  %_95.sroa.0.0 = phi i64 [ 0, %bb35 ], [ %_415.sroa.18.4, %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit ]
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_106)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_109)
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_114)
  %557 = getelementptr inbounds i8, ptr %ctx, i64 39
  %_115 = load i8, ptr %557, align 1, !noundef !2
  store i8 %_115, ptr %_114, align 1
  store ptr @alloc_837d2dfc2ca6132d7e624d246f381ca4, ptr %_109, align 8
  %558 = getelementptr inbounds i8, ptr %_109, i64 8
  store i64 14, ptr %558, align 8
  %559 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_109, i64 0, i64 1
  store ptr %mint, ptr %559, align 8
  %560 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_109, i64 0, i64 1, i32 1
  store i64 32, ptr %560, align 8
  %561 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_109, i64 0, i64 2
  store ptr %_114, ptr %561, align 8
  %562 = getelementptr inbounds [3 x { ptr, i64 }], ptr %_109, i64 0, i64 2, i32 1
  store i64 1, ptr %562, align 8
  store ptr %_109, ptr %_106, align 8
  %563 = getelementptr inbounds i8, ptr %_106, i64 8
  store i64 3, ptr %563, align 8
  %564 = icmp ne i8 %_539.sroa.0.0, 2
  br i1 %564, label %bb36, label %bb38

bb88:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute5sweep17h9943ff4781c7e018E.exit
  %565 = inttoptr i64 %_415.sroa.18.4 to ptr
  br label %bb67

bb38:                                             ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit269, %bb89
  %_325 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %566 = getelementptr inbounds i8, ptr %_325, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %old_creator, ptr noundef nonnull align 8 dereferenceable(32) %566, i64 32, i1 false)
  %567 = getelementptr inbounds i8, ptr %_325, i64 112
  %old_fee = load i64, ptr %567, align 8, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %566, ptr noundef nonnull align 1 dereferenceable(32) %target13, i64 32, i1 false)
  %_328 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %568 = getelementptr inbounds i8, ptr %_328, i64 163
  store i8 %167, ptr %568, align 1
  %_329 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %569 = getelementptr inbounds i8, ptr %_329, i64 165
  %570 = zext i1 %_0.sroa.0.0.off0.i to i8
  store i8 %570, ptr %569, align 1
  %switch75 = icmp eq i64 %0, 1
  br i1 %switch75, label %bb39, label %bb40

bb36:                                             ; preds = %bb89
  store i8 %_539.sroa.0.0, ptr %val6, align 1
  %sharing_update14.sroa.3.0.val6.sroa_idx = getelementptr inbounds i8, ptr %val6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %sharing_update14.sroa.3.0.val6.sroa_idx, ptr noundef nonnull align 1 dereferenceable(32) %sharing_update14.sroa.3, i64 32, i1 false)
  call void @llvm.lifetime.start.p0(i64 424, ptr nonnull %_120)
  call void @llvm.lifetime.start.p0(i64 5, ptr nonnull %_121.sroa.11)
  %571 = getelementptr inbounds i8, ptr %_266, i64 152
  %_427 = load ptr, ptr %571, align 8, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5701)
  %_2.i = load ptr, ptr %_427, align 8, !alias.scope !5701, !noalias !5704, !nonnull !2, !align !392, !noundef !2
  %572 = getelementptr inbounds i8, ptr %_427, i64 8
  %_12.i164 = load ptr, ptr %572, align 8, !alias.scope !5701, !noalias !5704, !nonnull !2, !noundef !2
  %self.val.i.i165 = load i64, ptr %_12.i164, align 8, !noalias !5706, !noundef !2
  %cond.i.i166 = icmp ne i64 %self.val.i.i165, 0
  call void @llvm.assume(i1 %cond.i.i166)
  %strong1.i.i167 = add i64 %self.val.i.i165, 1
  store i64 %strong1.i.i167, ptr %_12.i164, align 8, !noalias !5706
  %_7.i.i168 = icmp eq i64 %strong1.i.i167, 0
  br i1 %_7.i.i168, label %bb4.i.i172, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i169

bb4.i.i172:                                       ; preds = %bb36
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i169: ; preds = %bb36
  %573 = getelementptr inbounds i8, ptr %_427, i64 16
  %_16.i = load ptr, ptr %573, align 8, !alias.scope !5701, !noalias !5704, !nonnull !2, !noundef !2
  %self.val.i1.i = load i64, ptr %_16.i, align 8, !noalias !5706, !noundef !2
  %cond.i2.i = icmp ne i64 %self.val.i1.i, 0
  call void @llvm.assume(i1 %cond.i2.i)
  %strong1.i3.i = add i64 %self.val.i1.i, 1
  store i64 %strong1.i3.i, ptr %_16.i, align 8, !noalias !5706
  %_7.i4.i = icmp eq i64 %strong1.i3.i, 0
  br i1 %_7.i4.i, label %bb4.i5.i, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit"

bb4.i5.i:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i169
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i169
  %574 = getelementptr inbounds i8, ptr %_427, i64 24
  %_5.i171 = load ptr, ptr %574, align 8, !alias.scope !5701, !noalias !5704, !nonnull !2, !align !392, !noundef !2
  %575 = getelementptr inbounds i8, ptr %_427, i64 32
  %_6.i = load i64, ptr %575, align 8, !alias.scope !5701, !noalias !5704, !noundef !2
  %576 = getelementptr inbounds i8, ptr %_427, i64 40
  %577 = load i8, ptr %576, align 8, !range !394, !alias.scope !5701, !noalias !5704, !noundef !2
  %578 = getelementptr inbounds i8, ptr %_427, i64 41
  %579 = load i8, ptr %578, align 1, !range !394, !alias.scope !5701, !noalias !5704, !noundef !2
  %580 = getelementptr inbounds i8, ptr %_427, i64 42
  %581 = load i8, ptr %580, align 2, !range !394, !alias.scope !5701, !noalias !5704, !noundef !2
  %582 = getelementptr inbounds i8, ptr %_266, i64 104
  %x = load ptr, ptr %582, align 8, !nonnull !2, !align !3, !noundef !2
  %583 = getelementptr inbounds i8, ptr %x, i64 24
  %_299 = load ptr, ptr %583, align 8, !nonnull !2, !align !392, !noundef !2
  %584 = getelementptr inbounds i8, ptr %x, i64 8
  %_430 = load ptr, ptr %584, align 8, !nonnull !2, !noundef !2
  %self.val.i = load i64, ptr %_430, align 8, !noundef !2
  %cond.i = icmp ne i64 %self.val.i, 0
  call void @llvm.assume(i1 %cond.i)
  %strong1.i = add i64 %self.val.i, 1
  store i64 %strong1.i, ptr %_430, align 8
  %_7.i173 = icmp eq i64 %strong1.i, 0
  br i1 %_7.i173, label %bb4.i175, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit

bb4.i175:                                         ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit"
  %585 = getelementptr inbounds i8, ptr %x, i64 16
  %_434 = load ptr, ptr %585, align 8, !nonnull !2, !noundef !2
  %self.val.i176 = load i64, ptr %_434, align 8, !noundef !2
  %cond.i177 = icmp ne i64 %self.val.i176, 0
  call void @llvm.assume(i1 %cond.i177)
  %strong1.i178 = add i64 %self.val.i176, 1
  store i64 %strong1.i178, ptr %_434, align 8
  %_7.i179 = icmp eq i64 %strong1.i178, 0
  br i1 %_7.i179, label %bb4.i181, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit

bb4.i181:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit
  %586 = getelementptr inbounds i8, ptr %x, i64 32
  %_127 = load i64, ptr %586, align 8, !noundef !2
  %587 = getelementptr inbounds i8, ptr %x, i64 40
  %588 = load i8, ptr %587, align 8, !range !394, !noundef !2
  %589 = getelementptr inbounds i8, ptr %x, i64 41
  %590 = load i8, ptr %589, align 1, !range !394, !noundef !2
  %_300 = load ptr, ptr %x, align 8, !nonnull !2, !align !392, !noundef !2
  %591 = getelementptr inbounds i8, ptr %x, i64 42
  %592 = load i8, ptr %591, align 2, !range !394, !noundef !2
  %x18 = load ptr, ptr %_266, align 8, !nonnull !2, !align !3, !noundef !2
  %593 = getelementptr inbounds i8, ptr %x18, i64 41
  %594 = load i8, ptr %593, align 1, !range !394, !noundef !2
  %595 = getelementptr inbounds i8, ptr %x18, i64 42
  %596 = load i8, ptr %595, align 2, !range !394, !noundef !2
  %597 = getelementptr inbounds i8, ptr %x18, i64 40
  %598 = load i8, ptr %597, align 8, !range !394, !noundef !2
  %599 = getelementptr inbounds i8, ptr %x18, i64 32
  %_136 = load i64, ptr %599, align 8, !noundef !2
  %600 = getelementptr inbounds i8, ptr %x18, i64 8
  %_438 = load ptr, ptr %600, align 8, !nonnull !2, !noundef !2
  %self.val.i182 = load i64, ptr %_438, align 8, !noundef !2
  %cond.i183 = icmp ne i64 %self.val.i182, 0
  call void @llvm.assume(i1 %cond.i183)
  %strong1.i184 = add i64 %self.val.i182, 1
  store i64 %strong1.i184, ptr %_438, align 8
  %_7.i185 = icmp eq i64 %strong1.i184, 0
  br i1 %_7.i185, label %bb4.i187, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit188

bb4.i187:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit188: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit
  %601 = getelementptr inbounds i8, ptr %x18, i64 16
  %_442 = load ptr, ptr %601, align 8, !nonnull !2, !noundef !2
  %self.val.i189 = load i64, ptr %_442, align 8, !noundef !2
  %cond.i190 = icmp ne i64 %self.val.i189, 0
  call void @llvm.assume(i1 %cond.i190)
  %strong1.i191 = add i64 %self.val.i189, 1
  store i64 %strong1.i191, ptr %_442, align 8
  %_7.i192 = icmp eq i64 %strong1.i191, 0
  br i1 %_7.i192, label %bb4.i194, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit195

bb4.i194:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit188
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit195: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit188
  %602 = getelementptr inbounds i8, ptr %x18, i64 24
  %_302 = load ptr, ptr %602, align 8, !nonnull !2, !align !392, !noundef !2
  %_303 = load ptr, ptr %x18, align 8, !nonnull !2, !align !392, !noundef !2
  %_552 = load ptr, ptr %24, align 8, !nonnull !2, !noundef !2
  %x19 = load ptr, ptr %_552, align 8, !nonnull !2, !align !3, !noundef !2
  %603 = getelementptr inbounds i8, ptr %x19, i64 41
  %604 = load i8, ptr %603, align 1, !range !394, !noundef !2
  %605 = getelementptr inbounds i8, ptr %x19, i64 42
  %606 = load i8, ptr %605, align 2, !range !394, !noundef !2
  %607 = getelementptr inbounds i8, ptr %x19, i64 40
  %608 = load i8, ptr %607, align 8, !range !394, !noundef !2
  %609 = getelementptr inbounds i8, ptr %x19, i64 32
  %_144 = load i64, ptr %609, align 8, !noundef !2
  %610 = getelementptr inbounds i8, ptr %x19, i64 8
  %_447 = load ptr, ptr %610, align 8, !nonnull !2, !noundef !2
  %self.val.i196 = load i64, ptr %_447, align 8, !noundef !2
  %cond.i197 = icmp ne i64 %self.val.i196, 0
  call void @llvm.assume(i1 %cond.i197)
  %strong1.i198 = add i64 %self.val.i196, 1
  store i64 %strong1.i198, ptr %_447, align 8
  %_7.i199 = icmp eq i64 %strong1.i198, 0
  br i1 %_7.i199, label %bb4.i201, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit202

bb4.i201:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit195
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit202: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit195
  %611 = getelementptr inbounds i8, ptr %x19, i64 16
  %_451 = load ptr, ptr %611, align 8, !nonnull !2, !noundef !2
  %self.val.i203 = load i64, ptr %_451, align 8, !noundef !2
  %cond.i204 = icmp ne i64 %self.val.i203, 0
  call void @llvm.assume(i1 %cond.i204)
  %strong1.i205 = add i64 %self.val.i203, 1
  store i64 %strong1.i205, ptr %_451, align 8
  %_7.i206 = icmp eq i64 %strong1.i205, 0
  br i1 %_7.i206, label %bb4.i208, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209

bb4.i208:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit202
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit202
  %612 = getelementptr inbounds i8, ptr %x19, i64 24
  %_305 = load ptr, ptr %612, align 8, !nonnull !2, !align !392, !noundef !2
  %_306 = load ptr, ptr %x19, align 8, !nonnull !2, !align !392, !noundef !2
  %x20 = load ptr, ptr %3, align 8, !nonnull !2, !align !3, !noundef !2
  %613 = getelementptr inbounds i8, ptr %x20, i64 32
  %_149 = load i64, ptr %613, align 8, !noundef !2
  %614 = getelementptr inbounds i8, ptr %x20, i64 40
  %615 = load i8, ptr %614, align 8, !range !394, !noundef !2
  %616 = getelementptr inbounds i8, ptr %x20, i64 41
  %617 = load i8, ptr %616, align 1, !range !394, !noundef !2
  %618 = getelementptr inbounds i8, ptr %x20, i64 42
  %619 = load i8, ptr %618, align 2, !range !394, !noundef !2
  %620 = getelementptr inbounds i8, ptr %x20, i64 8
  %_455 = load ptr, ptr %620, align 8, !nonnull !2, !noundef !2
  %self.val.i210 = load i64, ptr %_455, align 8, !noundef !2
  %cond.i211 = icmp ne i64 %self.val.i210, 0
  call void @llvm.assume(i1 %cond.i211)
  %strong1.i212 = add i64 %self.val.i210, 1
  store i64 %strong1.i212, ptr %_455, align 8
  %_7.i213 = icmp eq i64 %strong1.i212, 0
  br i1 %_7.i213, label %bb4.i215, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit216

bb4.i215:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit216: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit209
  %621 = getelementptr inbounds i8, ptr %x20, i64 24
  %_308 = load ptr, ptr %621, align 8, !nonnull !2, !align !392, !noundef !2
  %622 = getelementptr inbounds i8, ptr %x20, i64 16
  %_459 = load ptr, ptr %622, align 8, !nonnull !2, !noundef !2
  %self.val.i217 = load i64, ptr %_459, align 8, !noundef !2
  %cond.i218 = icmp ne i64 %self.val.i217, 0
  call void @llvm.assume(i1 %cond.i218)
  %strong1.i219 = add i64 %self.val.i217, 1
  store i64 %strong1.i219, ptr %_459, align 8
  %_7.i220 = icmp eq i64 %strong1.i219, 0
  br i1 %_7.i220, label %bb4.i222, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit223

bb4.i222:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit216
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit223: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit216
  %_309 = load ptr, ptr %x20, align 8, !nonnull !2, !align !392, !noundef !2
  %_461 = load ptr, ptr %4, align 8, !nonnull !2, !align !3, !noundef !2
  call void @llvm.experimental.noalias.scope.decl(metadata !5707)
  %_2.i224 = load ptr, ptr %_461, align 8, !alias.scope !5707, !noalias !5710, !nonnull !2, !align !392, !noundef !2
  %623 = getelementptr inbounds i8, ptr %_461, i64 8
  %_12.i225 = load ptr, ptr %623, align 8, !alias.scope !5707, !noalias !5710, !nonnull !2, !noundef !2
  %self.val.i.i226 = load i64, ptr %_12.i225, align 8, !noalias !5712, !noundef !2
  %cond.i.i227 = icmp ne i64 %self.val.i.i226, 0
  call void @llvm.assume(i1 %cond.i.i227)
  %strong1.i.i228 = add i64 %self.val.i.i226, 1
  store i64 %strong1.i.i228, ptr %_12.i225, align 8, !noalias !5712
  %_7.i.i229 = icmp eq i64 %strong1.i.i228, 0
  br i1 %_7.i.i229, label %bb4.i.i240, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i230

bb4.i.i240:                                       ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit223
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i230: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit223
  %624 = getelementptr inbounds i8, ptr %_461, i64 16
  %_16.i231 = load ptr, ptr %624, align 8, !alias.scope !5707, !noalias !5710, !nonnull !2, !noundef !2
  %self.val.i1.i232 = load i64, ptr %_16.i231, align 8, !noalias !5712, !noundef !2
  %cond.i2.i233 = icmp ne i64 %self.val.i1.i232, 0
  call void @llvm.assume(i1 %cond.i2.i233)
  %strong1.i3.i234 = add i64 %self.val.i1.i232, 1
  store i64 %strong1.i3.i234, ptr %_16.i231, align 8, !noalias !5712
  %_7.i4.i235 = icmp eq i64 %strong1.i3.i234, 0
  br i1 %_7.i4.i235, label %bb4.i5.i239, label %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit241"

bb4.i5.i239:                                      ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i230
  call void @llvm.trap()
  unreachable

"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit241": ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit.i230
  %625 = getelementptr inbounds i8, ptr %_461, i64 24
  %_5.i237 = load ptr, ptr %625, align 8, !alias.scope !5707, !noalias !5710, !nonnull !2, !align !392, !noundef !2
  %626 = getelementptr inbounds i8, ptr %_461, i64 32
  %_6.i238 = load i64, ptr %626, align 8, !alias.scope !5707, !noalias !5710, !noundef !2
  %627 = getelementptr inbounds i8, ptr %_461, i64 40
  %628 = load i8, ptr %627, align 8, !range !394, !alias.scope !5707, !noalias !5710, !noundef !2
  %629 = getelementptr inbounds i8, ptr %_461, i64 41
  %630 = load i8, ptr %629, align 1, !range !394, !alias.scope !5707, !noalias !5710, !noundef !2
  %631 = getelementptr inbounds i8, ptr %_461, i64 42
  %632 = load i8, ptr %631, align 2, !range !394, !alias.scope !5707, !noalias !5710, !noundef !2
  %633 = getelementptr inbounds i8, ptr %_266, i64 160
  %_158 = load ptr, ptr %633, align 8, !nonnull !2, !align !3, !noundef !2
  %634 = getelementptr inbounds i8, ptr %_158, i64 16
  %_464 = load ptr, ptr %634, align 8, !nonnull !2, !noundef !2
  %self.val.i242 = load i64, ptr %_464, align 8, !noundef !2
  %cond.i243 = icmp ne i64 %self.val.i242, 0
  call void @llvm.assume(i1 %cond.i243)
  %strong1.i244 = add i64 %self.val.i242, 1
  store i64 %strong1.i244, ptr %_464, align 8
  %_7.i245 = icmp eq i64 %strong1.i244, 0
  br i1 %_7.i245, label %bb4.i247, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit248

bb4.i247:                                         ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit241"
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit248: ; preds = %"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E.exit241"
  %_160 = load ptr, ptr %633, align 8, !nonnull !2, !align !3, !noundef !2
  %635 = getelementptr inbounds i8, ptr %_160, i64 8
  %_468 = load ptr, ptr %635, align 8, !nonnull !2, !noundef !2
  %self.val.i249 = load i64, ptr %_468, align 8, !noundef !2
  %cond.i250 = icmp ne i64 %self.val.i249, 0
  call void @llvm.assume(i1 %cond.i250)
  %strong1.i251 = add i64 %self.val.i249, 1
  store i64 %strong1.i251, ptr %_468, align 8
  %_7.i252 = icmp eq i64 %strong1.i251, 0
  br i1 %_7.i252, label %bb4.i254, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit255

bb4.i254:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit248
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit255: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit248
  %_161 = load ptr, ptr %633, align 8, !nonnull !2, !align !3, !noundef !2
  %_314 = load ptr, ptr %_161, align 8, !nonnull !2, !align !392, !noundef !2
  %636 = getelementptr inbounds i8, ptr %_161, i64 24
  %_316 = load ptr, ptr %636, align 8, !nonnull !2, !align !392, !noundef !2
  %637 = getelementptr inbounds i8, ptr %_161, i64 32
  %_163 = load i64, ptr %637, align 8, !noundef !2
  %638 = getelementptr inbounds i8, ptr %_161, i64 40
  %639 = load i8, ptr %638, align 8, !range !394, !noundef !2
  %640 = getelementptr inbounds i8, ptr %_161, i64 41
  %641 = load i8, ptr %640, align 1, !range !394, !noundef !2
  %642 = getelementptr inbounds i8, ptr %_161, i64 42
  %643 = load i8, ptr %642, align 2, !range !394, !noundef !2
  %x21 = load ptr, ptr %571, align 8, !nonnull !2, !align !3, !noundef !2
  %644 = getelementptr inbounds i8, ptr %x21, i64 8
  %_472 = load ptr, ptr %644, align 8, !nonnull !2, !noundef !2
  %self.val.i256 = load i64, ptr %_472, align 8, !noundef !2
  %cond.i257 = icmp ne i64 %self.val.i256, 0
  call void @llvm.assume(i1 %cond.i257)
  %strong1.i258 = add i64 %self.val.i256, 1
  store i64 %strong1.i258, ptr %_472, align 8
  %_7.i259 = icmp eq i64 %strong1.i258, 0
  br i1 %_7.i259, label %bb4.i261, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262

bb4.i261:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit255
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit255
  %_322 = load ptr, ptr %x21, align 8, !nonnull !2, !align !392, !noundef !2
  %645 = getelementptr inbounds i8, ptr %x21, i64 16
  %_476 = load ptr, ptr %645, align 8, !nonnull !2, !noundef !2
  %self.val.i263 = load i64, ptr %_476, align 8, !noundef !2
  %cond.i264 = icmp ne i64 %self.val.i263, 0
  call void @llvm.assume(i1 %cond.i264)
  %strong1.i265 = add i64 %self.val.i263, 1
  store i64 %strong1.i265, ptr %_476, align 8
  %_7.i266 = icmp eq i64 %strong1.i265, 0
  br i1 %_7.i266, label %bb4.i268, label %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit269

bb4.i268:                                         ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  call void @llvm.trap()
  unreachable

_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit269: ; preds = %_ZN5alloc2rc10RcInnerPtr10inc_strong17h485e41ed5d8892acE.exit262
  %646 = getelementptr inbounds i8, ptr %x21, i64 24
  %_323 = load ptr, ptr %646, align 8, !nonnull !2, !align !392, !noundef !2
  %647 = getelementptr inbounds i8, ptr %x21, i64 32
  %_175 = load i64, ptr %647, align 8, !noundef !2
  %648 = getelementptr inbounds i8, ptr %x21, i64 40
  %649 = load i8, ptr %648, align 8, !range !394, !noundef !2
  %650 = getelementptr inbounds i8, ptr %x21, i64 41
  %651 = load i8, ptr %650, align 1, !range !394, !noundef !2
  %652 = getelementptr inbounds i8, ptr %x21, i64 42
  %653 = load i8, ptr %652, align 2, !range !394, !noundef !2
  %654 = getelementptr inbounds i8, ptr %_120, i64 72
  store ptr %_300, ptr %654, align 8
  %_122.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 80
  store ptr %_430, ptr %_122.sroa.4.0..sroa_idx, align 8
  %_122.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 88
  store ptr %_434, ptr %_122.sroa.5.0..sroa_idx, align 8
  %_122.sroa.6.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 96
  store ptr %_299, ptr %_122.sroa.6.0..sroa_idx, align 8
  %_122.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 104
  store i64 %_127, ptr %_122.sroa.7.0..sroa_idx, align 8
  %_122.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 112
  store i8 %588, ptr %_122.sroa.8.0..sroa_idx, align 8
  %_122.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 113
  store i8 %590, ptr %_122.sroa.9.0..sroa_idx, align 1
  %_122.sroa.10.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 114
  store i8 %592, ptr %_122.sroa.10.0..sroa_idx, align 2
  %_122.sroa.12.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 120
  store ptr %_303, ptr %_122.sroa.12.0..sroa_idx, align 8
  %_122.sroa.12.sroa.4.0._122.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 128
  store ptr %_438, ptr %_122.sroa.12.sroa.4.0._122.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.12.sroa.5.0._122.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 136
  store ptr %_442, ptr %_122.sroa.12.sroa.5.0._122.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.12.sroa.6.0._122.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 144
  store ptr %_302, ptr %_122.sroa.12.sroa.6.0._122.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.12.sroa.7.0._122.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 152
  store i64 %_136, ptr %_122.sroa.12.sroa.7.0._122.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.12.sroa.8.0._122.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 160
  store i8 %598, ptr %_122.sroa.12.sroa.8.0._122.sroa.12.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.12.sroa.9.0._122.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 161
  store i8 %594, ptr %_122.sroa.12.sroa.9.0._122.sroa.12.0..sroa_idx.sroa_idx, align 1
  %_122.sroa.12.sroa.10.0._122.sroa.12.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 162
  store i8 %596, ptr %_122.sroa.12.sroa.10.0._122.sroa.12.0..sroa_idx.sroa_idx, align 2
  %_122.sroa.13.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 168
  store ptr %_306, ptr %_122.sroa.13.0..sroa_idx, align 8
  %_122.sroa.13.sroa.4.0._122.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 176
  store ptr %_447, ptr %_122.sroa.13.sroa.4.0._122.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.13.sroa.5.0._122.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 184
  store ptr %_451, ptr %_122.sroa.13.sroa.5.0._122.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.13.sroa.6.0._122.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 192
  store ptr %_305, ptr %_122.sroa.13.sroa.6.0._122.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.13.sroa.7.0._122.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 200
  store i64 %_144, ptr %_122.sroa.13.sroa.7.0._122.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.13.sroa.8.0._122.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 208
  store i8 %608, ptr %_122.sroa.13.sroa.8.0._122.sroa.13.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.13.sroa.9.0._122.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 209
  store i8 %604, ptr %_122.sroa.13.sroa.9.0._122.sroa.13.0..sroa_idx.sroa_idx, align 1
  %_122.sroa.13.sroa.10.0._122.sroa.13.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 210
  store i8 %606, ptr %_122.sroa.13.sroa.10.0._122.sroa.13.0..sroa_idx.sroa_idx, align 2
  %_122.sroa.14.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 216
  store ptr %_309, ptr %_122.sroa.14.0..sroa_idx, align 8
  %_122.sroa.14.sroa.4.0._122.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 224
  store ptr %_455, ptr %_122.sroa.14.sroa.4.0._122.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.14.sroa.5.0._122.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 232
  store ptr %_459, ptr %_122.sroa.14.sroa.5.0._122.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.14.sroa.6.0._122.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 240
  store ptr %_308, ptr %_122.sroa.14.sroa.6.0._122.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.14.sroa.7.0._122.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 248
  store i64 %_149, ptr %_122.sroa.14.sroa.7.0._122.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.14.sroa.8.0._122.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 256
  store i8 %615, ptr %_122.sroa.14.sroa.8.0._122.sroa.14.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.14.sroa.9.0._122.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 257
  store i8 %617, ptr %_122.sroa.14.sroa.9.0._122.sroa.14.0..sroa_idx.sroa_idx, align 1
  %_122.sroa.14.sroa.10.0._122.sroa.14.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 258
  store i8 %619, ptr %_122.sroa.14.sroa.10.0._122.sroa.14.0..sroa_idx.sroa_idx, align 2
  %_122.sroa.15.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 264
  store ptr %_2.i224, ptr %_122.sroa.15.0..sroa_idx, align 8
  %_122.sroa.15.sroa.4.0._122.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 272
  store ptr %_12.i225, ptr %_122.sroa.15.sroa.4.0._122.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.15.sroa.5.0._122.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 280
  store ptr %_16.i231, ptr %_122.sroa.15.sroa.5.0._122.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.15.sroa.6.0._122.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 288
  store ptr %_5.i237, ptr %_122.sroa.15.sroa.6.0._122.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.15.sroa.7.0._122.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 296
  store i64 %_6.i238, ptr %_122.sroa.15.sroa.7.0._122.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.15.sroa.8.0._122.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 304
  store i8 %628, ptr %_122.sroa.15.sroa.8.0._122.sroa.15.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.15.sroa.9.0._122.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 305
  store i8 %630, ptr %_122.sroa.15.sroa.9.0._122.sroa.15.0..sroa_idx.sroa_idx, align 1
  %_122.sroa.15.sroa.10.0._122.sroa.15.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 306
  store i8 %632, ptr %_122.sroa.15.sroa.10.0._122.sroa.15.0..sroa_idx.sroa_idx, align 2
  %_122.sroa.16.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 312
  store ptr %_314, ptr %_122.sroa.16.0..sroa_idx, align 8
  %_122.sroa.16.sroa.4.0._122.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 320
  store ptr %_468, ptr %_122.sroa.16.sroa.4.0._122.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.16.sroa.5.0._122.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 328
  store ptr %_464, ptr %_122.sroa.16.sroa.5.0._122.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.16.sroa.6.0._122.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 336
  store ptr %_316, ptr %_122.sroa.16.sroa.6.0._122.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.16.sroa.7.0._122.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 344
  store i64 %_163, ptr %_122.sroa.16.sroa.7.0._122.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.16.sroa.8.0._122.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 352
  store i8 %639, ptr %_122.sroa.16.sroa.8.0._122.sroa.16.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.16.sroa.9.0._122.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 353
  store i8 %641, ptr %_122.sroa.16.sroa.9.0._122.sroa.16.0..sroa_idx.sroa_idx, align 1
  %_122.sroa.16.sroa.10.0._122.sroa.16.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 354
  store i8 %643, ptr %_122.sroa.16.sroa.10.0._122.sroa.16.0..sroa_idx.sroa_idx, align 2
  %_122.sroa.17.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 360
  store ptr %_322, ptr %_122.sroa.17.0..sroa_idx, align 8
  %_122.sroa.17.sroa.4.0._122.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 368
  store ptr %_472, ptr %_122.sroa.17.sroa.4.0._122.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.17.sroa.5.0._122.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 376
  store ptr %_476, ptr %_122.sroa.17.sroa.5.0._122.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.17.sroa.6.0._122.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 384
  store ptr %_323, ptr %_122.sroa.17.sroa.6.0._122.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.17.sroa.7.0._122.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 392
  store i64 %_175, ptr %_122.sroa.17.sroa.7.0._122.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.17.sroa.8.0._122.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 400
  store i8 %649, ptr %_122.sroa.17.sroa.8.0._122.sroa.17.0..sroa_idx.sroa_idx, align 8
  %_122.sroa.17.sroa.9.0._122.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 401
  store i8 %651, ptr %_122.sroa.17.sroa.9.0._122.sroa.17.0..sroa_idx.sroa_idx, align 1
  %_122.sroa.17.sroa.10.0._122.sroa.17.0..sroa_idx.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 402
  store i8 %653, ptr %_122.sroa.17.sroa.10.0._122.sroa.17.0..sroa_idx.sroa_idx, align 2
  store i64 0, ptr %_120, align 8
  %_478.sroa.4.0._120.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_478.sroa.4.0._120.sroa_idx, align 8
  %_478.sroa.5.0._120.sroa_idx = getelementptr inbounds i8, ptr %_120, i64 16
  store i64 0, ptr %_478.sroa.5.0._120.sroa_idx, align 8
  %655 = getelementptr inbounds i8, ptr %_120, i64 24
  store ptr %_2.i, ptr %655, align 8
  %_121.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 32
  store ptr %_12.i164, ptr %_121.sroa.4.0..sroa_idx, align 8
  %_121.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 40
  store ptr %_16.i, ptr %_121.sroa.5.0..sroa_idx, align 8
  %_121.sroa.6.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 48
  store ptr %_5.i171, ptr %_121.sroa.6.0..sroa_idx, align 8
  %_121.sroa.7.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 56
  store i64 %_6.i, ptr %_121.sroa.7.0..sroa_idx, align 8
  %_121.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 64
  store i8 %577, ptr %_121.sroa.8.0..sroa_idx, align 8
  %_121.sroa.9.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 65
  store i8 %579, ptr %_121.sroa.9.0..sroa_idx, align 1
  %_121.sroa.10.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 66
  store i8 %581, ptr %_121.sroa.10.0..sroa_idx, align 2
  %_121.sroa.11.0..sroa_idx = getelementptr inbounds i8, ptr %_120, i64 67
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(5) %_121.sroa.11.0..sroa_idx, ptr noundef nonnull align 1 dereferenceable(5) %_121.sroa.11, i64 5, i1 false)
  %656 = getelementptr inbounds i8, ptr %_120, i64 408
  store ptr %_106, ptr %656, align 8
  %657 = getelementptr inbounds i8, ptr %_120, i64 416
  store i64 1, ptr %657, align 8
  call void @llvm.lifetime.end.p0(i64 5, ptr nonnull %_121.sroa.11)
; call pump_recovered::pump_fees::cpi::admin_cto_sharing_config
  %658 = call { i64, ptr } @_ZN14pump_recovered9pump_fees3cpi24admin_cto_sharing_config17hb339d2894fd16ae6E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(424) %_120, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(33) %val6) #27
  %659 = extractvalue { i64, ptr } %658, 0
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %_120)
  %660 = icmp eq i64 %659, 2
  br i1 %660, label %bb38, label %bb65

bb39:                                             ; preds = %bb38
  %_330 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %661 = getelementptr inbounds i8, ptr %_330, i64 112
  store i64 %1, ptr %661, align 8
  br label %bb40

bb40:                                             ; preds = %bb38, %bb39
  %_331 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %662 = getelementptr inbounds i8, ptr %_331, i64 164
  store i8 0, ptr %662, align 4
  %_333 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %663 = getelementptr inbounds i8, ptr %_333, i64 112
  %nf = load i64, ptr %663, align 8, !noundef !2
  %664 = getelementptr inbounds i8, ptr %_266, i64 112
  %_189 = load ptr, ptr %664, align 8, !nonnull !2, !align !3, !noundef !2
; call solana_account_info::AccountInfo::data_is_empty
  %_188 = call noundef zeroext i1 @_ZN19solana_account_info11AccountInfo13data_is_empty17h4cbad3bc61143bcfE(ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_189) #27
  br i1 %_188, label %bb46, label %bb43

bb43:                                             ; preds = %bb40
  %_190 = load ptr, ptr %664, align 8, !nonnull !2, !align !3, !noundef !2
  %665 = getelementptr inbounds i8, ptr %_190, i64 24
  %_483 = load ptr, ptr %665, align 8, !nonnull !2, !align !392, !noundef !2
  %666 = call i32 @memcmp(ptr noundef nonnull dereferenceable(32) %_483, ptr noundef nonnull dereferenceable(32) @_ZN14pump_recovered8pump_amm2ID17h273c877549d15150E, i64 32)
  %667 = icmp eq i32 %666, 0
  br i1 %667, label %bb44, label %bb46

bb46:                                             ; preds = %bb40, %bb43
  call void @sol_log_(ptr noundef nonnull @alloc_f1e0cbbc2b934c2f02dd0c84a052221d, i64 noundef 48) #27
  br label %bb47

bb44:                                             ; preds = %bb43
  %668 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %669 = getelementptr inbounds i8, ptr %668, i64 165
  %670 = load i8, ptr %669, align 1, !range !394, !noundef !2
  %671 = icmp ne i8 %670, 0
  call void @llvm.lifetime.start.p0(i64 424, ptr nonnull %_195)
  %672 = getelementptr inbounds i8, ptr %_266, i64 88
  %_487 = load ptr, ptr %672, align 8, !nonnull !2, !align !3, !noundef !2
  %673 = getelementptr inbounds i8, ptr %_195, i64 24
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %673, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_487) #27
  call void @llvm.lifetime.start.p0(i64 336, ptr nonnull %_197)
  %_488 = load ptr, ptr %_266, align 8, !nonnull !2, !align !3, !noundef !2
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_197, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_488) #27
  %674 = getelementptr inbounds i8, ptr %_266, i64 96
  %_489 = load ptr, ptr %674, align 8, !nonnull !2, !align !3, !noundef !2
  %675 = getelementptr inbounds i8, ptr %_197, i64 48
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %675, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_489) #27
  %_490 = load ptr, ptr %664, align 8, !nonnull !2, !align !3, !noundef !2
  %676 = getelementptr inbounds i8, ptr %_197, i64 96
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %676, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_490) #27
  %677 = getelementptr inbounds i8, ptr %_266, i64 104
  %_491 = load ptr, ptr %677, align 8, !nonnull !2, !align !3, !noundef !2
  %678 = getelementptr inbounds i8, ptr %_197, i64 144
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %678, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_491) #27
  %_492 = load ptr, ptr %_77, align 8, !nonnull !2, !align !3, !noundef !2
  %679 = getelementptr inbounds i8, ptr %_197, i64 192
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %679, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_492) #27
  %680 = getelementptr inbounds i8, ptr %_266, i64 120
  %_493 = load ptr, ptr %680, align 8, !nonnull !2, !align !3, !noundef !2
  %681 = getelementptr inbounds i8, ptr %_197, i64 240
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %681, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_493) #27
  %_494 = load ptr, ptr %672, align 8, !nonnull !2, !align !3, !noundef !2
  %682 = getelementptr inbounds i8, ptr %_197, i64 288
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %682, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_494) #27
  %683 = getelementptr inbounds i8, ptr %_195, i64 72
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(336) %683, ptr noundef nonnull align 8 dereferenceable(336) %_197, i64 336, i1 false)
  store i64 0, ptr %_195, align 8
  %_495.sroa.4.0._195.sroa_idx = getelementptr inbounds i8, ptr %_195, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_495.sroa.4.0._195.sroa_idx, align 8
  %_495.sroa.5.0._195.sroa_idx = getelementptr inbounds i8, ptr %_195, i64 16
  store i64 0, ptr %_495.sroa.5.0._195.sroa_idx, align 8
  %684 = getelementptr inbounds i8, ptr %_195, i64 408
  store ptr %_106, ptr %684, align 8
  %685 = getelementptr inbounds i8, ptr %_195, i64 416
  store i64 1, ptr %685, align 8
  call void @llvm.lifetime.end.p0(i64 336, ptr nonnull %_197)
; call pump_recovered::pump_amm::cpi::admin_cto_pool
  %686 = call { i64, ptr } @_ZN14pump_recovered8pump_amm3cpi14admin_cto_pool17h6db7cfeb87b39219E(ptr noalias nocapture noundef nonnull align 8 dereferenceable(424) %_195, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) %target13, i1 noundef zeroext %671, i64 noundef %0, i64 %1) #27
  %687 = extractvalue { i64, ptr } %686, 0
  call void @llvm.lifetime.end.p0(i64 424, ptr nonnull %_195)
  %688 = icmp eq i64 %687, 2
  br i1 %688, label %bb47, label %bb65

bb47:                                             ; preds = %bb44, %bb46
  %pool_updated.sroa.0.1.off0 = phi i1 [ false, %bb46 ], [ true, %bb44 ]
  call void @llvm.lifetime.start.p0(i64 200, ptr nonnull %e)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_209)
; call solana_sysvar::clock::<impl solana_sysvar::Sysvar for solana_clock::Clock>::get
  call void @"_ZN13solana_sysvar5clock71_$LT$impl$u20$solana_sysvar..Sysvar$u20$for$u20$solana_clock..Clock$GT$3get17hf864a57fc372ac1bE"(ptr noalias nocapture noundef nonnull sret([48 x i8]) align 8 dereferenceable(48) %_209) #27
  %_503 = load i64, ptr %_209, align 8, !range !410, !noundef !2
  %trunc72.not = icmp eq i64 %_503, 0
  br i1 %trunc72.not, label %bb122, label %bb121

bb122:                                            ; preds = %bb47
  %_504.sroa.8.0..sroa_idx = getelementptr inbounds i8, ptr %_209, i64 40
  %_504.sroa.8.0.copyload = load i64, ptr %_504.sroa.8.0..sroa_idx, align 8
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_209)
  %_507 = load ptr, ptr %_266, align 8, !nonnull !2, !align !3, !noundef !2
  %_508 = load ptr, ptr %_507, align 8, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %e, ptr noundef nonnull align 1 dereferenceable(32) %_508, i64 32, i1 false)
  %689 = getelementptr inbounds i8, ptr %e, i64 32
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %689, ptr noundef nonnull align 1 dereferenceable(32) %mint, i64 32, i1 false)
  %_348 = load ptr, ptr %5, align 8, !nonnull !2, !align !3, !noundef !2
  %_511 = load ptr, ptr %_348, align 8, !nonnull !2, !align !3, !noundef !2
  %_512 = load ptr, ptr %_511, align 8, !nonnull !2, !align !392, !noundef !2
  %690 = getelementptr inbounds i8, ptr %e, i64 64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %690, ptr noundef nonnull align 1 dereferenceable(32) %_512, i64 32, i1 false)
  %691 = getelementptr inbounds i8, ptr %_348, i64 8
  %692 = getelementptr inbounds i8, ptr %e, i64 128
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %692, ptr noundef nonnull align 8 dereferenceable(32) %691, i64 32, i1 false)
  %693 = getelementptr inbounds i8, ptr %_348, i64 163
  %694 = load i8, ptr %693, align 1, !range !394, !noundef !2
  %695 = getelementptr inbounds i8, ptr %e, i64 160
  store i64 %_504.sroa.8.0.copyload, ptr %695, align 8
  %696 = getelementptr inbounds i8, ptr %e, i64 96
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %696, ptr noundef nonnull align 1 dereferenceable(32) %old_creator, i64 32, i1 false)
  %697 = getelementptr inbounds i8, ptr %e, i64 192
  store i8 %570, ptr %697, align 8
  %698 = getelementptr inbounds i8, ptr %e, i64 193
  store i8 %694, ptr %698, align 1
  %699 = getelementptr inbounds i8, ptr %e, i64 168
  store i64 %old_fee, ptr %699, align 8
  %700 = getelementptr inbounds i8, ptr %e, i64 176
  store i64 %nf, ptr %700, align 8
  %701 = getelementptr inbounds i8, ptr %e, i64 194
  %702 = zext i1 %564 to i8
  store i8 %702, ptr %701, align 2
  %703 = getelementptr inbounds i8, ptr %e, i64 184
  store i64 %_95.sroa.0.0, ptr %703, align 8
  %704 = getelementptr inbounds i8, ptr %e, i64 195
  %705 = zext i1 %pool_updated.sroa.0.1.off0 to i8
  store i8 %705, ptr %704, align 1
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_221)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_223)
; call <pump_recovered::admin_cto::AdminCtoEvent as anchor_lang::Event>::data
  call void @"_ZN79_$LT$pump_recovered..admin_cto..AdminCtoEvent$u20$as$u20$anchor_lang..Event$GT$4data17h2de1473225a7d978E"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_223, ptr noalias noundef nonnull readonly align 8 dereferenceable(200) %e) #27
  %706 = getelementptr inbounds i8, ptr %_223, i64 8
  %_515 = load ptr, ptr %706, align 8, !nonnull !2, !noundef !2
  %707 = getelementptr inbounds i8, ptr %_223, i64 16
  %_514 = load i64, ptr %707, align 8, !noundef !2
  store ptr %_515, ptr %_221, align 8
  %708 = getelementptr inbounds i8, ptr %_221, i64 8
  store i64 %_514, ptr %708, align 8
; call solana_program::log::sol_log_data
  call void @_ZN14solana_program3log12sol_log_data17h1e024b73f122854fE(ptr noalias noundef nonnull readonly align 8 %_221, i64 noundef 1) #27
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_223)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_221)
  %_226 = getelementptr inbounds i8, ptr %_266, i64 312
; call <solana_account_info::AccountInfo as core::clone::Clone>::clone
  call fastcc void @"_ZN71_$LT$solana_account_info..AccountInfo$u20$as$u20$core..clone..Clone$GT$5clone17h759150bcde62cc00E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %authority_info, ptr noalias noundef nonnull readonly align 8 dereferenceable(48) %_226) #27
  %709 = getelementptr inbounds i8, ptr %ctx, i64 46
  %authority_bump = load i8, ptr %709, align 2, !noundef !2
; call <pump_recovered::admin_cto::AdminCtoEvent as anchor_lang::Event>::data
  call void @"_ZN79_$LT$pump_recovered..admin_cto..AdminCtoEvent$u20$as$u20$anchor_lang..Event$GT$4data17h2de1473225a7d978E"(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %inner_data, ptr noalias noundef nonnull readonly align 8 dereferenceable(200) %e) #27
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %ix_data)
  %me.sroa.0.0.copyload.i = load i64, ptr %inner_data, align 8, !alias.scope !5713, !noalias !5716
  %me.sroa.4.0.self.sroa_idx.i = getelementptr inbounds i8, ptr %inner_data, i64 8
  %me.sroa.4.0.copyload.i = load ptr, ptr %me.sroa.4.0.self.sroa_idx.i, align 8, !alias.scope !5713, !noalias !5716, !nonnull !2, !noundef !2
  %me.sroa.5.0.self.sroa_idx.i = getelementptr inbounds i8, ptr %inner_data, i64 16
  %me.sroa.5.0.copyload.i = load i64, ptr %me.sroa.5.0.self.sroa_idx.i, align 8, !alias.scope !5713, !noalias !5716
  %_18.i270 = getelementptr inbounds i8, ptr %me.sroa.4.0.copyload.i, i64 %me.sroa.5.0.copyload.i
  %710 = getelementptr inbounds i8, ptr %_232, i64 32
  store ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, ptr %710, align 8
  %711 = getelementptr inbounds i8, ptr %_232, i64 40
  store ptr getelementptr inbounds (<{ [8 x i8] }>, ptr @alloc_d1e50873cb16f1fc41ca481a2a657dfa, i64 1, i32 0, i64 0), ptr %711, align 8
  store ptr %me.sroa.4.0.copyload.i, ptr %_232, align 8
  %_525.sroa.4.0._232.sroa_idx = getelementptr inbounds i8, ptr %_232, i64 8
  store ptr %me.sroa.4.0.copyload.i, ptr %_525.sroa.4.0._232.sroa_idx, align 8
  %_525.sroa.5.0._232.sroa_idx = getelementptr inbounds i8, ptr %_232, i64 16
  store i64 %me.sroa.0.0.copyload.i, ptr %_525.sroa.5.0._232.sroa_idx, align 8
  %_525.sroa.6.0._232.sroa_idx = getelementptr inbounds i8, ptr %_232, i64 24
  store ptr %_18.i270, ptr %_525.sroa.6.0._232.sroa_idx, align 8
; call <alloc::vec::Vec<T> as alloc::vec::spec_from_iter::SpecFromIter<T,I>>::from_iter
  call fastcc void @"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h05834ec09ece64f1E"(ptr noalias nocapture noundef nonnull align 8 dereferenceable(24) %ix_data, ptr noalias nocapture noundef nonnull align 8 dereferenceable(48) %_232) #27
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %ix)
  %712 = getelementptr inbounds i8, ptr %ix_data, i64 8
  %_528 = load ptr, ptr %712, align 8, !nonnull !2, !noundef !2
  %713 = getelementptr inbounds i8, ptr %ix_data, i64 16
  %_527 = load i64, ptr %713, align 8, !noundef !2
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_239)
; call alloc::alloc::exchange_malloc
  %_241 = call fastcc noundef ptr @_ZN5alloc5alloc15exchange_malloc17h6cd8dd11b0e3424eE(i64 noundef 34, i64 noundef 1) #27
  %_354 = load ptr, ptr %authority_info, align 8, !nonnull !2, !align !392, !noundef !2
  call void @llvm.memmove.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %_241, ptr noundef nonnull align 1 dereferenceable(32) %_354, i64 32, i1 false)
  %_243.sroa.4.0..sroa_idx = getelementptr inbounds i8, ptr %_241, i64 32
  store i8 1, ptr %_243.sroa.4.0..sroa_idx, align 1
  %_243.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_241, i64 33
  store i8 0, ptr %_243.sroa.5.0..sroa_idx, align 1
  store i64 1, ptr %_239, align 8, !alias.scope !5718, !noalias !5721
  %714 = getelementptr inbounds i8, ptr %_239, i64 8
  store ptr %_241, ptr %714, align 8, !alias.scope !5718, !noalias !5721
  %715 = getelementptr inbounds i8, ptr %_239, i64 16
  store i64 1, ptr %715, align 8, !alias.scope !5718, !noalias !5721
; call solana_instruction::Instruction::new_with_bytes
  call void @_ZN18solana_instruction11Instruction14new_with_bytes17h836fab8fb6401158E(ptr noalias nocapture noundef nonnull sret([80 x i8]) align 8 dereferenceable(80) %ix, ptr noalias nocapture noundef nonnull readonly align 1 dereferenceable(32) @_ZN14pump_recovered2ID17h8e245cf89cf2c06bE, ptr noalias noundef nonnull readonly align 1 %_528, i64 noundef %_527, ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_239) #27
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_239)
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %_251)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_251, ptr noundef nonnull align 8 dereferenceable(48) %authority_info, i64 48, i1 false)
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %_254)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %_257)
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %_261)
  store i8 %authority_bump, ptr %_261, align 1
  store ptr @alloc_7a7952b5e0d15f2b72d0341cef6d4739, ptr %_257, align 8
  %716 = getelementptr inbounds i8, ptr %_257, i64 8
  store i64 17, ptr %716, align 8
  %717 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_257, i64 0, i64 1
  store ptr %_261, ptr %717, align 8
  %718 = getelementptr inbounds [2 x { ptr, i64 }], ptr %_257, i64 0, i64 1, i32 1
  store i64 1, ptr %718, align 8
  store ptr %_257, ptr %_254, align 8
  %719 = getelementptr inbounds i8, ptr %_254, i64 8
  store i64 2, ptr %719, align 8
; call solana_program::program::invoke_signed
  call void @_ZN14solana_program7program13invoke_signed17h01c3b84bc1fc491eE(ptr noalias nocapture noundef nonnull sret([24 x i8]) align 8 dereferenceable(24) %_247, ptr noalias noundef nonnull readonly align 8 dereferenceable(80) %ix, ptr noalias noundef nonnull readonly align 8 %_251, i64 noundef 1, ptr noalias noundef nonnull readonly align 8 %_254, i64 noundef 1) #27
  %720 = load i64, ptr %_247, align 8, !range !408, !noundef !2
  %721 = icmp eq i64 %720, -9223372036854775782
  br i1 %721, label %bb131, label %bb130

bb121:                                            ; preds = %bb47
  %722 = getelementptr inbounds i8, ptr %_209, i64 8
  %_505.sroa.0.0.copyload = load i64, ptr %722, align 8
  %_505.sroa.5.0..sroa_idx = getelementptr inbounds i8, ptr %_209, i64 16
  %_505.sroa.5.0.copyload = load i64, ptr %_505.sroa.5.0..sroa_idx, align 8
  %_505.sroa.6.0..sroa_idx = getelementptr inbounds i8, ptr %_209, i64 24
  %_505.sroa.6.0.copyload = load i64, ptr %_505.sroa.6.0..sroa_idx, align 8
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_209)
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %_509)
  store i64 %_505.sroa.0.0.copyload, ptr %_509, align 8
  %residual9.sroa.2.0._509.sroa_idx = getelementptr inbounds i8, ptr %_509, i64 8
  store i64 %_505.sroa.5.0.copyload, ptr %residual9.sroa.2.0._509.sroa_idx, align 8
  %residual9.sroa.3.0._509.sroa_idx = getelementptr inbounds i8, ptr %_509, i64 16
  store i64 %_505.sroa.6.0.copyload, ptr %residual9.sroa.3.0._509.sroa_idx, align 8
; call <anchor_lang::error::Error as core::convert::From<solana_program_error::ProgramError>>::from
  %723 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_509) #27
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %_509)
  br label %bb63

bb131:                                            ; preds = %bb122
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_261)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_257)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_254)
  %724 = getelementptr inbounds i8, ptr %_251, i64 8
  %_251.val82 = load ptr, ptr %724, align 8, !nonnull !2, !noundef !2
  %725 = getelementptr inbounds i8, ptr %_251, i64 16
  %_251.val83 = load ptr, ptr %725, align 8
  %self1.val.i.i.i.i = load i64, ptr %_251.val82, align 8, !noundef !2
  %val.i.i.i.i = add i64 %self1.val.i.i.i.i, -1
  store i64 %val.i.i.i.i, ptr %_251.val82, align 8
  %726 = icmp eq i64 %val.i.i.i.i, 0
  br i1 %726, label %bb1.i.i.i.i, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i"

bb1.i.i.i.i:                                      ; preds = %bb131
  %727 = getelementptr i8, ptr %_251.val82, i64 8
  %self2.val.i.i.i.i = load i64, ptr %727, align 8, !noundef !2
  %val6.i.i.i.i = add i64 %self2.val.i.i.i.i, -1
  store i64 %val6.i.i.i.i, ptr %727, align 8
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i": ; preds = %bb1.i.i.i.i, %bb131
  %728 = icmp ne ptr %_251.val83, null
  call void @llvm.assume(i1 %728)
  %self1.val.i.i2.i.i = load i64, ptr %_251.val83, align 8, !noundef !2
  %val.i.i3.i.i = add i64 %self1.val.i.i2.i.i, -1
  store i64 %val.i.i3.i.i, ptr %_251.val83, align 8
  %729 = icmp eq i64 %val.i.i3.i.i, 0
  br i1 %729, label %bb1.i.i4.i.i, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"

bb1.i.i4.i.i:                                     ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i"
  %730 = getelementptr i8, ptr %_251.val83, i64 8
  %self2.val.i.i5.i.i = load i64, ptr %730, align 8, !noundef !2
  %val6.i.i6.i.i = add i64 %self2.val.i.i5.i.i, -1
  store i64 %val6.i.i6.i.i, ptr %730, align 8
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit": ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i", %bb1.i.i4.i.i
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_251)
  %_1.val.i = load i64, ptr %ix, align 8, !alias.scope !5723, !noundef !2
  %731 = icmp eq i64 %_1.val.i, 0
  br i1 %731, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i", label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"
  %732 = getelementptr inbounds i8, ptr %ix, i64 8
  %_1.val2.i = load ptr, ptr %732, align 8, !alias.scope !5723
  %733 = icmp ne ptr %_1.val2.i, null
  call void @llvm.assume(i1 %733)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i": ; preds = %bb2.i.i.i.i, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit"
  %734 = getelementptr inbounds i8, ptr %ix, i64 24
  %.val.i = load i64, ptr %734, align 8, !alias.scope !5723, !noundef !2
  %735 = icmp eq i64 %.val.i, 0
  br i1 %735, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i"
  %736 = getelementptr inbounds i8, ptr %ix, i64 32
  %.val1.i = load ptr, ptr %736, align 8, !alias.scope !5723
  %737 = icmp ne ptr %.val1.i, null
  call void @llvm.assume(i1 %737)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i", %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data)
  call void @llvm.lifetime.end.p0(i64 200, ptr nonnull %e)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_114)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_109)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_106)
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %hk)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %holder_key)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %mint)
  br label %bb68

bb130:                                            ; preds = %bb122
; call <anchor_lang::error::Error as core::convert::From<solana_program_error::ProgramError>>::from
  %738 = call { i64, ptr } @"_ZN107_$LT$anchor_lang..error..Error$u20$as$u20$core..convert..From$LT$solana_program_error..ProgramError$GT$$GT$4from17ha4865197be4b9a2fE"(ptr noalias nocapture noundef nonnull readonly align 8 dereferenceable(24) %_247) #27
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_261)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %_257)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_254)
  %739 = getelementptr inbounds i8, ptr %_251, i64 8
  %_251.val = load ptr, ptr %739, align 8, !nonnull !2, !noundef !2
  %740 = getelementptr inbounds i8, ptr %_251, i64 16
  %_251.val81 = load ptr, ptr %740, align 8
  %self1.val.i.i.i.i273 = load i64, ptr %_251.val, align 8, !noundef !2
  %val.i.i.i.i274 = add i64 %self1.val.i.i.i.i273, -1
  store i64 %val.i.i.i.i274, ptr %_251.val, align 8
  %741 = icmp eq i64 %val.i.i.i.i274, 0
  br i1 %741, label %bb1.i.i.i.i281, label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i275"

bb1.i.i.i.i281:                                   ; preds = %bb130
  %742 = getelementptr i8, ptr %_251.val, i64 8
  %self2.val.i.i.i.i282 = load i64, ptr %742, align 8, !noundef !2
  %val6.i.i.i.i283 = add i64 %self2.val.i.i.i.i282, -1
  store i64 %val6.i.i.i.i283, ptr %742, align 8
  br label %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i275"

"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i275": ; preds = %bb1.i.i.i.i281, %bb130
  %743 = icmp ne ptr %_251.val81, null
  call void @llvm.assume(i1 %743)
  %self1.val.i.i2.i.i276 = load i64, ptr %_251.val81, align 8, !noundef !2
  %val.i.i3.i.i277 = add i64 %self1.val.i.i2.i.i276, -1
  store i64 %val.i.i3.i.i277, ptr %_251.val81, align 8
  %744 = icmp eq i64 %val.i.i3.i.i277, 0
  br i1 %744, label %bb1.i.i4.i.i278, label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit284"

bb1.i.i4.i.i278:                                  ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i275"
  %745 = getelementptr i8, ptr %_251.val81, i64 8
  %self2.val.i.i5.i.i279 = load i64, ptr %745, align 8, !noundef !2
  %val6.i.i6.i.i280 = add i64 %self2.val.i.i5.i.i279, -1
  store i64 %val6.i.i6.i.i280, ptr %745, align 8
  br label %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit284"

"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit284": ; preds = %"_ZN4core3ptr84drop_in_place$LT$alloc..rc..Rc$LT$core..cell..RefCell$LT$$RF$mut$u20$u64$GT$$GT$$GT$17h78933b33a7933ef9E.exit.i.i275", %bb1.i.i4.i.i278
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_251)
  %_1.val.i285 = load i64, ptr %ix, align 8, !alias.scope !5726, !noundef !2
  %746 = icmp eq i64 %_1.val.i285, 0
  br i1 %746, label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i288", label %bb2.i.i.i.i286

bb2.i.i.i.i286:                                   ; preds = %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit284"
  %747 = getelementptr inbounds i8, ptr %ix, i64 8
  %_1.val2.i287 = load ptr, ptr %747, align 8, !alias.scope !5726
  %748 = icmp ne ptr %_1.val2.i287, null
  call void @llvm.assume(i1 %748)
  br label %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i288"

"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i288": ; preds = %bb2.i.i.i.i286, %"_ZN4core3ptr74drop_in_place$LT$$u5b$solana_account_info..AccountInfo$u3b$$u20$1$u5d$$GT$17h907ee5ac84b0815bE.exit284"
  %749 = getelementptr inbounds i8, ptr %ix, i64 24
  %.val.i289 = load i64, ptr %749, align 8, !alias.scope !5726, !noundef !2
  %750 = icmp eq i64 %.val.i289, 0
  br i1 %750, label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit292", label %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i290"

"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i290": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i288"
  %751 = getelementptr inbounds i8, ptr %ix, i64 32
  %.val1.i291 = load ptr, ptr %751, align 8, !alias.scope !5726
  %752 = icmp ne ptr %.val1.i291, null
  call void @llvm.assume(i1 %752)
  br label %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit292"

"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit292": ; preds = %"_ZN4core3ptr89drop_in_place$LT$alloc..vec..Vec$LT$solana_instruction..account_meta..AccountMeta$GT$$GT$17h57f29fa0325d9f10E.exit.i288", %"_ZN63_$LT$alloc..alloc..Global$u20$as$u20$core..alloc..Allocator$GT$10deallocate17h6b30618160528bb2E.exit.i.i.i.i290"
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %ix)
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %ix_data)
  br label %bb63

bb68:                                             ; preds = %bb67, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit"
  %_0.sroa.11.1 = phi ptr [ %_0.sroa.11.4, %bb67 ], [ undef, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit" ]
  %_0.sroa.0.1 = phi i64 [ %_0.sroa.0.4, %bb67 ], [ 2, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit" ]
  %753 = insertvalue { i64, ptr } poison, i64 %_0.sroa.0.1, 0
  %754 = insertvalue { i64, ptr } %753, ptr %_0.sroa.11.1, 1
  ret { i64, ptr } %754

bb63:                                             ; preds = %bb121, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit292"
  %.pn = phi { i64, ptr } [ %723, %bb121 ], [ %738, %"_ZN4core3ptr52drop_in_place$LT$solana_instruction..Instruction$GT$17h3ecb6a9b9e1b11acE.exit292" ]
  %_0.sroa.0.2 = extractvalue { i64, ptr } %.pn, 0
  call void @llvm.lifetime.end.p0(i64 200, ptr nonnull %e)
  br label %bb65

bb65:                                             ; preds = %bb63, %bb44, %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit269
  %.pn.pn.pn = phi { i64, ptr } [ %658, %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit269 ], [ %.pn, %bb63 ], [ %686, %bb44 ]
  %_0.sroa.0.3 = phi i64 [ %659, %_ZN5alloc2rc10RcInnerPtr10inc_strong17hbf2f50dabd5a1ea9E.exit269 ], [ %_0.sroa.0.2, %bb63 ], [ %687, %bb44 ]
  %_0.sroa.11.3 = extractvalue { i64, ptr } %.pn.pn.pn, 1
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %_114)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %_109)
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %_106)
  br label %bb67

bb67:                                             ; preds = %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316, %bb65, %bb88, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit", %bb79, %bb75
  %_0.sroa.11.4 = phi ptr [ %_49.sroa.27.1.ph, %bb75 ], [ %_0.sroa.11.3, %bb65 ], [ %565, %bb88 ], [ %_81.1, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit" ], [ %173, %bb79 ], [ %_0.sroa.11.4.i.ph, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316 ], [ %_0.sroa.11.4.i, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit ]
  %_0.sroa.0.4 = phi i64 [ %_49.sroa.16.1.ph, %bb75 ], [ %_0.sroa.0.3, %bb65 ], [ %_415.sroa.0.4, %bb88 ], [ %_81.0, %"_ZN45_$LT$T$u20$as$u20$alloc..string..ToString$GT$9to_string17h1551814bef63e52cE.exit" ], [ %169, %bb79 ], [ %_0.sroa.0.4.i.ph, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit.thread316 ], [ %_0.sroa.0.4.i, %_ZN14pump_recovered9admin_cto7execute6wallet17h67aeb09bf4f58cf9E.exit ]
  call void @llvm.lifetime.end.p0(i64 33, ptr nonnull %hk)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %holder_key)
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %mint)
  br label %bb68
}