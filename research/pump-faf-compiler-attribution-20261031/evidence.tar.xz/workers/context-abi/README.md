# Frozen FAF sharing-CPI CpiContext closure

This packet closes the five CpiContext header fields omitted from the prior
64-field original AccountInfo census. All five agree between the captured
original and the actual admitted FAF artifact. It identifies no ABI discrepancy
and proposes no Rust change, build trial or source gain.

The frozen source is `faf99624250b4e60107790f7edabf6609f709885`; the parent
source141 seal is `29a8df2d7e12b379a9dc515d5a84eaaf051729da62350a54996a0077015f0c8a`.
The original full payload is SHA256
`7a19affaa2c6187e04a5fe0ea298cee81fa5eb8c24cfcc30d85f615e89f7b02d`.
The admitted `work/lifecycle/run41146593117/artifact/unstripped.so` is SHA256
`8febf467fc61fbf17ff11045ed9d7b0d3aba0eeedbcadf5060abb2552212b02a`.
No statement here describes a later main revision.

## Coordinates and evidence

CTO is VA `0x22a10..0x29518`, 27,400 bytes, in both images. Its actual FAF
`STT_FUNC` is unique. The sharing call is original CTO+`0x4a78` (VA `0x27488`)
and FAF CTO+`0x49f8` (VA `0x27408`). Both direct-call immediates resolve to
VA `0x116718`, the unique FAF `admin_cto_sharing_config` symbol, 4,040 bytes.
The complete original/candidate callee bytes agree, SHA256
`29448eb927f43b914f919fa969440b2d7192b77a501548ee3f22da69ffe63833`.

`FP` means r10 of the CTO caller. The callee has its own r10. Both callers
pass r1=`FP-0x860` (return slot), r2=`FP-0x2d0` (CpiContext), and
r3=`FP-0x651` (the `Option<Pubkey>` argument). A context offset is relative
to r2, never to the callee r10. Objdump's decimal numbers in the preserved
`work/trading/FAF-*.txt` are instruction-slot coordinates VA/8, not logical
instruction counts or CTO offsets. `LDDW` occupies 16 bytes. Analysis used
maintained `score.body`, `sections`, `instruction_stream` and `elf_symbols`.
Here `.text` has both VA and file offset `0x120`; that numerical coincidence
is not the general address translation rule.

## Five reaching definitions

| Field | Context offset | Caller frame | Value | Original store CTO offset (VA) | FAF store CTO offset (VA) |
| --- | --- | --- | --- | --- | --- |
| remaining_accounts capacity | `+0x0` | `FP-0x2d0` | `0` | `0x4a38` (`0x27448`) | `0x49b8` (`0x273c8`) |
| remaining_accounts pointer | `+0x8` | `FP-0x2c8` | `8` | `0x4a30` (`0x27440`) | `0x49b0` (`0x273c0`) |
| remaining_accounts length | `+0x10` | `FP-0x2c0` | `0` | `0x4a28` (`0x27438`) | `0x49a8` (`0x273b8`) |
| signer_seeds pointer | `+0x198` | `FP-0x138` | `FP-0x4d0` | `0x4a00` (`0x27410`) | `0x4980` (`0x27390`) |
| signer_seeds length | `+0x1a0` | `FP-0x130` | `1` | `0x4a40` (`0x27450`) | `0x49c0` (`0x273d0`) |

The pointer store is preceded by `mov64 r1,r10; add64 r1,-0x4d0` in each
caller. The other four stores are immediate `stdw`. Removing each defining
instruction from its complete caller CFG makes the sharing call unreachable.
The LDDW-aware CFGs contain 3,339 original and 3,337 FAF logical instructions;
all are conservatively reachable when both conditional outcomes and returning
calls are admitted. Calls are treated as returning even on abort paths, so this
is an overapproximation, not reliance on an inferred no-return function.

Between each header definition and its sharing call there is no branch, call,
indirect store or overlapping subsequent frame write. These are exact reaching
definitions at the call, not values inferred from `new_with_signer` spelling.
The raw zero length proves that the outer `ctx.remaining_accounts` is not
propagated into this particular sharing CPI. It says nothing about other CPIs.
The pointer `8` is an empty Vec sentinel, not an account pointer read on this
zero-length path.

## Nested signer seeds

The context signer pair is a slice of **one signer**, whose element is a
slice of **three byte slices**. It is not a flat three-entry signer slice:

```text
context+0x198 -> FP-0x4d0; context+0x1a0 = 1
FP-0x4d0: { pointer: FP-0x4b8, length: 3 }
FP-0x4b8: { pointer: VA0x1b68a2, length: 14 }  # b"pool-authority"
FP-0x4a8: { pointer: FP-0x6c0,   length: 32 }  # mint key copy
FP-0x498: { pointer: FP-0x530,   length: 1  }  # bump byte
```

The exact defining stores are:

| Definition | Original CTO offset | FAF CTO offset |
| --- | --- | --- |
| outer element pointer at `FP-0x4d0` | `0x3cd8` | `0x3c98` |
| outer element length 3 at `FP-0x4c8` | `0x3cf8` | `0x3cb8` |
| seed 0 pointer at `FP-0x4b8` | `0x3cb8` | `0x3c78` |
| seed 0 length 14 at `FP-0x4b0` | `0x3cf0` | `0x3cb0` |
| seed 1 pointer at `FP-0x4a8` | `0x3ca0` | `0x3c60` |
| seed 1 length 32 at `FP-0x4a0` | `0x3ce8` | `0x3ca8` |
| seed 2 pointer at `FP-0x498` | `0x3c88` | `0x3c48` |
| seed 2 length 1 at `FP-0x490` | `0x3ce0` | `0x3ca0` |
| bump byte at `FP-0x530` | `0x3cc0` | `0x3c80` |

All nine stores dominate the call; none has a later overlapping direct frame
write before the call. No intervening call exists from this seed setup through
the sharing call. The literal load is an actual 16-byte LDDW at original
CTO+`0x3ca8` and FAF CTO+`0x3c68`.

The mint copy is identically built in both callers at CTO+`0x28..0x78`:
incoming context r2+8 gives the account aggregate, aggregate+`0x10` gives
the mint AccountInfo, and AccountInfo+0 gives its key pointer. Four eight-byte
loads/stores fill `FP-0x6c0..FP-0x6a0`. The bump is loaded from incoming
context+`0x27` and stored to `FP-0x530`; the saved incoming context is original
`FP-0x938`, FAF `FP-0x930`. Its source attribution is
`ctx.bumps.pool_authority` at frozen source line 745.

For the long seed interval, this packet assumes well-typed incoming
AccountInfo/Rc pointers do not alias this function's newly created local frame.
The indirect stores in the account-clone path update externally supplied Rc
headers. The five context-header proofs need no such long-interval assumption:
their defining suffix contains no indirect store at all.

## Actual callee use

The complete body supports nonempty remaining accounts. It is not specialized
to the empty vector supplied by these two callers:

| Callee VA | Actual behavior |
| --- | --- |
| `0x116718` | Save context r2 at callee `FP-0xc0`. |
| `0x116870..0x116890` | Pass context+`0x48` to generated seven-account `to_account_metas` at `0x118360`. |
| `0x1168a0..0x1168b0` | Load context+`0x10` length; branch to `0x116aa0` if nonzero. |
| `0x116b78..0x116c50` | Nonempty path loads context+8 pointer, reads each 48-byte AccountInfo's key/signer/writable fields, emits 34-byte AccountMeta entries, and loops exactly length times. |
| `0x1168e8..0x116918` | Append the generated remaining-account metas after the fixed seven metas; empty path supplies a zero-length append. |
| `0x1169e8` | Generate fixed seven AccountInfos through `to_account_infos` at `0xca628`. |
| `0x116a08..0x116a58` | Load context+8 pointer and context+`0x10` length; skip the clone loop if length is zero. |
| `0x116e18`, `0x116ce0..0x116dc8` | Nonempty clone loop increments both Rc strong counts, copies all meaningful AccountInfo fields, advances source/destination by 48, and decrements the iteration count to zero. Rc overflow follows abort edges to `0x116e78`. |
| `0x116dd0..0x117048` | Append the context's program AccountInfo after the fixed and remaining AccountInfos. |
| `0x117050..0x117068` | Load signer length from context+`0x1a0` and pointer from context+`0x198`; place them in callee `FP-0xff8` / `FP-0x1000`. |
| `0x1170b0` | Pass r5=callee FP to `solana_program::program::invoke_signed` at `0x1a0530`; this is SBF stack-argument forwarding of the signer slice. |
| `0x117560..0x117680` | Drop the input remaining AccountInfos using context length and pointer; the empty path skips their element-drop loop. |

No context-capacity load is present among the raw body's context-alias accesses;
the element operations use pointer and length. The caller still defines capacity
explicitly as zero. Both zero-length paths bypass remaining-account element
loads; fixed metas and AccountInfos are still generated and the program account
is appended normally. Out-of-memory and Rc-overflow abort paths are retained;
this is not a claim that CPI invocation always succeeds.

`invoke_signed` loads the signer pair from its incoming r5 at VA `0x1a0558`
(length) and `0x1a0568` (pointer), retains it through borrow checks, and forwards
the pair at VA `0x1a0818..0x1a0860` to `invoke_signed_unchecked` at
`0x1a1d70`. The latter saves that stack pair at offsets `+0x20..+0x38`
and loads pointer/length into r4/r5 at offsets `+0x2e8/+0x2f0`, directly
before its relocated invoke call at VA `0x1a2068`. The helpers forward the
nested descriptors; they do not flatten or rewrite them. The 880-byte
`invoke_signed` and 984-byte `invoke_signed_unchecked` bodies are separately
byte-compared by the verifier. Runtime validation of seed lengths, bump and PDA
is outside this static packet.

## Accounting, preservation and next IR question

The prior immutable `work/trading/ORIGINAL-AGGREGATE.json` has SHA256
`8adeef25887c3e5580f3cc53cd33bef66ed72ae3fd95a89d1b2db73622be251a`.
Its eight AccountInfo extents occupy 384 bytes, containing 64 meaningful fields
whose widths total 344 bytes plus 40 padding bytes. The five newly closed fields
add 40 meaningful bytes. The cumulative original census is therefore **69
meaningful fields / 384 meaningful bytes in a 424-byte context**; 40 bytes of
AccountInfo padding remain explicitly excluded. This packet compares the five
new header fields in both callers; it does not relabel the earlier original-only
64-field provenance as a fresh FAF 64-field proof.

The optional donor `anchor-lang-0.31.1/src/context.rs` was read only after its
SHA256 `4fb586c501b94ea136c72cd2e784e3537e93827c34b403d1e4df167ef70d753e`
matched the actual artifact's `registry-source-inputs.json`. It confirms the
field/API attribution and the generic meta/info extension behavior. Raw stores
and branches, rather than the donor's constructor spelling, establish emptiness.

The next IR question is precise: **which actual `alloca`/aggregate-copy and
`lifetime.start`/`lifetime.end` boundaries for the by-value sharing context,
its seven-account temporary, and the nested signer descriptors cause the
different register/spill allocation across the clone-to-call interval, despite
these five identical ABI values and the previously mapped original fields?**
Map those allocations and their crossing live values in captured frozen-FAF IR
before proposing a source lifetime correction. This packet supplies no evidence
for changing remaining-account propagation, signer nesting, vector initialization
or any account-clone spelling.

Only files under `work/context-abi` were created. Prior packets, SDK, compiler,
VM, Rust source, ELF inputs, scorer and masks were not changed. No target program
was run; no build, score, package installation, GitHub publication or message was
performed. Identity: OpenAI, GPT-6, Codex agent client.

Reproduction (bytecode-cache writes disabled before maintained-helper imports):

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -B work/context-abi/verify.py > work/context-abi/CLOSURE.json
```

The verifier is read-only except for the shell's explicitly selected output file.
It binds both complete images, uses maintained ELF/body and logical-instruction
helpers, checks store opcodes/values, verifies CFG dominance and overwrite/call
claims, and preserves the previous 64-field receipt. A passing result is static
ABI evidence, not whole-function equivalence or a byte-match gain.
