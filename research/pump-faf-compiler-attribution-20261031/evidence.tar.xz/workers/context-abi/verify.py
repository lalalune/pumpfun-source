#!/usr/bin/env python3
"""Read-only frozen-FAF CpiContext header and signer-descriptor verifier.

Run with PYTHONDONTWRITEBYTECODE=1 python3 -B work/context-abi/verify.py.
No compiler, SDK, subprocess, scorer execution, target execution or write to an
input tree is performed. Imported maintained helpers only decode input bytes.
"""
import os
import sys

sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'reconstruction/harness'))
from score import body, sections
from instruction_stream import instruction_boundaries, instruction_offsets
from elf_symbols import function_symbols

START, SIZE, CALLEE, CALLEE_SIZE = 0x22a10, 27400, 0x116718, 4040
BASE = 'faf99624250b4e60107790f7edabf6609f709885'
FILES = {
    'original': ('evidence/original/pump/deployed.so',
                 '7a19affaa2c6187e04a5fe0ea298cee81fa5eb8c24cfcc30d85f615e89f7b02d'),
    'faf': ('work/lifecycle/run41146593117/artifact/unstripped.so',
            '8febf467fc61fbf17ff11045ed9d7b0d3aba0eeedbcadf5060abb2552212b02a'),
}


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def instructions(raw):
    rows = {}
    for off in instruction_offsets(raw):
        op, packed, displacement, immediate = struct.unpack_from('<BBhi', raw, off)
        width = 16 if op == 0x18 else 8
        rows[off] = dict(offset=off, opcode=op, dst=packed & 15,
                         src=packed >> 4, displacement=displacement,
                         immediate=immediate, width=width, raw=raw[off:off + width].hex())
    return rows


def cfg(ins):
    edges = {}
    for off, i in ins.items():
        op = i['opcode']
        nxt = off + i['width']
        successors = [] if op == 0x95 else ([nxt] if nxt in ins else [])
        if op & 7 in (5, 6) and op not in (0x85, 0x8d, 0x95):
            target = off + 8 + i['displacement'] * 8
            assert target in ins, ('branch enters a noninstruction or leaves function', off, target)
            successors = [target] if op & 0xf0 == 0 else [target] + successors
        edges[off] = successors
    return edges


def reachable(edges, blocked=None):
    seen, todo = set(), [0]
    while todo:
        node = todo.pop()
        if node in seen or node == blocked:
            continue
        seen.add(node)
        todo.extend(edges[node])
    return seen


def record(ins, off, start=START):
    return dict(window_offset=hex(off), va=hex(start + off),
                objdump_slot=(start + off) // 8, **{k: v for k, v in ins[off].items() if k != 'offset'})


def assert_store(ins, off, frame, value, width=8):
    i = ins[off]
    assert i['opcode'] == (0x7a if width == 8 else 0x72)
    assert i['dst'] == 10 and i['displacement'] == frame and i['immediate'] == value


def assert_fp_pointer(ins, off, frame, pointee):
    store, add, mov = ins[off], ins[off - 8], ins[off - 16]
    reg = store['src']
    assert store['opcode'] == 0x7b and store['dst'] == 10 and store['displacement'] == frame
    assert add['opcode'] == 0x07 and add['dst'] == reg and add['immediate'] == pointee
    assert mov['opcode'] == 0xbf and mov['dst'] == reg and mov['src'] == 10


STORE_WIDTHS = {0x7a: 8, 0x7b: 8, 0x62: 4, 0x63: 4,
                0x6a: 2, 0x6b: 2, 0x72: 1, 0x73: 1}


def direct_overwrites(ins, begin, end, frame, width):
    found = []
    for off, i in ins.items():
        if not begin < off < end or i['opcode'] not in STORE_WIDTHS or i['dst'] != 10:
            continue
        lo, hi = i['displacement'], i['displacement'] + STORE_WIDTHS[i['opcode']]
        if lo < frame + width and frame < hi:
            found.append(off)
    return found


def caller(label, raw):
    ins = instructions(raw)
    edges = cfg(ins)
    call = 0x4a78 if label == 'original' else 0x49f8
    shift = 0 if label == 'original' else -0x80
    seed_shift = 0 if label == 'original' else -0x40
    assert call in reachable(edges)
    ci = ins[call]
    assert ci['opcode'] == 0x85 and ci['src'] == 1
    assert START + call + 8 + ci['immediate'] * 8 == CALLEE
    # The three arguments are return slot, by-value context address and Option<Pubkey>.
    for pointer_end, reg, frame in [(call - 0x28, 1, -0x860),
                                    (call - 0x18, 2, -0x2d0),
                                    (call - 0x08, 3, -0x651)]:
        add, mov = ins[pointer_end], ins[pointer_end - 8]
        assert add['opcode'] == 0x07 and add['dst'] == reg and add['immediate'] == frame
        assert mov['opcode'] == 0xbf and mov['dst'] == reg and mov['src'] == 10

    headers = []
    for field, ctxoff, frame, original_off, value in [
        ('remaining_accounts.capacity', 0, -0x2d0, 0x4a38, 0),
        ('remaining_accounts.pointer', 8, -0x2c8, 0x4a30, 8),
        ('remaining_accounts.length', 16, -0x2c0, 0x4a28, 0),
        ('signer_seeds.pointer', 0x198, -0x138, 0x4a00, 'FP-0x4d0'),
        ('signer_seeds.length', 0x1a0, -0x130, 0x4a40, 1),
    ]:
        off = original_off + shift
        if isinstance(value, int):
            assert_store(ins, off, frame, value)
        else:
            assert_fp_pointer(ins, off, frame, -0x4d0)
        assert call not in reachable(edges, off), ('store does not dominate call', label, field)
        assert not direct_overwrites(ins, off, call, frame, 8)
        # All instructions after each header store through call are in one
        # straight-line block and perform no call/indirect memory mutation.
        for later, i in ins.items():
            if off < later < call:
                assert i['opcode'] & 7 not in (5, 6)
                assert i['opcode'] not in STORE_WIDTHS or i['dst'] == 10
        headers.append(dict(field=field, context_offset=hex(ctxoff), frame=hex(frame),
                            value=value, store=record(ins, off),
                            dominates_call=True, subsequent_direct_overwrites=[]))

    seeds = []
    seed_specs = [
        ('signers[0].pointer', -0x4d0, 8, 0x3cd8, 'FP-0x4b8'),
        ('signers[0].length', -0x4c8, 8, 0x3cf8, 3),
        ('seeds[0].pointer', -0x4b8, 8, 0x3cb8, 'VA0x1b68a2'),
        ('seeds[0].length', -0x4b0, 8, 0x3cf0, 14),
        ('seeds[1].pointer', -0x4a8, 8, 0x3ca0, 'FP-0x6c0'),
        ('seeds[1].length', -0x4a0, 8, 0x3ce8, 32),
        ('seeds[2].pointer', -0x498, 8, 0x3c88, 'FP-0x530'),
        ('seeds[2].length', -0x490, 8, 0x3ce0, 1),
        ('seeds[2].byte', -0x530, 1, 0x3cc0, 'incoming_ctx[0x27]'),
    ]
    for field, frame, width, original_off, value in seed_specs:
        off = original_off + seed_shift
        i = ins[off]
        if isinstance(value, int):
            assert_store(ins, off, frame, value)
        elif value.startswith('FP'):
            assert_fp_pointer(ins, off, frame, int(value[2:], 16))
        elif value.startswith('VA'):
            assert i['opcode'] == 0x7b and i['dst'] == 10 and i['displacement'] == frame
            ld = ins[off - 16]
            assert ld['opcode'] == 0x18 and ld['dst'] == i['src']
            assert int.from_bytes(bytes.fromhex(ld['raw'])[4:8], 'little') == 0x1b68a2
            assert bytes.fromhex(ld['raw'])[12:16] == bytes(4)
        else:
            assert i['opcode'] == 0x73 and i['dst'] == 10 and i['displacement'] == -0x530
            ld = ins[(0x3c70 if label == 'original' else 0x3c30)]
            assert ld['opcode'] == 0x71 and ld['displacement'] == 0x27 and ld['dst'] == i['src']
            ctx_load = ins[(0x3c68 if label == 'original' else 0x3c28)]
            ctx_frame = -0x938 if label == 'original' else -0x930
            assert ctx_load['opcode'] == 0x79 and ctx_load['src'] == 10 and ctx_load['displacement'] == ctx_frame
            initial = ins[0x20]
            assert initial['opcode'] == 0x7b and initial['dst'] == 10 and initial['src'] == 2 and initial['displacement'] == ctx_frame
        assert call not in reachable(edges, off), ('seed store does not dominate call', label, field)
        assert not direct_overwrites(ins, off, call, frame, width)
        seeds.append(dict(field=field, frame=hex(frame), width=width, value=value,
                          store=record(ins, off), dominates_call=True,
                          subsequent_direct_overwrites=[]))
    seed_start = min(int(i['store']['window_offset'], 16) for i in seeds)
    assert not any(seed_start < off < call and i['opcode'] in (0x85, 0x8d)
                   for off, i in ins.items())
    # Mint seed bytes: incoming Context.accounts -> AdminCto.mint -> key.
    mint_copy = [0x28, 0x30, 0x38, 0x40, 0x48, 0x50, 0x58, 0x60, 0x68, 0x70, 0x78]
    assert [ins[i]['raw'] for i in mint_copy] == [
        '7928080000000000', '7981100000000000', '7911000000000000',
        '7912180000000000', '7b2a58f900000000', '7912100000000000',
        '7b2a50f900000000', '7912080000000000', '7b2a48f900000000',
        '7911000000000000', '7b1a40f900000000']
    mint_stores = [(0x48, -0x6a8), (0x58, -0x6b0), (0x68, -0x6b8), (0x78, -0x6c0)]
    for off, frame in mint_stores:
        assert call not in reachable(edges, off)
        assert not direct_overwrites(ins, off, call, frame, 8)
    return dict(cto_sha256=sha(raw), logical_instructions=len(ins),
                cfg_reachable_instructions=len(reachable(edges)),
                call=record(ins, call), target=hex(CALLEE),
                context_pointer='FP-0x2d0', header_fields=headers,
                seed_descriptors=seeds,
                mint_seed_copy=[record(ins, off) for off in mint_copy],
                no_intervening_calls_from_seed_setup_to_sharing=True,
                alias_limit='Nested seed reaching-value proof excludes corruption or ill-typed external AccountInfo/Rc pointers aliasing this function frame. Header proof itself has only direct frame stores and no call or indirect write after each defining store.')


def consumption(raw):
    ins = instructions(raw)
    checks = [
        (0x0, 0x7b, 10, 2, -0xc0, 0, 'save incoming context'),
        (0x180, 0x79, 5, 10, -0xc0, 0, 'reload context for meta length'),
        (0x188, 0x79, 0, 5, 0x10, 0, 'read remaining_accounts length'),
        (0x198, 0x55, 0, 0, 0x3d, 0, 'nonempty meta branch to callee+0x388'),
        (0x460, 0x79, 1, 5, 8, 0, 'read remaining_accounts pointer'),
        (0x480, 0x07, 1, 0, 0, 0x29, 'source points to writable byte'),
        (0x4b0, 0x79, 4, 1, -0x29, 0, 'load remaining AccountInfo key pointer'),
        (0x4d8, 0x71, 8, 1, -1, 0, 'load remaining AccountInfo signer byte'),
        (0x4e0, 0x71, 9, 1, 0, 0, 'load remaining AccountInfo writable byte'),
        (0x518, 0x07, 1, 0, 0, 0x30, 'advance source AccountInfo by48'),
        (0x520, 0x07, 2, 0, 0, 0x22, 'advance destination AccountMeta by34'),
        (0x528, 0x07, 3, 0, 0, -1, 'decrement meta loop count'),
        (0x530, 0x15, 3, 0, 1, 0, 'exit meta loop at zero'),
        (0x538, 0x05, 0, 0, -0x12, 0, 'meta loop back edge'),
        (0x238, 0x79, 7, 10, -0xc0, 0, 'reload context for info construction'),
        (0x2f0, 0x79, 6, 7, 8, 0, 'read remaining AccountInfo pointer'),
        (0x2f8, 0x79, 7, 7, 0x10, 0, 'read remaining AccountInfo length'),
        (0x340, 0x15, 7, 0, 0x6e, 0, 'skip info clone loop at zero length'),
        (0x700, 0x7b, 10, 7, -0x98, 0, 'save remaining clone count'),
        (0x748, 0x79, 4, 4, 0, 0, 'load cloned AccountInfo key'),
        (0x750, 0x7b, 3, 5, 0, 0, 'increment cloned lamports Rc'),
        (0x5c8, 0x7b, 5, 0, 0, 0, 'increment cloned data Rc'),
        (0x690, 0x07, 2, 0, 0, 0x30, 'advance AccountInfo clone displacement by48'),
        (0x698, 0x07, 8, 0, 0, 1, 'increment output AccountInfo length'),
        (0x6a8, 0x07, 7, 0, 0, -1, 'decrement clone count'),
        (0x6b0, 0x55, 7, 0, 9, 0, 'clone loop back edge while nonzero'),
        (0x938, 0x79, 1, 3, 0x1a0, 0, 'read signer slice length'),
        (0x940, 0x79, 2, 3, 0x198, 0, 'read signer slice pointer'),
        (0x948, 0x7b, 10, 2, -0x1000, 0, 'stack argument signer pointer'),
        (0x950, 0x7b, 10, 1, -0xff8, 0, 'stack argument signer length'),
        (0xe48, 0x79, 3, 0, 0x10, 0, 'drop input remaining_accounts length'),
        (0xe50, 0x15, 3, 0, 7, 0, 'skip input element drops at zero'),
        (0xe60, 0x79, 4, 4, 8, 0, 'load pointer for input element drops'),
    ]
    records = []
    for off, op, dst, src, displacement, immediate, role in checks:
        i = ins[off]
        actual = tuple(i[k] for k in ('opcode', 'dst', 'src', 'displacement', 'immediate'))
        assert actual == (op, dst, src, displacement, immediate), (hex(off), role, actual)
        records.append(dict(role=role, **record(ins, off, CALLEE)))
    call_targets = []
    for off, target, role in [(0x178, 0x118360, 'fixed seven account metas'),
                               (0x2d0, 0xca628, 'fixed seven AccountInfos'),
                               (0x998, 0x1a0530, 'invoke_signed with signer slice stack pair')]:
        i = ins[off]
        assert i['opcode'] == 0x85 and i['src'] == 1
        assert CALLEE + off + 8 + i['immediate'] * 8 == target
        call_targets.append(dict(role=role, target=hex(target), **record(ins, off, CALLEE)))
    return dict(raw_checks=records, internal_calls=call_targets,
                both_frozen_callers_take_zero_length_remaining_account_edges=True,
                nonempty_meta_stride=34, nonempty_info_stride=48,
                signer_pair_forwarded_without_flattening=True,
                capacity_use='No capacity load found in manual review of full raw callee context-alias accesses; exact caller capacity store is nevertheless verified.')


def main():
    images, secs = {}, {}
    for label, (path, digest) in FILES.items():
        images[label] = (ROOT / path).read_bytes()
        assert sha(images[label]) == digest
        secs[label] = sections(images[label])
    symbols = function_symbols(images['faf'])
    assert len([s for s in symbols if s[0] == START and s[1] == SIZE and 'admin_cto7execute' in s[2]]) == 1
    callee_symbols = [s for s in symbols if s[0] == CALLEE and s[1] == CALLEE_SIZE]
    assert len(callee_symbols) == 1 and 'admin_cto_sharing_config' in callee_symbols[0][2]
    result = {}
    for label in FILES:
        full_text = body(images[label], secs[label], secs[label]['.text']['addr'], secs[label]['.text']['size'])
        boundaries = instruction_boundaries(full_text)
        relative = START - secs[label]['.text']['addr']
        assert relative in boundaries and relative + SIZE in boundaries
        result[label] = caller(label, body(images[label], secs[label], START, SIZE))
    callees = {label: body(images[label], secs[label], CALLEE, CALLEE_SIZE) for label in FILES}
    assert callees['original'] == callees['faf']
    assert sha(callees['faf']) == '29448eb927f43b914f919fa969440b2d7192b77a501548ee3f22da69ffe63833'
    # Bind downstream ABI forwarding helpers by actual frozen symbols/raw bytes.
    downstream = []
    for address, size in [(0x1a0530, 880), (0x1a1d70, 984)]:
        syms = [s for s in symbols if s[0] == address and s[1] == size]
        assert len(syms) == 1
        original = body(images['original'], secs['original'], address, size)
        candidate = body(images['faf'], secs['faf'], address, size)
        assert original == candidate
        downstream.append(dict(va=hex(address), bytes=size, symbol=syms[0][2],
                               sha256=sha(candidate), raw_equal=True))
    # The literal's section is resolved through the maintained section map.
    literal = None
    for section in secs['faf'].values():
        if section['addr'] <= 0x1b68a2 and 0x1b68a2 + 14 <= section['addr'] + section['size']:
            pos = section['offset'] + 0x1b68a2 - section['addr']
            literal = images['faf'][pos:pos + 14]
    assert literal == b'pool-authority'
    previous = (ROOT / 'work/trading/ORIGINAL-AGGREGATE.json').read_bytes()
    assert sha(previous) == '8adeef25887c3e5580f3cc53cd33bef66ed72ae3fd95a89d1b2db73622be251a'
    prior = json.loads(previous)
    assert prior['meaningful_account_fields_closed'] == 64
    assert len(prior['account_info_groups']) == 8
    assert all(len(group['fields']) == 8 for group in prior['account_info_groups'])
    result.update(source_base=BASE, status='FROZEN_FAF_HEADER_AGREEMENT_NO_RUST_PATCH',
                  context_bytes=424, account_info_extents_bytes=384,
                  account_info_meaningful_bytes=344, header_bytes=40,
                  cumulative_original_meaningful_fields=69,
                  cumulative_original_meaningful_bytes=384,
                  excluded_account_info_padding_bytes=40,
                  newly_compared_fields_both_callers=5,
                  prior_original_64_field_receipt_sha256=sha(previous),
                  callee=dict(va=hex(CALLEE), bytes=CALLEE_SIZE,
                              symbol=callee_symbols[0][2], sha256=sha(callees['faf']), raw_equal=True),
                  callee_consumption=consumption(callees['faf']),
                  downstream_raw_equal=downstream,
                  verifier_sha256=sha(Path(__file__).read_bytes()),
                  maintained_helpers={p: sha((ROOT / p).read_bytes()) for p in [
                      'reconstruction/harness/score.py',
                      'reconstruction/harness/instruction_stream.py',
                      'reconstruction/harness/elf_symbols.py']})
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
