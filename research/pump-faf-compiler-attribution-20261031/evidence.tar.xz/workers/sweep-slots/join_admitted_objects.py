"""Verify the root-admitted fixed FAF IR and selected alloca/frame joins."""
from pathlib import Path
import hashlib
import json
import re

WORK=Path(__file__).resolve().parent
ROOT=WORK.parent.parent
ART=ROOT/'work/ir-native-run/offline-extraction-v2'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def lines_with(lines, pattern):
    return [{'line':i+1,'text':s} for i,s in enumerate(lines) if re.search(pattern,s)]


def main():
    admission_path=ART/'CODE-IR-ADMISSION.json'
    admission=json.loads(admission_path.read_text())
    assert admission['codeIdentityQualified'] is True
    assert admission['sourceBase']=='faf99624250b4e60107790f7edabf6609f709885'
    assert admission['strippedSha256']=='d5cee214ba29be1a1ccbb96d036f3dd7dfbd683d61046d76b66103507d3ef750'
    irentry=admission['optimizedTarget']
    irbytes=Path(irentry['path']).read_bytes()
    assert sha(irbytes)==irentry['sha256'] and len(irbytes)==irentry['bytes']
    ir=irbytes.decode().splitlines()
    dumps=[]
    for entry in admission['machineFunctions']:
        data=Path(entry['path']).read_bytes()
        assert sha(data)==entry['sha256'] and len(data)==entry['bytes']
        dumps.append(data.decode().splitlines())
    assert len(dumps)==5
    # Stable SSA machine definitions directly show frame coloring between snapshots.
    spec=[
        ('hk',33,141,141,-1657,426),
        ('holder_key',32,142,142,-1696,902),
        ('_5.i',32,32,21,-720,898),
        ('_7.i',33,30,21,-720,904),
        ('_10.i123',32,29,36,-1104,905),
        ('dest.i',32,31,47,-1304,918),
        ('_14.i',32,28,21,-720,917),
        ('_17.i',160,27,21,-720,936),
        ('_24.i121',64,25,21,-720,949),
        ('_31.i',16,24,21,-720,958),
        ('_37.i',16,23,21,-720,961),
        ('_42.i',160,22,21,-720,963),
    ]
    objects=[]
    for name,size,fi,merged,offset,vreg in spec:
        decl=lines_with(ir,r'^  %'+re.escape(name)+r' = alloca \['+str(size)+r' x i8\]')
        assert len(decl)==1,(name,decl)
        lifetimes=lines_with(ir,r'@llvm\.lifetime\.(?:start|end)\.p0\(i64 '+str(size)+r', ptr nonnull %'+re.escape(name)+r'\)')
        assert any('lifetime.start' in x['text'] for x in lifetimes)
        assert any('lifetime.end' in x['text'] for x in lifetimes)
        original=lines_with(dumps[0],r'^\s*%'+str(vreg)+r':gpr = .*%stack\.'+str(fi)+r'\b')
        colored=lines_with(dumps[1],r'\s%'+str(vreg)+r':gpr = .*%stack\.'+str(merged)+r'\b')
        assert len(original)==len(colored)==1,(name,original,colored)
        final=lines_with(dumps[4],r'^  fi#'+str(merged)+r': size=\d+, align=\d+, at location \[SP'+str(offset)+r'\]$')
        assert len(final)==1,(name,final)
        frames=[]
        for stage,lines in enumerate(dumps):
            rows=lines_with(lines,r'^  fi#(?:'+str(fi)+'|'+str(merged)+r'):')
            frames.append({'stage':admission['machineFunctions'][stage]['pass'],
                           'timing':admission['machineFunctions'][stage]['timing'],'rows':rows})
        objects.append({'alloca':'%'+name,'bytes':size,'declaration':decl[0],
                        'lifetimes':lifetimes,'finalizeFi':fi,'coloredFi':merged,
                        'machineVregWitness':vreg,'finalizeWitness':original[0],
                        'beforeGreedyWitness':colored[0],'finalFrame':final[0],
                        'finalFpOffset':offset,'frameSnapshots':frames})
    hk_use=lines_with(ir,r'@llvm\.memcpy.*dereferenceable\(7\) %hk, i64 7, i1 false\)')
    assert len(hk_use)==1
    final_hk_reads=lines_with(dumps[4],r'LDW_V1 \$r10, -165[47] :: .*%ir\.hk')
    assert len(final_hk_reads)==2
    returns=[]
    for fi,offset in [(160,-1984),(161,-2000),(162,-2016)]:
        rows=lines_with(dumps[4],r'^  fi#'+str(fi)+r': size=16, align=8, at location \[SP'+str(offset)+r'\]$')
        assert len(rows)==1
        returns.append({'fi':fi,'offset':offset,'frame':rows[0],
                        'optimizedAlloca':False,
                        'scope':'ABI lowering of a {i64,ptr} SSA call return; not an identified Rust local.'})
    prior=json.loads((WORK/'PR3140-live.json').read_text())['structuredContent']['pull_request']
    assert prior['head_sha']=='90d5b39035456305644534ebfe8c173272baf504'
    assert 'a scoped `hk`' in prior['diff']
    assert 'holder arm reads `holder_key` instead of `hk`' in prior['diff']
    result={'schema':'faf-actual-ir-sweep-alloca-frame-join-v1',
            'admissionPath':str(admission_path.relative_to(ROOT)),
            'admissionSha256':sha(admission_path.read_bytes()),
            'admissionScope':admission['offlineAttributionScope'],
            'preservedNativeOutcome':admission['preservedNativeOutcome'],
            'target':irentry,'machineInputs':admission['machineFunctions'],
            'objects':objects,'hkForwardedSevenByteUse':hk_use[0],
            'hkFinalMachineReads':final_hk_reads,'abiReturnObjects':returns,
            'knownness':{'pr':3140,'head':prior['head_sha'],
                         'url':prior['url'],'sha256':sha((WORK/'PR3140-live.json').read_bytes()),
                         'status':'Same hk7 forwarding and immediately shortened hk lifetime already studied; scoped hk explicitly included in exhausted plain-PDA family.'},
            'limits':['Current optimized IR does not establish original LLVM alloca identities.',
                      'No source edit or compiler/VM/variant invocation; no score or equality gain claimed.'],
            'producerSha256':sha(Path(__file__).read_bytes())}
    out=WORK/'ir-join'
    out.mkdir(exist_ok=True)
    (out/'JOIN-VERIFIED.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'objects':len(objects),'stages':len(dumps),
                      'hkForwardedUseLine':hk_use[0]['line'],'scopedHkKnownNegative':True}))


if __name__=='__main__':
    main()
