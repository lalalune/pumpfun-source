# Actual frozen FAF event / bump join

Scope: root's `offline-extraction-v2/CODE-IR-ADMISSION.json` admits the actual
run41148994357 executable/data and IR join. The strict native run remains
FAILURE. All six inspected IR/machine files match their admitted hashes.
`ACTUAL-IR-JOIN.json` records exact lines and the verifier is
`PYTHONDONTWRITEBYTECODE=1 python3 -B work/event-slots/join_actual_ir.py`.

## Event object is already correct

`admin-cto.ll:123` allocates `%e` as200 bytes, alignment8. Its lifetime starts
at3665 and ends at3883(success)/3972(error). Sharing context `%_120` ends3567;
pool context `%_195` ends3659. Thus the actual LLVM lifetimes already separate
both prior424-byte contexts from `%e`. The same `%e` operand is passed to both
Event::data calls3715/3733, with all13 field stores/copies before3715 and no
intervening event mutation. Semantic field bytes remain0..195 inclusive; the
candidate alloca also has4 trailing padding bytes.

Finalize-isel has `fi120.e` size200 and lifetime pseudos at5701,5992,6077.
Before greedy, it has already been colored into `fi21._54.i` size664, along
with both prior CPI contexts. Final frame records place fi21 at SP-720
(`FP-2d0`), agreeing with both original and admitted baseline raw bytes.
This supplies no missing event scope/lifetime correction.

## Exact bump / clone allocation exchange

LLVM `%authority_info` is48 bytes (`ll:119`). Clone3729 writes it;
AccountMeta construction reads its key3762; memcpy3777 copies48 bytes into the
one-element account-info array. This stack descriptor has no explicit lifetime
intrinsics in this optimized target. That absence does not establish a source
mistake or an original-image lifetime; the final clone descriptor occupies
`FP-610` in both images.

The clone address is pre-greedy `v1398`: one def68400B and two uses68416B and
69520B. It becomes `r6` in virtregrewriter, killed at the latter memcpy argument.
The bump is LLVM `%authority_bump`, one load of`ctx+46` at3731 and one use at
seed-byte store3781. Pre-greedy `v1399` has def68480B/use69680B. Greedy splits
it into the load `%2239`, spill68488B to fi346, reload69672B `%2240`, and seed
store69680B. After spill-slot coloring, fi346 is dead and final fi178 is at
SP-2264 (`FP-8d8`), matching the admitted ELF's bump spill/reload.

Five values overlap immediately after slot69296B and before69376B/69392B:

| Value | Pre-greedy def → final use | Final allocation |
|---|---|---|
| clone address v1398 |68400B→69520B|r6|
| bump v1399 |68480B→69680B|spill FP-8d8|
| bytes pointer v1409 |68928B→69376B|r8|
| bytes length v1410 |68944B→69392B|r9|
| Instruction address v1418 |69296B→69872B|r7|

The Instruction address is materialized before the bytes pointer/length are
copied into call arguments. The original raw code retains bump inr6 and spills
the clone address to FP-8d8 instead. Actual dumps establish the candidate's
choice and overlap; they do not print spill weights, actual LiveIntervals or
allocator priority/eviction traces. No claim that this overlap uniquely forces
the observed spill, or that changing source spelling fixes it, follows.

## Source cause and transferability

There is no extra bump use, repeated clone-pointer use, missing event field or
misplaced event lifetime here. No genuinely new event/bump/clone Rust correction
is justified. Reopening old macro, clone literal or signer declaration spelling
would be unsupported by this evidence.

Frozen FAF does have `%nf` loaded at ll3583 before pool-CPI selection and stored
into event+176 at3703. Its pre-greedy v363 spans64720B→67888B across pool CPI.
Original instead loads that fee from the curve during event construction. This
is a concrete upstream used-origin/lifetime distinction, already in the known
family and, per root, addressed on latest main by #3315. That change can alter
global register allocation, so the frozen tail allocation choice must not be
asserted for latest main or used to justify replaying the same correction.
The alloca/call-operand join method transfers; these exact SSA IDs, live spans
and spill decisions do not establish latest-main state.

No build, compiler/SDK/VM execution, source edit, binary edit, matcher change or
public action was performed in this lane.
