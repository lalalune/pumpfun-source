"""Admit only the explicitly authorized missing original SDK linker wrapper and parent dir."""
from pathlib import Path
import hashlib,json,tarfile,os,stat
R=Path(__file__).resolve().parent;Q=R.parent/'relay-sdk-v148-quarantine-20261030';S=R.parent/'relay-sdk-v148-staged-20261030';sdk=S/'sdk'
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
n='rust/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld';parent=str(Path(n).parent);archive=next(Q.glob('*.tar.bz2'));assert digest(archive)=='a9d3157f937d5f6faf4321a35a8035e0f827114a663b0150db492e893ec27597'
inv={r['path']:r for r in json.loads((Q/'TAR-INVENTORY.json').read_text())};hashes={r['path']:r for r in json.loads((Q/'SDK-MEMBER-HASHES.json').read_text())};assert inv[n]['size']==408048 and hashes[n]['sha256']=='2aea8cee216207f00db286bde7131decdf6016da14e8b30ea1bcdaacd71dc136'and inv[parent]['type']=='dir'
assert not(sdk/parent).exists()and not(sdk/n).exists()
data=None
with tarfile.open(archive,'r|bz2')as tar:
 for m in tar:
  if m.name==n:
   assert m.isfile()and m.size==408048 and oct(m.mode)==inv[n]['mode'];data=tar.extractfile(m).read();break
assert data is not None and len(data)==408048 and sha(data)==hashes[n]['sha256']
(sdk/parent).mkdir();(sdk/parent).chmod(int(inv[parent]['mode'],8))
with(sdk/n).open('xb')as f:f.write(data)
(sdk/n).chmod(int(inv[n]['mode'],8));assert digest(sdk/n)==hashes[n]['sha256']
old_path=Q/'REQUIRED-SDK-CLOSURE.json';old=json.loads(old_path.read_text());new={**old};new['scope']='Corrected selected SDK closure: one authenticated compiler-discovered native linker wrapper added after actual first-attempt lookup failure. No compiler flags/source/layout change.'
added=[{**inv[parent],'roles':['original parent metadata for authorized host linker wrapper']},{**inv[n],'sha256':hashes[n]['sha256'],'roles':['actual rustc host self-contained-linker discovery, observed missing in attempt1']}]
new['files']=sorted(old['files']+added,key=lambda r:r['path']);new['regularFiles']=971;new['regularPayloadBytes']=old['regularPayloadBytes']+408048;new['regularBlocks4096Bytes']=old['regularBlocks4096Bytes']+409600;new['blocksAfterOptionalOwnedHardlinkDedup']=old['blocksAfterOptionalOwnedHardlinkDedup']+409600
new['correction']={'oldClosureSHA256':digest(old_path),'exactAddedPath':n,'exactAddedParent':parent,'attempt1FailureReceipt':'native-build-20261030/BUILD-FAILURE-ATTRIBUTION.json','attempt1FailureReceiptSHA256':digest(S/'native-build-20261030/BUILD-FAILURE-ATTRIBUTION.json'),'otherOriginalSDKMemberChanges':False,'newCompilerOptionsOrSourceVariant':False}
# Existing ELF metadata/host version providers already cover all wrapper dependencies.
metadata=json.loads((Q/'SDK-ELF-METADATA.json').read_text())[n]
for need in metadata['versionNeeds']:
 providers=[v for v in old['nativeRuntimeLibraries'].values()if Path(v['path']).name.startswith(need['library'].split('.so')[0])]
 if need['library']=='ld-linux-x86-64.so.2':providers=[v for v in old['nativeRuntimeLibraries'].values()if'ld-linux'in v['path']]
 available=set(x for p in providers for x in p['providedVersions']);assert set(need['versions'])<=available
new['correctedToolMetadata']=metadata
files=[];dirs=[]
for row in new['files']:
 p=sdk/row['path']
 if row['type']=='file':
  assert p.is_file()and not p.is_symlink()and p.stat().st_size==row['size']and digest(p)==row['sha256']and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8)&0o7777
  files.append({'path':row['path'],'type':'file','bytes':row['size'],'sha256':row['sha256'],'mode':row['mode']})
 elif row['type']=='symlink':
  assert p.is_symlink()and os.readlink(p)==row['linkTarget']and p.resolve().is_relative_to(sdk.resolve())and p.resolve().is_file();files.append({'path':row['path'],'type':'symlink','linkTarget':row['linkTarget']})
 else:assert p.is_dir()and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8)&0o7777
for p in [sdk]+[p for p in sdk.rglob('*')if p.is_dir()and not p.is_symlink()]:
 relative=p.relative_to(sdk).as_posix();assert inv[relative]['type']=='dir'and stat.S_IMODE(p.stat().st_mode)==int(inv[relative]['mode'],8)&0o7777;dirs.append({'path':relative,'mode':inv[relative]['mode']})
assert {p.relative_to(sdk).as_posix()for p in sdk.rglob('*')if p.is_file()or p.is_symlink()}=={r['path']for r in files}
critical=json.loads((R/'compiler-tools.json').read_text());checked=[]
for name,row in critical.items():
 if '/sbf-solana-solana/'in name:continue
 assert digest(sdk/name)==row['sha256'];checked.append(name)
out=S/'REQUIRED-SDK-CLOSURE-WITH-HOST-LINKER.json';out.write_text(json.dumps(new,indent=2)+'\n')
record={'status':'ONLY_AUTHORIZED_HOST_LINKER_MEMBER_ADDED_FULL_SDK_REVERIFIED','archiveSHA256':digest(archive),'regularFiles':971,'originalAliases':7,'regularBytes':new['regularPayloadBytes'],'files':files,'allDirectories':dirs,'requiredCriticalReverified':checked,'unusedLegacyCritical25ArchiveOnly':True,'correctedClosureSHA256':digest(out),'added':added,'prior693f3913AndAttempt1Preserved':True,'compilerExecutionsByThisCorrection':0,'rootRelease':'one bounded infrastructure correction plus retry of same source variant; no automatic third attempt','producerSHA256':digest(Path(__file__)),'freeBytesAfter':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize}
p=S/'SDK-HOST-LINKER-CORRECTION.json';p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items()if k not in ['files','allDirectories','added','requiredCriticalReverified']},indent=2));print('correction SHA256',digest(p),flush=True)
