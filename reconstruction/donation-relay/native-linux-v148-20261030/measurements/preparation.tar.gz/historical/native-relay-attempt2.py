"""One released native Relay control. Exact logical recipe; monitored fresh target, no variants."""
from pathlib import Path
import hashlib,json,os,signal,stat,subprocess,sys,time,tarfile,tomllib,shutil
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];R=ROOT/'work/relay-public-history';S=ROOT/'work/relay-sdk-v148-staged-20261030';Q=ROOT/'work/relay-sdk-v148-quarantine-20261030'
A=S/'native-build-attempt2-20261030';A.mkdir(exist_ok=False);target=A/'target';output=A/'output'
target.mkdir();output.mkdir();(output/'home').mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(p):
    h=hashlib.sha256()
    with p.open('rb')as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()
def save(name,data):(A/name).write_text(json.dumps(data,indent=2)+'\n')
free=lambda:os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize
seal=S/'STAGED-CLOSURE-ATTEMPT2.json';assert digest(seal)=='20d0e877d1211cfcb30d02393b8cdc933ef73241dca73ef7a5f8392485843c49'
ident=S/'tool-identification/IDENTIFICATION-REVIEW.json';assert digest(ident)=='6e95912771b9d1261c2844803820092ba1e3eb09d4dd05bcbb9991ab569f8ad9'
plan=json.loads(seal.read_text());launch=json.loads((R/'canonical-launch.json').read_text());closure=json.loads((S/'REQUIRED-SDK-CLOSURE-WITH-HOST-LINKER.json').read_text());admission=json.loads((S/'REGISTRY-ADMISSION.json').read_text());vector=json.loads((S/'REGISTRY-SOURCE-VECTOR.json').read_text());host=json.loads((Q/'NATIVE-HOST-INPUTS-COMPLETE.json').read_text());aliases=json.loads((S/'HOST-ALIASES.json').read_text())
registry=S/'cargo-home/registry';index='index.crates.io-6f17d22bba15001f';source=R/'current-source'
locked=[p for p in tomllib.loads((source/'Cargo.lock').read_text())['package']if p.get('source','').startswith('registry+')]
def verify_inputs():
    source_hashes={p.relative_to(source).as_posix():digest(p)for p in source.rglob('*')if p.is_file()}
    assert source_hashes==launch['source_inputs']and len(source_hashes)==60
    for row in json.loads((R/'CURRENT-60-AUDIT.json').read_text())['sourceInputs']:
        assert stat.S_IMODE((source/row['path']).stat().st_mode)==int(row['mode'],8)&0o7777
    config={p.name:digest(p)for p in (R/'canonical-config').iterdir()};assert config==launch['config_inputs']
    sdk_files=[]
    for row in closure['files']:
        p=S/'sdk'/row['path']
        if row['type']=='file':
            assert p.is_file()and not p.is_symlink()and p.stat().st_size==row['size']and digest(p)==row['sha256']
            assert stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8)&0o7777;sdk_files.append(row['path'])
        elif row['type']=='symlink':assert p.is_symlink()and os.readlink(p)==row['linkTarget'];sdk_files.append(row['path'])
        else:assert p.is_dir()and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8)&0o7777
    assert set(sdk_files)=={p.relative_to(S/'sdk').as_posix()for p in (S/'sdk').rglob('*')if p.is_file()or p.is_symlink()}
    # Same archive/source equality algorithm as authenticated b907be1a canonical check;
    # only physical source/cache roots are adapted to the owned authenticated registry.
    rows=[]
    for p in locked:
        name=p['name']+'-'+p['version'];archive=registry/'cache'/index/(name+'.crate');src=registry/'src'/index/name
        assert digest(archive)==p['checksum'];count=0
        with tarfile.open(archive,'r:gz')as tar:
            for member in tar.getmembers():
                if not member.isfile():continue
                path=Path(member.name);assert path.parts[0]==name and '..'not in path.parts
                relative=Path(*path.parts[1:]);data=tar.extractfile(member).read();assert(src/relative).is_file()and(src/relative).read_bytes()==data
                count+=1
        rows.append({'name':name,'checksum':p['checksum'],'files':count})
    canonical=json.loads((S/'CANONICAL-REGISTRY-CHECK.json').read_text());assert rows==canonical['rows']and sum(r['files']for r in rows)==7968
    for row in vector:
        p=registry/'src'/index/row['package']/row['path'];assert digest(p)==row['sha256']and stat.S_IMODE(p.stat().st_mode)==int(row['mode'],8)&0o7777
    for row in admission['sourceRows']:
        p=registry/'src'/index/row['package'];assert digest(p/'.cargo-checksum.json')==row['generatedCargoChecksumSHA256']and digest(p/'.cargo-ok')==row['generatedCargoMarkerSHA256']
    for row in admission['indexMetadata']['entries']:assert digest(registry/'index'/index/'.cache'/row['relative'])==row['sha256']
    assert digest(registry/'index'/index/'config.json')==admission['indexMetadata']['configSHA256']
    for collection in [host['executablesAndRuntimeClosure'].values(),host['seedAliases'],host['linkerCrtAndStaticInputs'],host['conservativeHostHeaderInputs'],closure['nativeRuntimeLibraries'].values()]:
        for row in collection:assert digest(Path(row['path']))==row['sha256']
    for row in aliases['aliases']:
        assert os.readlink(Path(row['logicalPath']))==row['linkTarget']and digest(Path(row['logicalPath']))==row['resolvedSHA256']
    assert digest(Path(aliases['loaderCache']['path']))==aliases['loaderCache']['sha256']
    return {'sourceHashes':source_hashes,'configHashes':config,'sdkRegularFiles':971,'sdkOriginalAliases':7,'registryPackages':len(rows),'registryMembers':7968,'canonicalRegistryRowsExact':True,'registrySourceVectorSHA256':digest(S/'REGISTRY-SOURCE-VECTOR.json'),'registryAdmissionSHA256':digest(S/'REGISTRY-ADMISSION.json'),'hostManifestSHA256':digest(Q/'NATIVE-HOST-INPUTS-COMPLETE.json'),'sourceClosureSHA256':digest(seal),'identificationSHA256':digest(ident),'controllerSHA256':digest(Path(__file__))}

before=verify_inputs();save('INPUTS-BEFORE.json',before)
assert not any(target.iterdir())and free()>128*1024*1024
probe=json.loads((S/'STAGED-CONTEXT-PROBE.json').read_text());prefix=probe['command'][:probe['command'].index('--')+1]
def replace_tmpfs(args,logical,physical):
    i=next(i for i in range(len(args)-1)if args[i:i+2]==['--tmpfs',logical]);return args[:i]+['--bind',str(physical),logical]+args[i+2:]
prefix=replace_tmpfs(prefix,'/target',target);prefix=replace_tmpfs(prefix,'/output',output)
# /output/home was created on the fresh owned output; remove only duplicate setup directive.
i=prefix.index('--dir',prefix.index(str(output)))if '--dir'in prefix[prefix.index(str(output)):]else-1
if i>=0 and prefix[i:i+2]==['--dir','/output/home']:prefix=prefix[:i]+prefix[i+2:]
environment=['/usr/bin/env','-i']+[k+'='+v for k,v in plan['canonicalEnvironment'].items()]
cargo_argv=plan['canonicalCargoArgv'];cmd=prefix+environment+cargo_argv
start_wall=time.time();save('LAUNCH.json',{'controllerSHA256':digest(Path(__file__)),'command':cmd,'canonicalCargoArgv':cargo_argv,'canonicalEnvironment':plan['canonicalEnvironment'],'freshTarget':str(target),'output':str(output),'capturedOrExpectedElfsMounted':False,'timeoutSeconds':1800,'freeFloorBytes':128*1024*1024,'sourceClosureSHA256':digest(seal),'identificationReference':str(ident),'transportChanges':['podman c9bcc container replaced by disclosed native Linux bwrap transport','exact current native cc/c++ aliases and system host files explicitly sealed','logical source/config/sdk/registry/env/argv/linker layout remain unchanged'],'expectedOutputSHA256':plan['expectedActualOutputHardGate']})

def monitored(argv,phase,timeout):
    floor=128*1024*1024;begin=time.monotonic();lowest=free();reason=None;last=-1
    with(A/(phase+'.log')).open('wb')as log,(A/(phase+'-resources.jsonl')).open('w')as samples:
        process=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        save(phase+'-PROCESS.json',{'pid':process.pid,'pgid':process.pid,'argv':argv,'startedUnix':time.time()})
        while process.poll()is None:
            elapsed=time.monotonic()-begin;available=free();lowest=min(lowest,available)
            if int(elapsed)!=last:
                samples.write(json.dumps({'seconds':elapsed,'freeBytes':available,'pid':process.pid})+'\n');samples.flush();last=int(elapsed)
            if available<floor:reason='HOST_DISK_FLOOR_128_MIB';break
            if elapsed>timeout:reason='TIMEOUT_'+str(timeout)+'_SECONDS';break
            time.sleep(.1)
        if reason:
            try:os.killpg(process.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                process.wait()
        else:process.wait()
        final_free=free();lowest=min(lowest,final_free)
        if final_free<floor and reason is None:reason='HOST_DISK_FLOOR_128_MIB_AFTER_EXIT'
    group_left=False
    try:os.killpg(process.pid,0);group_left=True
    except ProcessLookupError:pass
    if group_left:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        if reason is None:reason='OWNED_PROCESS_GROUP_REMAINED_AFTER_LEADER_EXIT'
    return {'ownedProcessGroupRemainedAfterLeaderExit':group_left,'returncode':process.returncode,'seconds':time.monotonic()-begin,'guardFired':reason,'lowestFreeBytes':lowest,'freeBytesAfter':final_free,'logSHA256':digest(A/(phase+'.log'))}

result={'attemptOrdinal':2,'priorFailedAttempt':'native-build-20261030/BUILD-FAILURE-ATTRIBUTION.json','scope':'ONE fresh same-source native Relay retry, only authenticated missing original host linker added; unchanged flags/wrapper/layout. No variants.','cargoBuildAttempts':1,'identificationExecutionsBeforeBuild':4,'build':monitored(cmd,'build',1800),'startedUnix':start_wall}
save('RESULT.json',result)
try:
    after=verify_inputs();save('INPUTS-AFTER-BUILD.json',after);result['inputsUnchangedAfterBuild']=before==after
    assert result['inputsUnchangedAfterBuild']
    if result['build']['returncode']==0 and result['build']['guardFired']is None:
        log=(A/'build.log').read_bytes();result['rootCompilerInvocations']=log.count(b'--crate-name donation_relay_source_proposal ');result['errorModelCompilerInvocations']=log.count(b'--crate-name relay_error_model_reconstructed ')
        assert result['rootCompilerInvocations']==1 and result['errorModelCompilerInvocations']==1
        actual=target/'sbpf-solana-solana/release/donation_relay_source_proposal.so';assert actual.is_file();shutil.copyfile(actual,output/'symbols.so')
        strip_argv=plan['postLink']['argv'];result['strip']=monitored(prefix+environment+strip_argv,'strip',60)
        assert result['strip']['returncode']==0 and result['strip']['guardFired']is None
        result['artifacts']={name:{'bytes':(output/name).stat().st_size,'sha256':digest(output/name)}for name in ['symbols.so','candidate.so']}
        result['bothExpectedRawHashesEqual']=result['artifacts']['symbols.so']['sha256']==plan['expectedActualOutputHardGate']['symbolsSHA256']and result['artifacts']['candidate.so']['sha256']==plan['expectedActualOutputHardGate']['strippedSHA256']
        # Comparison is host-side ONLY AFTER build+strip; no original bytes enter namespace.
        sys.path.insert(0,str(ROOT/'work/current-required-gates/scripts'));import analyze
        capture=ROOT/'work/current-required-gates/evidence/dependencies/donation_relay/deployed.so';original=capture.read_bytes();candidate=(output/'candidate.so').read_bytes();layout=analyze.elf_layout(original);extent=layout['elf_extent']
        assert sha(original)=='367f07a62e3f74d358187d175cf3228848e81a56c781a9a75b9df7fed1268563'
        mismatches=[i for i,(a,b)in enumerate(zip(original[:extent],candidate))if a!=b]
        result['captureComparison']={'captureSHA256':sha(original),'captureBytes':len(original),'actualCandidateSHA256':sha(candidate),'actualCandidateBytes':len(candidate),'meaningfulElfExtent':extent,'literalDifferentOverlappingMeaningfulBytes':len(mismatches),'firstDifferentOffsets':mismatches[:32],'meaningfulLengthEqual':len(candidate)==extent,'allMeaningfulElfBytesLiteralEqual':len(candidate)==extent and not mismatches,'wholeCapturedPayloadEqualsCompilerFile':candidate==original,'captureAllocationSuffixBytes':len(original)-extent,'captureAllocationSuffixAllZero':not any(original[extent:]),'analyzerSHA256':digest(Path(analyze.__file__)),'originalMountedOrCompilerInput':False,'noOutputPaddingPatchingOrOriginalCodeCopy':True}
        final=verify_inputs();save('INPUTS-AFTER-STRIP.json',final);result['inputsUnchangedAfterStrip']=before==final
        result['acceptedColdReproduction']=bool(result['bothExpectedRawHashesEqual']and result['captureComparison']['allMeaningfulElfBytesLiteralEqual']and result['inputsUnchangedAfterStrip']and not result['build']['guardFired']and not result['strip']['guardFired'])
    else:result['acceptedColdReproduction']=False
except BaseException as error:
    result['qualificationFailure']={'type':type(error).__name__,'message':str(error)};result['acceptedColdReproduction']=False;save('RESULT.json',result);raise
finally:
    result['finishedUnix']=time.time();result['freeBytesAtFinish']=free();save('RESULT.json',result)
print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if result.get('acceptedColdReproduction') else 1)
