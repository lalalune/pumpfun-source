"""Root-owned one-shot checks of the genuine 858cd consumer packet."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

ROOT = Path('/dev/shm/pump-cto-consumer-publication')
PREP = ROOT / 'work/revision-2-preparation'
OUT = ROOT / 'work/final-checks-v2'
LANE = 'reconstruction/pump-main/lanes/original-creator-consumers-20261031'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def snapshot(prepared):
    records = {}
    local = prepared['local']['files']
    external = prepared['external']
    for kind, row in [('local', r) for r in local] + [('external', external['python'])] + [('external', r) for r in external['qualified_runtime_files']]:
        path = ROOT / row['path'] if kind == 'local' else Path(row['path'])
        info = path.lstat()
        if kind == 'local' and row['git_mode'] == '120000':
            assert path.is_symlink()
            data = os.fsencode(os.readlink(path))
        else:
            assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
            data = path.read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], str(path)
        assert info.st_mode == row['physical_mode'], str(path)
        assert info.st_dev == row['device'] and info.st_ino == row['inode'] and info.st_mtime_ns == row['mtime_ns'], str(path)
        if kind == 'local':
            assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob']
        records[str(path)] = dict(bytes=len(data), sha256=sha(data), mode=info.st_mode, device=info.st_dev, inode=info.st_ino, mtime_ns=info.st_mtime_ns)
    assert len(local) == 365 and len(records) == 370
    return records


def main():
    assert sys.dont_write_bytecode and sys.flags.optimize == 0 and os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
    assert not OUT.exists(), 'Never rerun or overwrite these checks'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == '07f2430f112c3ed97bb44cc92fb591cc6f953f48'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT).decode().strip() == '9f38b5bfb339a4a3446d8fd4535680594321ad94'
    assert sha((ROOT / 'work/preparation/PREPARATION-FREEZE.json').read_bytes()) == '486e158f0035829dbec847fb4a07de9290bc2126ef56afa67a31d93429198fb8'
    # Previous independent preparation review retained; corrective delta reviewed by root.
    assert sha((ROOT / LANE / 'verify.py').read_bytes()) == '72205e242e9ea28d48ca7f6da6b2efb052e50390cb8d830da6168ab15da30a11'
    assert sha((ROOT / LANE / 'queries.json').read_bytes()) == '527bd086508ea5fda0a595c1014f1bea836db712427adb10de6f1acc8bbb186e'
    assert sha((ROOT / LANE / 'inputs.json').read_bytes()) == '1706472e074420c43aeef24c79c84d3af621084a54ad5044172ffc528a598a3d'
    prepared_path = PREP / 'INPUTS-PREPARED.json'
    assert sha(prepared_path.read_bytes()) == '1bf4a8391dbf4b29ba6bb13f741c2e3d3d876a5c9522e9c80703bb63003ce784'
    prepared = json.loads(prepared_path.read_text())
    OUT.mkdir()
    temporary = Path('/dev/shm/cto-consumer-check-tmp')
    temporary.mkdir(exist_ok=True)
    env = dict(os.environ)
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONOPTIMIZE', None)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['TMPDIR'] = str(temporary)
    commands = [
        ('portable', [sys.executable, '-B', LANE + '/verify.py', '--repo', str(ROOT)]),
        ('evidence', [sys.executable, '-B', 'scripts/verify_evidence.py']),
        ('tooling', [sys.executable, '-B', 'scripts/test_tooling.py']),
    ]
    receipts = []
    for name, argv in commands:
        destination = OUT / name
        destination.mkdir()
        before = snapshot(prepared)
        save(destination / 'INPUTS-BEFORE.json', before)
        started = now()
        save(destination / 'STARTED.json', dict(argv=argv, cwd=str(ROOT), startUtc=started, once=True))
        clock = time.monotonic()
        with (destination / 'stdout').open('wb') as stdout, (destination / 'stderr').open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
            save(destination / 'PROCESS.json', dict(pid=process.pid, argv=argv, cwd=str(ROOT), startUtc=started, environment={k: env.get(k) for k in ('PYTHONDONTWRITEBYTECODE', 'TMPDIR', 'PYTHONPATH', 'PYTHONOPTIMIZE')}))
            exit_code = process.wait()
        after = snapshot(prepared)
        save(destination / 'INPUTS-AFTER.json', after)
        assert before == after
        receipt = dict(name=name, argv=argv, pid=process.pid, startUtc=started, endUtc=now(), elapsedSeconds=time.monotonic()-clock, exitCode=exit_code, inputsUnchanged=True, localInputs=365, externalInputs=5, files={n: dict(bytes=(destination/n).stat().st_size, sha256=sha((destination/n).read_bytes())) for n in ('stdout', 'stderr')})
        save(destination / 'RESULT.json', receipt)
        receipts.append(receipt)
        print(json.dumps(receipt), flush=True)
        if exit_code:
            save(OUT / 'STOPPED.json', dict(command=name, results=receipts, reason='First actual failure retained; no automatic rerun or later command'))
            return 1
    save(OUT / 'RECEIPT.json', dict(commit=prepared['commit'], tree=prepared['tree'], packetLane=LANE, checks=receipts, sourceProgramChanges=0, limits='Finite original-only replay and required tooling/evidence checks; no source gain or S4/H1 candidate runtime claim'))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
