import io
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from build_process import run_compiler
import fastbuild


class CompilerDeadlineTests(unittest.TestCase):
    def run_python(self, code, **kwargs):
        return run_compiler([sys.executable, '-u', '-c', code], **kwargs)

    def background_writer_trial(self, status, timeout):
        """A redirected descendant must not write after the runner returns."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            ready, release, marker, pids = (root / name for name in
                                          ('ready', 'release', 'late-output', 'pids'))
            child = (
                'import os,time\nfrom pathlib import Path\n'
                f'Path({str(ready)!r}).write_text(str(os.getpgrp()))\n'
                f'gate=Path({str(release)!r})\n'
                'deadline=time.monotonic()+10\n'
                'while not gate.exists() and time.monotonic()<deadline: time.sleep(0.01)\n'
                f'if gate.exists(): Path({str(marker)!r}).write_text("late write")\n'
            )
            leader = (
                'import json,os,subprocess,sys,time\nfrom pathlib import Path\n'
                f'child=subprocess.Popen([sys.executable,"-c",{child!r}],'
                'stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\n'
                f'Path({str(pids)!r}).write_text(json.dumps([os.getpid(),child.pid]))\n'
                'deadline=time.monotonic()+2\n'
                f'while not Path({str(ready)!r}).exists() and time.monotonic()<deadline: time.sleep(0.01)\n'
                'print("leader diagnostic",flush=True)\n'
                f'sys.exit({status})\n'
            )
            try:
                result, expired = self.run_python(leader, timeout=timeout)
                leader_pid, _ = json.loads(pids.read_text())
                self.assertTrue(ready.exists(), 'descendant never became ready')
                self.assertEqual(int(ready.read_text()), leader_pid)
                self.assertFalse(marker.exists())
                # Release only after run_compiler has returned. A surviving
                # child would now mutate files outside the caller's build lock.
                release.touch()
                deadline = time.monotonic() + 1
                while not marker.exists() and time.monotonic() < deadline:
                    time.sleep(0.01)
                self.assertFalse(expired)
                self.assertEqual(result.returncode, status)
                self.assertEqual(result.stdout, 'leader diagnostic\n')
                self.assertFalse(marker.exists(), 'descendant wrote after runner returned')
            finally:
                if pids.exists():
                    _, child_pid = json.loads(pids.read_text())
                    try:
                        os.kill(child_pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass

    def test_successful_leader_stops_redirected_descendants(self):
        for timeout in (None, 3):
            with self.subTest(timeout=timeout):
                self.background_writer_trial(0, timeout)

    def test_failed_leader_stops_redirected_descendants(self):
        for timeout in (None, 3):
            with self.subTest(timeout=timeout):
                self.background_writer_trial(7, timeout)

    def detached_pipe_trial(self, stream='stdout', leader_exits=False, interrupt=False):
        """Run run_compiler behind a watchdog and always reap escaped descendants."""
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            leader_pid = root / 'leader.pid'
            descendant_pid = root / 'descendant.pid'
            child_ready, leader_ready, armed = (root / name for name in ('child.ready', 'leader.ready', 'armed'))
            child = (
                'import sys,time; from pathlib import Path; '
                f'print("detached-{stream}",file=sys.{stream},flush=True); '
                f'Path({str(child_ready)!r}).touch(); time.sleep(30)'
            )
            leader_tail = 'sys.exit(0)' if leader_exits else 'time.sleep(30)'
            leader = (
                'import os,subprocess,sys,time; from pathlib import Path; '
                f'Path({str(leader_pid)!r}).write_text(str(os.getpid())); '
                f'c=subprocess.Popen([sys.executable,"-u","-c",{child!r}],start_new_session=True); '
                f'Path({str(descendant_pid)!r}).write_text(str(c.pid)); '
                f'print("leader-{stream}",file=sys.{stream},flush=True); '
                f'Path({str(leader_ready)!r}).touch(); {leader_tail}'
            )
            harness = str(Path(__file__).resolve().parent)
            # Start the short cleanup clock only after both real processes
            # have emitted their diagnostics. CPU load must not turn this into
            # a test of whether two Python interpreters start within 200ms.
            wrapper = (
                'import json,os,signal,sys,threading,time\nfrom pathlib import Path\n'
                f'sys.path.insert(0,{harness!r})\n'
                'import build_process\n'
                'original_popen=build_process.subprocess.Popen\n'
                'def ready_popen(*args,**kwargs):\n'
                ' process=original_popen(*args,**kwargs)\n'
                ' deadline=time.monotonic()+3\n'
                f' while not (Path({str(child_ready)!r}).exists() and Path({str(leader_ready)!r}).exists()):\n'
                '  if time.monotonic()>deadline: raise RuntimeError("process fixture did not become ready")\n'
                '  time.sleep(0.005)\n'
                f' Path({str(armed)!r}).write_text(str(time.monotonic()))\n'
                + (' threading.Timer(0.2,lambda:os.kill(os.getpid(),signal.SIGINT)).start()\n' if interrupt else '')
                + ' return process\n'
                'build_process.subprocess.Popen=ready_popen\n'
                f'command=[sys.executable,"-u","-c",{leader!r}]\n'
            )
            if interrupt:
                wrapper += (
                    'try:\n'
                    ' build_process.run_compiler(command,timeout=30)\n'
                    'except KeyboardInterrupt:\n'
                    ' print(json.dumps({"interrupted":True}),flush=True)\n'
                )
            else:
                wrapper += (
                    'r,t=build_process.run_compiler(command,timeout=0.2)\n'
                    'print(json.dumps({"timed_out":t,"returncode":r.returncode,"stdout":r.stdout}),flush=True)\n'
                )
            started = time.monotonic()
            # A shell background job starts with SIGINT ignored, and Python then
            # never raises KeyboardInterrupt; give the wrapper a real handler.
            outer = subprocess.Popen(
                [sys.executable, '-u', '-c', wrapper], start_new_session=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                preexec_fn=lambda: signal.signal(signal.SIGINT, signal.SIG_DFL),
            )
            returned = False
            output = ''
            descendant_alive = False
            leader_alive = False
            try:
                output, _ = outer.communicate(timeout=5.5)
                returned = True
            except subprocess.TimeoutExpired as error:
                output = error.output or ''
                os.killpg(outer.pid, signal.SIGKILL)
                tail, _ = outer.communicate(timeout=1)
                output = tail or output
            finally:
                if outer.poll() is None:
                    os.killpg(outer.pid, signal.SIGKILL)
                    outer.communicate(timeout=1)
                pids = []
                for pid_path in (leader_pid, descendant_pid):
                    if pid_path.exists():
                        pid = int(pid_path.read_text())
                        pids.append(pid)
                        try:
                            os.kill(pid, 0)
                            if pid_path == descendant_pid:
                                descendant_alive = True
                            else:
                                leader_alive = True
                        except ProcessLookupError:
                            pass
                        try:
                            os.kill(pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
            return {
                'returned': returned,
                'elapsed': time.monotonic() - float(armed.read_text()) if armed.exists() else time.monotonic() - started,
                'total_elapsed': time.monotonic() - started,
                'outer_returncode': outer.returncode,
                'pids': pids,
                'descendant_alive_before_cleanup': descendant_alive,
                'leader_alive_before_cleanup': leader_alive,
                'output': output,
            }

    def test_success_and_nonzero_exit_retain_output(self):
        for status in (0, 7):
            result, expired = self.run_python(f'import sys; print("diagnostic"); sys.exit({status})', timeout=2)
            self.assertFalse(expired);self.assertEqual(result.returncode,status)
            self.assertEqual(result.stdout,'diagnostic\n')

    def test_optional_timeout_preserves_unbounded_mode(self):
        result,expired=self.run_python('print("done")')
        self.assertFalse(expired);self.assertEqual(result.stdout,'done\n')

    def test_timeout_preserves_partial_output(self):
        result,expired=self.run_python('import time; print("started"); time.sleep(30)',timeout=1)
        self.assertTrue(expired);self.assertNotEqual(result.returncode,0)
        self.assertEqual(result.stdout,'started\n')

    def test_detached_descendant_cannot_hold_stdout_cleanup_open(self):
        trial = self.detached_pipe_trial()
        self.assertTrue(trial['returned'], trial)
        report = json.loads(trial['output'])
        self.assertTrue(report['timed_out'])
        self.assertNotEqual(report['returncode'], 0)
        self.assertCountEqual(report['stdout'].splitlines(), ['leader-stdout', 'detached-stdout'])

    def test_detached_pipes_and_exited_leader_have_bounded_cleanup(self):
        cases = (('stderr', False, -signal.SIGKILL), ('stdout', True, 0))
        for stream, leader_exits, returncode in cases:
            with self.subTest(stream=stream, leader_exits=leader_exits):
                trial = self.detached_pipe_trial(stream, leader_exits)
                self.assertTrue(trial['returned'], trial)
                self.assertLess(trial['elapsed'], 2.5)
                self.assertTrue(trial['descendant_alive_before_cleanup'], trial)
                report = json.loads(trial['output'])
                self.assertTrue(report['timed_out'])
                self.assertEqual(report['returncode'], returncode)
                self.assertCountEqual(
                    report['stdout'].splitlines(),
                    [f'leader-{stream}', f'detached-{stream}'],
                )

    def test_interrupt_cleanup_is_bounded_with_detached_pipe(self):
        trial = self.detached_pipe_trial(interrupt=True)
        self.assertTrue(trial['returned'], trial)
        self.assertLess(trial['elapsed'], 2.5)
        self.assertEqual(json.loads(trial['output']), {'interrupted': True})
        self.assertFalse(trial['leader_alive_before_cleanup'], trial)

    def test_compiler_descendants_are_stopped(self):
        with tempfile.TemporaryDirectory() as temp:
            marker=Path(temp)/'orphan'
            child=f'import time; from pathlib import Path; time.sleep(1.5); Path({str(marker)!r}).write_text("survived")'
            parent=f'import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",{child!r}]); print("child launched"); time.sleep(30)'
            result,expired=self.run_python(parent,timeout=1)
            self.assertTrue(expired);self.assertIn('child launched',result.stdout)
            time.sleep(0.8)
            self.assertFalse(marker.exists())

    def test_invalid_timeout_does_not_start_process(self):
        with patch('build_process.subprocess.Popen') as popen:
            for timeout in (0,-1,float('inf'),float('nan'),True,'1'):
                with self.assertRaises(ValueError):self.run_python('',timeout=timeout)
            popen.assert_not_called()

    def test_builder_releases_slot_and_retains_log_without_publication(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);slot=io.StringIO();out=root/'out';(root/'src').mkdir()
            (root/'crate').mkdir()
            (root/'crate/Cargo.toml').write_text('[package]\nname="pump-recovered"\nversion="0.1.0"\n')
            out.mkdir()
            (out/'candidate.so').write_bytes(b'prior candidate')
            (out/'unstripped.so').write_bytes(b'prior unstripped')
            (out/'build.log').write_text('prior log')
            original_archive = fastbuild.archive_previous_outputs
            def archive(path):
                with self.assertRaisesRegex(RuntimeError, 'already in use'):
                    with fastbuild.workspace_lock(root/'work'):
                        pass
                original_archive(path)
            def compiler(command, **kwargs):
                self.assertFalse((out/'candidate.so').exists())
                self.assertFalse((out/'unstripped.so').exists())
                self.assertFalse((out/'build.log').exists())
                self.assertEqual(len(list((out/'previous').glob('build-*'))), 1)
                self.assertEqual(kwargs['timeout'], 1)
                with self.assertRaisesRegex(RuntimeError, 'already in use'):
                    with fastbuild.workspace_lock(root/'work'):
                        pass
                return self.run_python('import time; print("partial compiler log"); time.sleep(30)', timeout=kwargs['timeout'])
            with patch.object(fastbuild,'archive_previous_outputs',side_effect=archive),patch.object(fastbuild,'stage',return_value=root/'crate'),patch.object(fastbuild,'acquire_slot',return_value=slot),patch.object(fastbuild,'run_compiler',side_effect=compiler),patch.object(fastbuild,'RECIPES',{'test':{'triple':'test','rustc':root/'rustc','template':root/'missing'}}),patch.object(fastbuild.subprocess,'run') as publish:
                report=fastbuild.build(root/'src',root/'work',out,quiet=True,recipe='test',timeout=1)
                publish.assert_not_called()
            self.assertFalse(report['ok']);self.assertTrue(report['timed_out']);self.assertTrue(slot.closed)
            self.assertEqual((out/'build.log').read_text(),'partial compiler log\n')
            self.assertFalse((out/'candidate.so').exists())
            self.assertFalse((out/'unstripped.so').exists())
            archive, = (out/'previous').glob('build-*')
            self.assertEqual((archive/'candidate.so').read_bytes(), b'prior candidate')
            self.assertEqual((archive/'unstripped.so').read_bytes(), b'prior unstripped')
            self.assertEqual((archive/'build.log').read_text(), 'prior log')
            with fastbuild.workspace_lock(root/'work'):
                pass

    def test_invalid_timeout_precedes_workspace_mutation(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            with self.assertRaises(ValueError):
                fastbuild.build(root/'src',root/'work',root/'out',timeout=0)
            self.assertEqual(list(root.iterdir()), [])


if __name__ == '__main__':unittest.main()
