"""Materialization-only correction for a required newly imported upstream fixture."""
import hashlib,json,os,stat
from pathlib import Path
R=Path('/dev/shm/pump-cto-s5-publication');P=R/'work/preparation/INPUTS-PREPARED.json';d=json.loads(P.read_text());Q=R/'work/preparation-attempt-02';Q.mkdir(exist_ok=False)
for row in d['local']:
 p=R/row['path'];s=p.lstat();b=os.fsencode(os.readlink(p))if p.is_symlink()else p.read_bytes()
 assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']and(s.st_mode,s.st_dev,s.st_ino,s.st_mtime_ns)==(row['physical_mode'],row['device'],row['inode'],row['mtime_ns']),str(p)
name='research/imported-lab/analysis/pump_fun/curve-fresh-trades-v3-signed-surfpool.json';p=R/name;s=p.lstat();b=p.read_bytes();assert not p.is_symlink()and stat.S_ISREG(s.st_mode)
oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert oid=='2254a3521cb78c0f866ee1fbb3ef42fda2ad1e7f'
assert name not in [r['path']for r in d['local']]
d['local'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'physical_mode':s.st_mode,'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'git_mode':'100644','git_blob':oid});d['local'].sort(key=lambda x:x['path'])
d['correction']={'firstToolingAttempt':'250 tests, one missing tracked fixture in sparse checkout; failure retained under work/checks-attempt-01/tooling.','trackedInputAdded':name,'gitBlob':oid,'prior1559PhysicalInputsUnchanged':True,'programSourceOrPacketChanged':False,'onlyToolingWillRerun':True}
(Q/'INPUTS-PREPARED.json').write_text(json.dumps(d,indent=2)+'\n')
t=Path('/dev/shm/run_s5_publication_checks.py').read_text().replace('work/preparation/INPUTS-PREPARED.json','work/preparation-attempt-02/INPUTS-PREPARED.json').replace('work/checks-attempt-01','work/checks-attempt-02')
t='\n'.join("    commands=[('tooling',[sys.executable,'-B','scripts/test_tooling.py'])]"if line.startswith('    commands=')else line for line in t.splitlines())+'\n'
Path('/dev/shm/run_s5_tooling_retry.py').write_text(t)
print(json.dumps({'preparedInputs':len(d['local']),'addedTrackedFixtureBytes':len(b),'gitBlob':oid,'onlyFailedToolingWillRerun':True,'runnerSHA256':hashlib.sha256(t.encode()).hexdigest()}))
