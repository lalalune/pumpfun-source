import datetime,hashlib,json,os,stat,subprocess,sys
from pathlib import Path
R=Path('/dev/shm/pump-cto-s5-publication');O=R/'work/preparation';O.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='c78a9861f047606b16b46de84712584d514f3072'
assert git('rev-parse','HEAD^{tree}').decode().strip()=='ea0b2d6147bfda6ae940c0b2531f844afe41ce81'
assert not git('status','--porcelain','--untracked-files=no')
def row(p):
 s=p.lstat();b=os.fsencode(os.readlink(p))if p.is_symlink()else p.read_bytes();assert p.is_symlink()or stat.S_ISREG(s.st_mode)
 return {'path':str(p),'bytes':len(b),'sha256':sha(b),'physical_mode':s.st_mode,'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
local=[]
for raw in git('ls-files','--stage','-z').split(b'\0'):
 if not raw:continue
 meta,name=raw.split(b'\t',1);mode,oid,stage=meta.decode().split();name=name.decode();p=R/name
 if not p.exists()and not p.is_symlink():continue
 v=row(p);b=os.fsencode(os.readlink(p))if p.is_symlink()else p.read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 v.update(path=name,git_mode=mode,git_blob=oid);local.append(v)
prior=json.loads(Path('/dev/shm/pump-cto-h1-publication/work/preparation/INPUTS-PREPARED.json').read_text())['external']
external={'python':row(Path(sys.executable).resolve()),'python_version':sys.version,'versions':prior['versions'],'qualified_runtime_files':[row(Path(x['path']))for x in prior['qualified_runtime_files']]}
assert external['python']['sha256']==prior['python']['sha256']
assert all(x['sha256']==y['sha256']for x,y in zip(external['qualified_runtime_files'],prior['qualified_runtime_files']))
extra=[]
for name,p in [('S5-native-ZIP',Path('/dev/shm/pump-cto-borrowed-selection-s5/work/native-run/raw-artifact.zip')),('S5-capsule',Path('/dev/shm/pump-cto-borrowed-selection-s5-retention/s5-borrowed-selection-admission.tar.xz')),('D421-control-ZIP',Path('/dev/shm/pump-cto-d421-control/work/native-run/raw-artifact.zip')),('D421-capsule',Path('/dev/shm/pump-cto-d421-retention/d421-current-admission.tar.xz'))]:
 v=row(p);v['name']=name;extra.append(v)
prepared={'commit':'c78a9861f047606b16b46de84712584d514f3072','tree':'ea0b2d6147bfda6ae940c0b2531f844afe41ce81','parent':'9120883a957d7d9b2cab6140f66fb5bc9e6774d5','local':local,'external':external,'extra':extra,'installReview':'No installation. Read current test_tooling.py delta44 lines and its new symbol/fixture-input tests; report writer and existing shared fixture input paths reviewed. Program build was separately fixed D421/S5, no source edits in this publication.','scope':'One read-only packet replay and both required evidence/tooling checks; no source/compiler/metric/candidateVM action.','agentReview':False}
(O/'INPUTS-PREPARED.json').write_text(json.dumps(prepared,indent=2)+'\n')
old=Path('/dev/shm/run_h1_publication_checks.py').read_text();new=old.replace('prepared H1 packet','prepared S5 packet').replace('/dev/shm/pump-cto-h1-publication',str(R)).replace('hopt-h1-negative-20261031','borrowed-selection-s5-negative-20261031').replace('2e2dfdb14af8060f67a59acdfdec7879c851b9e4',prepared['commit']).replace('/dev/shm/h1-publication-check-tmp','/dev/shm/s5-publication-check-tmp').replace('H1-native-ZIP','S5-native-ZIP').replace('Ebe-control-ZIP','D421-control-ZIP').replace('H1-capsule','S5-capsule').replace("'--capsule',inputs['S5-capsule']]","'--capsule',inputs['S5-capsule'],'--control-capsule',inputs['D421-capsule']]").replace("'externalInputs':8","'externalInputs':9")
Path('/dev/shm/run_s5_publication_checks.py').write_text(new)
print(json.dumps({'localTypedFiles':len(local),'externalInputs':len(extra)+len(external['qualified_runtime_files'])+1,'genuineRevision':prepared['commit'],'runnerSHA256':sha(new.encode())}))
