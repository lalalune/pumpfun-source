"""One execution of each check at the genuine prepared H1 packet revision."""
from pathlib import Path
import datetime, hashlib, json, os, stat, subprocess, sys, time

ROOT=Path('/dev/shm/pump-cto-h1-publication')
PREP=ROOT/'work/preparation/INPUTS-PREPARED.json'
OUT=ROOT/'work/checks-attempt-01'
LANE='reconstruction/pump-main/lanes/hopt-h1-negative-20261031'
def sha(data): return hashlib.sha256(data).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path, value):
    with path.open('x') as stream: stream.write(json.dumps(value,indent=2)+'\n')
def snapshot(prepared):
    records={}
    rows=[(ROOT/r['path'],r) for r in prepared['local']]
    rows += [(Path(r['path']),r) for r in [prepared['external']['python'],*prepared['external']['qualified_runtime_files'],*prepared['extra']]]
    for path,row in rows:
        info=path.lstat()
        if row.get('git_mode')=='120000':
            assert path.is_symlink(); data=os.fsencode(os.readlink(path))
        else:
            assert stat.S_ISREG(info.st_mode) and not path.is_symlink(); data=path.read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256'],str(path)
        assert (info.st_mode,info.st_dev,info.st_ino,info.st_mtime_ns)==(row['physical_mode'],row['device'],row['inode'],row['mtime_ns']),str(path)
        if 'git_blob' in row: assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob']
        records[str(path)]={'bytes':len(data),'sha256':sha(data),'mode':info.st_mode,'device':info.st_dev,'inode':info.st_ino,'mtime_ns':info.st_mtime_ns}
    return records
def main():
    assert sys.dont_write_bytecode and sys.flags.optimize==0 and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
    assert not OUT.exists()
    prepared=json.loads(PREP.read_text())
    assert prepared['commit']=='2e2dfdb14af8060f67a59acdfdec7879c851b9e4'
    for suffix,expected in [('HEAD',prepared['commit']),('HEAD^{tree}',prepared['tree'])]:
        assert subprocess.check_output(['git','rev-parse',suffix],cwd=ROOT).decode().strip()==expected
    OUT.mkdir()
    env=dict(os.environ);env.pop('PYTHONPATH',None);env.pop('PYTHONOPTIMIZE',None)
    temporary=Path('/dev/shm/h1-publication-check-tmp');temporary.mkdir(exist_ok=True)
    env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(temporary))
    inputs={r['name']:r['path'] for r in prepared['extra']}
    commands=[('portable',[sys.executable,'-B',LANE+'/verify.py','--repo',str(ROOT),'--native-zip',inputs['H1-native-ZIP'],'--control-zip',inputs['Ebe-control-ZIP'],'--capsule',inputs['H1-capsule']]),('evidence',[sys.executable,'-B','scripts/verify_evidence.py']),('tooling',[sys.executable,'-B','scripts/test_tooling.py'])]
    results=[]
    for name,argv in commands:
        destination=OUT/name;destination.mkdir();before=snapshot(prepared);save(destination/'INPUTS-BEFORE.json',before)
        started=now();clock=time.monotonic();save(destination/'STARTED.json',{'argv':argv,'cwd':str(ROOT),'utc':started,'once':True})
        with (destination/'stdout').open('xb') as stdout,(destination/'stderr').open('xb') as stderr:
            child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
            save(destination/'PROCESS.json',{'pid':child.pid,'argv':argv,'cwd':str(ROOT),'startUtc':started,'environment':{k:env.get(k) for k in ('PYTHONDONTWRITEBYTECODE','PYTHONPATH','PYTHONOPTIMIZE','TMPDIR')}})
            code=child.wait()
        after=snapshot(prepared);save(destination/'INPUTS-AFTER.json',after);assert before==after
        result={'name':name,'pid':child.pid,'argv':argv,'startUtc':started,'endUtc':now(),'elapsedSeconds':time.monotonic()-clock,'exitCode':code,'localInputs':len(prepared['local']),'externalInputs':8,'allInputsUnchanged':True,'files':{n:{'bytes':(destination/n).stat().st_size,'sha256':sha((destination/n).read_bytes())} for n in ('stdout','stderr')}}
        save(destination/'RESULT.json',result);results.append(result);print(json.dumps(result),flush=True)
        if code:
            save(OUT/'STOPPED.json',{'status':'FIRST_FAILURE_RETAINED_NO_LATER_COMMANDS','command':name,'results':results})
            return 1
    save(OUT/'RECEIPT.json',{'commit':prepared['commit'],'tree':prepared['tree'],'checks':results,'preparedInputsSHA256':sha(PREP.read_bytes()),'programSourceChanges':0,'limits':'Bounded evidence replay and required tooling checks; no compiler, new official score, metric or candidate VM.'})
    return 0
if __name__=='__main__': raise SystemExit(main())
